# 21. tcgen05 同步范式 —— fence / pipeline / 跨线程 canonical patterns

> 锚点：承接笔记 15(blackwell_hardware §七-§九 mbarrier/async barrier)、17(tma_smem_desc_mbarrier)。
> 主题：Blackwell **异步 tcgen05 指令**(mma/cp/ld…)之间如何建立顺序 —— 两道 `tcgen05.fence` +
> morally strong 同步指令 + pipeline 概念。来源：PTX ISA 9.7.17.6.4 Canonical synchronization patterns。
> 一句话：**fence 只在本线程内划"禁止重排的隔离线"；跨线程的顺序必须靠 mbarrier 这类桥来传递。**

---

## 0. 一句话结论

| 概念 | 含义 |
|--|--|
| **tcgen05 pipeline** | 特定成对的异步 tcgen05 指令，硬件**自动保证按发射顺序执行**(in-order)，无需显式 wait |
| **Non-pipelined** | 硬件**不自动**保证顺序(放任会乱序)，但**加显式 `tcgen05.wait`** 后照样正确 |
| **`fence::before_thread_sync`** | 生产者侧：把 fence **之前**的异步操作**封在 fence 之前**(封下界，往上封) |
| **`fence::after_thread_sync`** | 消费者侧：把 fence **之后**的操作**拦在 fence 之后**(拦上界，往下拦) |
| **morally strong 指令** | 跨线程传递顺序的**唯一桥**：mbarrier / `st.release`→`ld.acquire` / `atom` / `barrier` |

---

## 1. 两套同步机制(tcgen05 有两个选择)

原文：*tcgen05 支持一种 specialized inter-thread synchronization，针对 tcgen05 家族优化；
standard memory consistency model 的同步机制也依然适用。*

| | 专用机制 | 标准机制 |
|--|------|------|
| 指令 | `tcgen05.fence::before/after_thread_sync` | `fence`/`ld.acquire`/`st.release`/`atom`/`mbarrier`/`barrier` |
| 面向 | 只为 tcgen05 家族优化 | 对所有 PTX 指令通用 |
| 定位 | 更轻、贴合异步 MMA | 通用兜底 |

先用专用 fence(为异步 MMA 优化)，标准机制也不失效。

---

## 2. fence 是什么 —— "禁止重排的隔离线"

fence **不搬数据、不做同步**，只是一条"墙"，禁止某些操作跨越它重排。
类比机场安检：安检前的人必须全过完，安检后才放行；安检线本身不"执行"任何事，只规定顺序。

**关键：这套跨线程机制里有两道 fence，长在不同线程里，不是同一道被两个线程越过。**

- `before_thread_sync`(生产者 A)：把上面的异步操作"封住不下溜"(下界)
- `after_thread_sync`(消费者 B)：把下面的读取"拦住不上蹿"(上界)

为什么要两道对向封堵？因为异步 tcgen05 的乱序发生在**两侧**：A 可能让完成漏到后面，
B 可能让读取提前到前面。只堵一侧堵不住。

**精修点**：A 侧 fence 按住的是异步 mma/cp 的**"完成效果"**(写进 TMEM 的结果)，不是"指令发射"。
指令发射早过去了，异步计算还在后台跑，要按住的是它算完、结果落定这个事件。

---

## 3. 三段接力(生产者 A → 消费者 B 的完整数据流)

两道 fence 只在**本线程内**生效，本身不跨线程。morally strong 指令是**唯一把两侧接起来的桥**。
是**串联接力**，不是并列的三重保险：

```
线程 A(生产者):
    tcgen05.mma ...                      // 异步算(乱序完成)
    tcgen05.fence::before_thread_sync    // ① A侧封下界:把 mma 完成锚在此线之前
    st.release / mbarrier.arrive         // ② 桥:发信号(跨线程)
- - - - - - - - - - - - - - - - - - - - - - -
线程 B(消费者):
    ld.acquire / mbarrier.try_wait       // ② 桥:收信号(跨线程)
    tcgen05.fence::after_thread_sync     // ③ B侧拦上界:读取只能在此线之后
    tcgen05.ld / 读 TMEM 累加器           // 此刻保证:A 的 mma 结果已完成且可见
```

- 单独 mbarrier：能跨线程传信号，但保证不了 A 的异步 mma 真做完
- 单独 fence：能锚定异步操作，但信号传不到 B
- **两者组合**：才得到完整的 happens-before

它保证的是 **ordering(顺序) + visibility(可见性)**，不是"A 线程整体先于 B 执行"。

---

## 4. morally strong(实质强序)

PTX 内存模型术语，是**一对操作**的属性(不是单条指令)。两个操作互为 morally strong 当且仅当：

1. **二者都是 strong 操作**(带同步语义、非 relaxed)：`atom`/`ld.acquire`/`st.release`/`fence`/`mbarrier`…
2. **scope 互相覆盖对方**：各自声明的 `.cta`/`.cluster`/`.gpu`/`.sys` 都大到能包含对方所在线程

**坑**：用 relaxed 访存、或 scope 不够(只声明 `.cta` 却想跨 cluster)→ 不是 morally strong → fence 建立不起想要的跨线程顺序。

> ⚠️ 但见 §6 的重要修正：在 fence 已兜底顺序的场景，桥可以退化成 **relaxed mbarrier**。

---

## 5. pipeline 概念 —— "按发射顺序执行"的白送保证

异步指令默认"发射后乱序完成"。一旦某对异步 tcgen05 指令**能形成 pipeline**，就额外获得
"按发射顺序执行"的保证 —— 像自动扶梯:先进先出，你什么都不用做。

**修正常见误解**：Non-pipelined **不等于"注定乱序没救"**，而是"默认乱序、但可用显式 wait 救回来"。
两者**最终都能正确**，区别是顺序"免费白送"还是"你自己加 wait 换取"：

```
Pipelined     = 自动扶梯:站着不动自动按序送上去
Non-pipelined = 普通楼梯:不迈腿(不加wait)上不去;自己迈腿(加wait)照样按序上楼
```

---

## 6. Canonical patterns 2×2 矩阵(PTX 9.7.17.6.4)

两个正交维度切出 4 格 + 1 特例：

| | **same thread(同线程)** | **different thread(跨线程)** |
|--|------|------|
| **Pipelined** | 6.4.1 | **6.4.3** |
| **Non-pipelined** | 6.4.2 | 6.4.4 |
| 特例 | 6.4.5 Register dependencies | — |

**规律(两维度各管一件事)：**
- **Pipelined vs Non** → 决定要不要**显式 wait**(Non 要，Pipelined 不要)
- **same vs different** → 决定要不要**跨线程同步(mbarrier)**(different 要，same 不要)

| 小节 | 显式 wait? | 跨线程同步? |
|--|--|--|
| 6.4.1 Pipelined, same | ❌ | ❌ (最省事) |
| 6.4.2 Non-pipelined, same | ✅ | ❌ |
| 6.4.3 Pipelined, different | ❌ | ✅ |
| 6.4.4 Non-pipelined, different | ✅ | ✅ (最全副武装) |

---

## 7. 三个跨线程代码范例(消费者侧永远相同，差异全在生产者)

**消费者 Thread 1 在三例中一字不差**(跨线程那道坎的固定模式)：
```
mbarrier.try_wait.relaxed.cluster [mbar]  // loop till success
tcgen05.fence::after_thread_sync
tcgen05.ld / tcgen05.mma                   // 消费
```
变的永远是**生产者如何确保"完成"并把信号送上桥**。

### 例 A — 6.4.3 Pipelined, different thread (cp)
```
Thread 0:
    tcgen05.cp
    tcgen05.fence::before_thread_sync
    mbarrier.arrive.relaxed.cluster
```
- cp **能形成 pipeline** → before fence 自动锚定 cp 完成 → **生产者无需显式 wait**
- 正文："no explicit waiting mechanism is needed but proper synchronization between threads is needed"
  → 前半=Pipelined，后半=different thread，正好是这个格子的两个坐标
- **`.relaxed` 的关键印证**：顺序已全部由两道 fence 包办，mbarrier 无需再扛内存序，
  只负责"跨线程传信号"，故用最便宜的 relaxed 即可。
  → 修正 §4：morally strong 桥**不一定非得 acquire/release**；顺序由 fence 兜底时可退化成 relaxed mbarrier

### 例 B — 6.4.4 Non-pipelined, different thread (ld)
```
Thread 0:
    tcgen05.ld
    tcgen05.wait::ld                     ← ★ 比例A多这一行
    tcgen05.fence::before_thread_sync
    mbarrier.arrive.relaxed.cluster
```
- ld **形不成 pipeline** → fence 锚不住它的完成 → 生产者**必须先显式 `tcgen05.wait::ld` 死等**再发信号
- 正文："producer threads must explicitly wait for the instructions' completion before synchronizing with consumers"
- **例A 与例B 唯一差别就是这条 `tcgen05.wait::ld`** —— 这一行就是 pipeline/non-pipeline 区别的全部物理体现

### 例 C — mma 的专用捷径 (commit 三合一)
```
Thread 0:
    tcgen05.mma
    tcgen05.commit.mbarrier::arrive::one [mbar]   ← 一条顶三条
```
- `tcgen05.commit.mbarrier::arrive` **一条指令同时干三件事**：
  ① 等前面的 mma 完成(替代 wait) ② 锚定顺序(替代 before fence) ③ mma 完成后自动向 [mbar] arrive(替代单独 arrive)
- 语义："把我前面发的 mma 提交给这个 mbarrier，全部完成后替我 arrive 一次"
- 能用这条捷径，是因为 **mma 完成有专门的硬件追踪**(note 15 "MMA 完成走第三条 `tcgen05.commit`")

**三种生产者写法总览：**
| 异步指令 | 完成怎么保证 | 发信号 | 生产者代码 |
|--|--|--|--|
| cp (pipelined) | fence 自动锚定 | 单独 arrive | fence + arrive (2步) |
| ld (non-pipelined) | 手动 `wait::ld` | 单独 arrive | wait + fence + arrive (3步) |
| mma | `commit` 内置等待 | `commit` 内置 arrive | **`commit.mbarrier::arrive` (1步)** |

---

## 8. 与本仓其他笔记的咬合

- note 15 §七-§九：mbarrier 的 phase parity / tx-count / 2SM commit multicast —— 本篇的桥就用这些原语
- note 15 warp 专精：softmax/mma/correction warp 共用 TMEM 累加器，正是靠 fence+mbarrier 保证 mma warp 算完 softmax warp 才读
- `AI/DEBUG_2CTA.md`："TMEM 提前释放/读取" 死锁 = 没锚定异步 tcgen05 完成就跨 warp 读 → 本篇机制正是解药

---

## 9. TMEM 三件套 ld / st / cp —— 累加器进出指令

Blackwell(gen5)新增 **TMEM(Tensor Memory)**：`tcgen05.mma` 的累加器 `d` 不再放寄存器，而是驻留 TMEM(容量大、跨 warp 共享、跨 2CTA 池化)。因此需要专门指令在 TMEM 与其他存储间搬数据。

**内存层级：**
```
HBM ──TMA──> SMEM ──tcgen05.cp──> TMEM <──ld/st──> RF(寄存器)
```

| 指令 | 数据方向 | 用途 |
|--|--|--|
| **`tcgen05.ld`** | **TMEM → 寄存器** | 把 MMA 累加结果读出，交线程做 softmax/epilogue/写回 |
| **`tcgen05.st`** | **寄存器 → TMEM** | 初始化累加器 / 把中间结果放回 TMEM 供下一次 MMA |
| **`tcgen05.cp`** | **SMEM → TMEM** | 异步批量拷贝(不过寄存器)，如 FP8 scale/操作数直接进 TMEM |

- **TMEM 只有 async proxy(tcgen05 系)能访问**，普通线程 `ld.shared` 读不了 TMEM。
- 三条都是异步的 → 需 §2-§7 的 wait/fence/commit 同步。
- FA4 (`flash_fwd_sm100.py`) 里：mma 累加进 TMEM → softmax warp 用 `ld` 读回算 online-softmax → P 矩阵可 `st` 回 TMEM 给 PV 的 mma → FP8 scale 用 `cp` 从 SMEM 进 TMEM。

---

## 10. 6.4.5 Register dependencies 补充 —— "保值不保时序"

> 原文：*For tcgen05.ld, an intra-thread ordering through true register dependency will be respected
> regardless of the presence or absence of other forms of synchronization. This form of register
> dependency does not imply any other form of ordering. ... To enforce such memory orderings and
> avoiding anti-dependency hazards around tcgen05.ld, tcgen05.wait::ld must be used.*

**核心：`tcgen05.ld` 给一条"寄存器值正确性"的免费保序链，但它不外溢成任何其他顺序保证。**

**✅ 保证(免费)**：同线程内，**直接消费 ld 目标寄存器值**的下游指令，靠真寄存器依赖(RAW)天然保序，无需 wait/fence。
```
tcgen05.ld  %r1, [d];
tcgen05.mma ..., %r1, ...;   // mma 读 %r1 → 有寄存器依赖 → 免同步(6.4.5 example)
```

**❌ 不保证(必须显式同步)**：
- ld 的**访存动作**(读 TMEM)相对其他内存操作的时序 —— *"a register dependency does not imply that a dependee instruction's memory accesses will be performed before a dependent instruction's memory accesses"*
- 对**同一 TMEM 地址的覆盖**(下一个 mma 写 d、释放 TMEM)= **anti-dependency / WAR 冒险**
- **跨线程**使用

```
tcgen05.ld  %r1, [d];
tcgen05.wait::ld;            // ★ 防 WAR + 强制内存顺序
tcgen05.mma [d], ...;        // 覆盖 d 才安全(不读 %r1 → 无寄存器依赖兜不住)
```

**判定关键点**：下游到底"用不用" ld 的那个目标寄存器 —— 用 → 免费保序；只是碰同一块 TMEM/跨线程 → 必须 `tcgen05.wait::ld`。
**本质**：寄存器依赖管"**值对不对**"，`tcgen05.wait::ld` 管"**访存时序 + 防覆盖**"，两者不同维度。

---

## 11. 6.5 Shared Memory Accesses —— proxy 与 `fence.proxy.async`

> 原文：*The shared memory accesses by tcgen05.mma and tcgen05.cp operations are performed in the
> asynchronous proxy (async proxy). Accessing the same memory location across multiple proxies needs
> a cross-proxy fence. For the async proxy, fence.proxy.async should be used to synchronize memory
> between generic proxy and the async proxy.*

**proxy = 访问内存的"通道/路径"。** 同一块内存可经不同物理路径读写，各路径有各自缓存/缓冲 → 一个 proxy 的写，另一个 proxy **不保证自动可见**。这是与 §2-§10"完成时序"**正交的另一维度：可见性**。

| proxy | 往 SMEM 写 | 从 SMEM 读 |
|--|--|--|
| **generic**(普通线程) | `st.shared` | `ld.shared` |
| **async**(异步引擎) | **TMA** `cp.async.bulk` | `tcgen05.mma`、`tcgen05.cp` 的**源** |

- **触发条件**：**同一内存地址** 被 generic 和 async **两种 proxy 交叉读写**(TMEM 只有 async 能碰，不涉及跨 proxy；跨 proxy 冲突只发生在 **SMEM** 这块两边都能碰的内存)。
- **解决**：`fence.proxy.async` 建立 generic ↔ async 的跨 proxy 可见性。

**两类场景(注意"可见"与"完成"是两件事)：**

场景 A — generic 写 → async 读(普通线程备数据给 MMA)。generic `st.shared` 是**同步**指令，写完即完，**只需 fence(可见性)**：
```
st.shared  [smem], data       // generic 写
fence.proxy.async             // ← 让 async 看得见
tcgen05.mma ..., [smem], ...  // async(cp 同理，读 SMEM 源)
```

场景 B — async 写 → generic 读(TMA 搬进 SMEM 给普通线程)。async 是异步的，**既要等完成又要 fence**：
```
cp.async.bulk [smem], [gmem]  // async(TMA)写 SMEM
（mbarrier 等 TMA 完成: tx-count）  // ① 完成(时序)
fence.proxy.async             // ② 可见(跨 proxy)
ld.shared  r, [smem]          // generic 读
```

**正交关系(勿混)**：
- 异步操作**做完了吗**(时序) → mbarrier / `wait` / `commit`（§2-§7）
- 跨 proxy **看得见吗**(可见性) → `fence.proxy.async`（本节）

真实 kernel 常两者都要：先(或后)`fence.proxy.async` 保可见，再用 mbarrier/wait 保完成。

> ⚠️ 易错纠正：`tcgen05.cp` 是 **SMEM→TMEM**(源在 SMEM、目标在 TMEM)，不是往 SMEM 写。往 SMEM 写的 async 主角是 **TMA**。`cp` 的跨 proxy 可见性发生在它**读 SMEM 源**这一侧(若该 SMEM 是 generic 刚写的，需 fence)。
