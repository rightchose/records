# 17. TMA descriptor / smem descriptor / mbarrier —— 三大硬件结构的构造与使用

> 以 FlashAttention-4 (`flash-attention/flash_attn/cute/`) 代码为锚，讲清楚 Hopper/Blackwell 上
> 异步流水线三件套的**大小、谁来造、怎么用**。
>
> 相关文件：
> - `mma_sm100_desc.py` —— MMA 描述符（smem desc 64-bit / instr desc 32-bit）
> - `copy_utils.py` —— TMA / bulk copy 的发起
> - `pipeline.py` —— CUTLASS Pipeline 封装（mbarrier 语义）
> - `flash_fwd_sm90.py` —— SM90 前向，TMA atom 创建 + pipeline 创建 + 生产/消费循环

---

## 0. 三者大小速查

| 结构 | 大小 | 谁造 | 编码层级 |
|------|------|------|----------|
| **TMA descriptor** (`CUtensorMap`) | **128 字节**，64B 对齐 | host (`cuTensorMapEncodeTiled`) | 描述"整张 GMEM tensor + 怎么切 box" |
| **wgmma smem descriptor** (Hopper) | **64-bit (8B)** | device 拼位 | 描述 smem 操作数的地址/swizzle/stride |
| **tcgen05 instruction descriptor** (Blackwell) | **32-bit (4B)** | device 拼位 | 描述 MMA 指令的 M/N、dtype、major 等 |
| **mbarrier** | **8 字节 (Int64)**，每 stage ×2 | smem 分配 + pipeline init | full/empty 一对，phase-parity 翻转 |

---

## 1. TMA descriptor —— host 端 encode，device 端 prefetch + 用

TMA descriptor（128B 的 `CUtensorMap`）**不在 device kernel 里手搓**，而是 host setup 阶段由
CuTeDSL 帮你 encode。它描述的是"整张 GMEM tensor + 怎么切 box"，**和具体哪个 tile 无关**——
取哪个 tile 由 device 端给坐标决定。

### (a) host 端构造：`make_tiled_tma_atom`

`flash_fwd_sm90.py:259-300`：

```python
gmem_tiled_copy_KV = cpasync.CopyBulkTensorTileG2SOp()   # 选 TMA copy op (G2S / S2G)
tma_atom_K, tma_tensor_K = cpasync.make_tiled_tma_atom(
    gmem_tiled_copy_KV,
    mK,                                       # 全局张量 (含 shape/stride)
    cute.select(self.sK_layout, mode=[0, 1]), # smem 目标 layout (含 swizzle)
    (self.tile_n, self.tile_hdim),            # box(tile) 形状
    1,                                        # multicast 数 (cluster mcast 才 >1)
)
```

`make_tiled_tma_atom` 内部去调 `cuTensorMapEncodeTiled`，把
**全局张量 base/size/stride + tile 形状 + element type + swizzle 模式** 打进那 128 字节。返回两个东西：

- `tma_atom`：拷贝时用的 atom（descriptor 句柄）
- `tma_tensor`：一个"TMA 视角"的张量，坐标系已按 box 重排，给 kernel 切 tile 用

提前算好每次搬多少字节（喂给 mbarrier 的 `tx_count`，见第 3 节），`flash_fwd_sm90.py:263-270`：

```python
self.tma_copy_bytes = {
    name: cute.size_in_bytes(mX.element_type, cute.select(layout, mode=[0, 1]))
    for name, mX, layout in [("Q", mQ, self.sQ_layout),
                             ("K", mK, self.sK_layout),
                             ("V", mV, self.sV_layout)]
}
```

### (b) device 端：先 prefetch descriptor

`flash_fwd_sm90.py:441-445`，进 kernel 第一件事，0 号 warp 把 descriptor 从 gmem 预取进 cache：

```python
if warp_idx == 0:
    for tma_atom in (tma_atom_Q, tma_atom_K, tma_atom_V, tma_atom_O):
        if const_expr(tma_atom is not None):
            cpasync.prefetch_descriptor(tma_atom)
```

### (c) device 端：发起拷贝

`copy_utils.py:324-360` `tma_get_copy_fn`，用 `cpasync.tma_partition` 把 atom + cta 坐标 +
smem/gmem tensor 绑好，返回闭包，循环里调：

```python
cute.copy(atom, src[None, src_idx], dst[None, dst_idx], tma_bar=...)
```

底层就是 `cp.async.bulk.tensor`，要带上一个 mbarrier 指针做完成通知（第 3 节）。

### (d) 旁路：裸 bulk copy（不走 descriptor）

cluster 内 smem→smem 等场景不需要 descriptor，`copy_utils.py:210-263` 直接手写 inline PTX 并自传 size：

```python
# cpasync_bulk_g2s
"cp.async.bulk.shared::cta.global.mbarrier::complete_tx::bytes [$1], [$0], $3, [$2];"
# cpasync_bulk_s2cluster (跨 CTA)
"cp.async.bulk.shared::cluster.shared::cta.mbarrier::complete_tx::bytes [$0], [$1], $3, [$2];"
```

---

## 2. smem descriptor —— device 端拼 64-bit（Hopper） / 32-bit instr desc（Blackwell）

`mma_sm100_desc.py` 把 CUTLASS C++ 的 `mma_sm100_desc.hpp` 移植成 Python。
**拼装分两步**：基址无关部分（每 stage 可复用）+ 基址部分（每 stage 重算）。

### (a) 基址无关部分：`make_smem_desc_base`（`mma_sm100_desc.py:212-282`）

输入 smem 的 2D layout + swizzle + major(K/MN)，输出 64-bit 里除地址外的所有字段：

1. `_layout_type(swizzle)`（`:191-209`）把 `cute.Swizzle(B,M,S)` 翻成硬件
   `SWIZZLE_NONE / 32B / 64B / 128B / 128B_BASE32B`
2. 从 canonical layout 推 **LBO (leading byte offset)** 与 **SBO (stride byte offset)**，单位 16B(uint128)
3. 打包（`:268-280`）：

| 字段 | bit 区间 |
|------|----------|
| leading_byte_offset (LBO) | [16:30) |
| stride_byte_offset (SBO) | [32:46) |
| version = 1 | [46:48) |
| base_offset = 0 | [49:52) |
| lbo_mode = 0 | [52:53) |
| layout_type (swizzle) | **[61:64)** 最高 3 bit |

### (b) 基址部分：`make_smem_desc_start_addr`（`:285-287`）

```python
return (start_addr.toint() & 0x3FFFF) >> 4   # 14-bit，单位 16B，所以 >>4
```

对应 bits [0:14)。kernel 里 `desc = base | start_addr`，换 stage 只重算地址再 OR。

### (c) 实战入口：`smem_desc_base_from_tensor`（`:290-296`）

直接从 smem tensor 取 swizzle，recast 成 uint128 layout，调 `make_smem_desc_base`。

### (d) Blackwell 不一样：32-bit instruction descriptor

`make_instr_desc`（`:111-162`）造的是 **32-bit idesc**，编码 M/N 维、a/b/c dtype、major、negate、
saturate、max_shift 等。打包要点（`:144-160`）：

```text
c_format  [4:6)   a_format [7:10)  b_format [10:13)
a_major   [15]    b_major  [16]
n_dim = N>>3  [17:23)        m_dim = M>>4  [24:29)
```

注意：这是 **tcgen05 MMA 的指令描述符**，不是 smem 地址描述符。Blackwell 累加器在 **TMEM**，
操作数寻址机制与 Hopper 64-bit smem desc 不同 —— 迁移代码常踩这个坑。
`mma_op_to_idesc`（`:165-174`）是从 `MmaOp` 直接生成 idesc 的便捷封装。

---

## 3. mbarrier —— smem 里 Int64，靠 CUTLASS Pipeline 封装

FA4 几乎不直接写 `mbarrier.init/arrive/wait` PTX，而用 CUTLASS 的 **Pipeline** 抽象
（`pipeline.py` 再包一层）。smem 分配和语义看得很清楚。

### (a) 在 smem struct 里分配（`flash_fwd_sm90.py:131-139`）

```python
mbar_ptr_Q_struct = cute.struct.MemRange[cutlass.Int64, 1 * 2]               # 1 stage
mbar_ptr_K_struct = cute.struct.MemRange[cutlass.Int64, self.num_stages * 2]
mbar_ptr_V_struct = cute.struct.MemRange[cutlass.Int64, self.num_stages * 2]
```

两个细节直接印证大小结论：

- **`cutlass.Int64` → 每个 mbarrier = 8 字节**
- **`* 2`** → 每个 pipeline stage 需要**两个** mbarrier：
  - `full`：数据搬好了，通知 consumer
  - `empty`：consumer 用完了，通知 producer 可以覆盖
- K/V 是 `num_stages * 2`，多级流水每级一对

### (b) 创建 pipeline = init mbarrier（`flash_fwd_sm90.py:457-465`）

```python
pipeline_k = pipeline_custom.PipelineTmaAsync.create(
    barrier_storage = storage.mbar_ptr_K.data_ptr(),  # 指向上面那块 smem
    num_stages      = self.num_stages,
    producer_group  = tma_warp,                        # 谁 arrive (TMA 单 warp)
    consumer_group  = mma_warps,                       # 谁 wait/release
    tx_count        = self.tma_copy_bytes["K"],        # 期望搬多少字节
    defer_sync      = True,
)
```

`tx_count` 就是 mbarrier 的 **expect-tx**：TMA 搬完 `tx_count` 字节后硬件自动 `complete_tx`，触发 full barrier。

### (c) 生产者 / 消费者用法

**Producer（TMA load warp）** —— `PipelineTmaAsync.producer_acquire`（`pipeline.py:304-327`）：

```python
self.sync_object_empty.wait(index, phase)                     # 等 buffer 空
self.sync_object_full.arrive_and_expect_tx(index, tx_count)   # 设好期望字节数
```

然后发 `cp.async.bulk.tensor`，把 `tma_bar = pipeline.producer_get_barrier(state)` 传进去
（`copy_utils.py:363-372`）。TMA 自己负责搬完 arrive。

**Consumer（MMA warps）** —— `flash_fwd_sm90.py:1284` 等：

```python
pipeline_k.consumer_wait(state, pipeline_k.consumer_try_wait(state))  # 等 full
# ... 用 sK 做 MMA ...
pipeline_k.consumer_release(state)                                    # arrive empty
```

### (d) index / phase 怎么转（`pipeline.py:38-83` `PipelineStateSimple`）

循环缓冲的 (index, phase) 用单个 Int32 `phase_index` 编码：

```python
index = phase_index % stages
phase = phase_index // stages
advance(): phase_index += 1        # stages==1 时直接 ^= 1 翻 phase
```

这就是 mbarrier 的 phase-parity 翻转机制。

### (e) 2CTA / cluster 特例

- 跨 CTA 通知时，用 `mapa.shared::cluster`（`copy_utils.py:147-163` `set_block_rank`）把 mbarrier 地址
  映射到 peer CTA，再发 `st.async.shared::cluster.mbarrier::complete_tx::bytes`（`:201`）/
  `cp.async.bulk.shared::cluster...`（`:234`）。
- `PipelineTmaUmma.producer_acquire`（`pipeline.py:340-377`）里 **只有 `is_leader_cta` 才 arrive**
  —— 对应 2CTA "仅 leader 发 MMA / arrive"。

---

## 4. 一句话脉络

- **TMA descriptor**：host encode 128B → device prefetch → `cp.async.bulk.tensor` + mbarrier 通知
- **smem desc**：device 拼 `base(swizzle/LBO/SBO) | start_addr(>>4)` 成 64-bit，喂 wgmma
- **mbarrier**：smem Int64 ×2/stage（full+empty），Pipeline 封装 acquire/wait/release，phase 翻转

> 另注：`barrier.py` 里的 `ld_acquire / red_release / wait_eq / arrive_inc` 是 **global memory 上的
> lock/flag**（split-KV combine 跨 block 同步用），**不是** smem mbarrier，别混淆。
