# CuTe DSL 入门：以 Elementwise Add 为例

## 一、概述

CuTe DSL 是 NVIDIA CUTLASS 项目中的 Python 领域特定语言，让开发者用 Python 语法编写高性能 GPU kernel。本文以最简单的 elementwise add 为例，串讲 CuTe DSL 的核心概念。

参考文档：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/dsl_introduction.html

---

## 二、完整代码

```python
import cute
import torch

# ============ 1. 准备数据 ============
M, N = 15, 25
A = torch.randn(M, N, device="cuda", dtype=torch.float16)
B = torch.randn(M, N, device="cuda", dtype=torch.float16)
C = torch.zeros(M, N, device="cuda", dtype=torch.float16)

mA = cute.from_dlpack(A)
mB = cute.from_dlpack(B)
mC = cute.from_dlpack(C)

# ============ 2. 定义布局 ============
thr_layout = cute.make_layout((2, 3), stride=(3, 1))   # 6 个线程的排布
val_layout = cute.make_layout((2, 2), stride=(2, 1))   # 每线程 4 个值

# ============ 3. 构造 TV layout 和 tiler ============
tiler_mn, tv_layout = cute.make_layout_tv(thr_layout, val_layout)

# ============ 4. 切分 tensor ============
gA = cute.zipped_divide(mA, tiler_mn)
gB = cute.zipped_divide(mB, tiler_mn)
gC = cute.zipped_divide(mC, tiler_mn)

# ============ 5. 坐标 tensor（边界检查用）============
cC = cute.make_identity_tensor(mC.shape)
cC = cute.zipped_divide(cC, tiler_mn)

# ============ 6. 构造 Copy Atom ============
copy_atom = cute.make_copy_atom(cute.nvgpu.CopyUniversalOp(), mA.element_type)

# ============ 7. Kernel 定义 ============
@cute.kernel
def elementwise_add_kernel(gA, gB, gC, cC, shape, thr_layout, val_layout):
    bidx = cute.arch.blockIdx.x
    tidx = cute.arch.threadIdx.x

    # 取当前 block 的 tile
    blkA = gA[:, bidx]
    blkB = gB[:, bidx]
    blkC = gC[:, bidx]
    cCi  = cC[:, bidx]

    # partition: 当前线程负责的元素
    thr_tAi = cute.local_partition(blkA, thr_layout, tidx, val_layout)
    thr_tBi = cute.local_partition(blkB, thr_layout, tidx, val_layout)
    thr_tCi = cute.local_partition(blkC, thr_layout, tidx, val_layout)
    thr_cCi = cute.local_partition(cCi,  thr_layout, tidx, val_layout)

    # 逐元素计算（带边界检查）
    for i in range(cute.size(thr_tCi)):
        if cute.elem_less(thr_cCi[i], shape):
            thr_tCi[i] = thr_tAi[i] + thr_tBi[i]

# ============ 8. Launch ============
elementwise_add_kernel(gA, gB, gC, cC, mC.shape, thr_layout, val_layout).launch(
    grid=[cute.size(gC, mode=[1]), 1, 1],
    block=[cute.size(tv_layout, mode=[0]), 1, 1],
)
```

---

## 三、知识点逐层拆解

---

### 知识点 1：`make_layout` — 布局的基本表示

```python
thr_layout = cute.make_layout((2, 3), stride=(3, 1))
```

- **Shape** `(2, 3)`: 二维逻辑形状，M 方向 2，N 方向 3
- **Stride** `(3, 1)`: 坐标到线性 index 的映射系数
- **映射公式**: `index = m * 3 + n * 1`

**默认 stride**：不指定则为列优先 (column-major)，即 `stride = (1, shape[0])`

```
thr_layout (stride=(3,1)):          默认 stride=(1,2):
       n=0  n=1  n=2                      n=0  n=1  n=2
m=0  [  0    1    2  ]              m=0  [  0    2    4  ]
m=1  [  3    4    5  ]              m=1  [  1    3    5  ]
```

> 例：`cute.make_layout((4, 8))` 的默认 stride 为 `(1, 4)`，列优先。

---

### 知识点 2：`make_layout_tv` — 构造 Thread-Value 映射

```python
tiler_mn, tv_layout = cute.make_layout_tv(thr_layout, val_layout)
```

**输入**：
- `thr_layout (2, 3)`: 线程在 tile 中的二维排布（共 6 个线程）
- `val_layout (2, 2)`: 每个线程负责的元素的二维排布（每线程 4 个值）

**输出**：

| 返回值 | 含义 | 计算方式 | 本例 |
|--------|------|----------|------|
| `tiler_mn` | Tile 尺寸 | `(thr_M×val_M, thr_N×val_N)` | `(4, 6)` |
| `tv_layout` | `(thread_id, value_id) → tile内偏移` | shape = `(T, V)` | `(6, 4)` |

**本质**：定义"一组线程如何集体覆盖一个 tile 的所有元素"。

**直观图示**（6 线程覆盖 4×6 tile）：

```
4×6 Tile 的数据所属关系:

         N=0    N=1    N=2    N=3    N=4    N=5
M=0    T0,v0  T1,v0  T2,v0  T0,v1  T1,v1  T2,v1
M=1    T0,v2  T1,v2  T2,v2  T0,v3  T1,v3  T2,v3
M=2    T3,v0  T4,v0  T5,v0  T3,v1  T4,v1  T5,v1
M=3    T3,v2  T4,v2  T5,v2  T3,v3  T4,v3  T5,v3
```

---

### 知识点 3：`zipped_divide` — 按 tile 切分 tensor

```python
gA = cute.zipped_divide(mA, tiler_mn)
# mA: (15, 25)  →  gA: ((4, 6), (4, 5))
#                        tile内   tile网格(RestM, RestN)
```

**作用**：将大 tensor 切成若干 tile，重组为两级结构：
- 第 1 模态 `(TileM, TileN)`: tile 内部坐标 — 交给线程分配
- 第 2 模态 `(RestM, RestN)`: tile 网格坐标 — 用 blockIdx 索引

**"Zipped" 的含义** — 就是 Python `zip()` 的概念，对模态做转置重组：

```python
logical_divide → ((TileM, RestM), (TileN, RestN))   # 各维度独立切分
zipped_divide  → ((TileM, TileN), (RestM, RestN))   # zip 重组
                   内部们打包       索引们打包
```

**直观图示**（15×25 按 4×6 切）：

```
┌──────┬──────┬──────┬──────┬──────┐
│(0,0) │(0,1) │(0,2) │(0,3) │(0,4) │  ← tile 行 0
│ 4×6  │ 4×6  │ 4×6  │ 4×6  │ 4×1! │
├──────┼──────┼──────┼──────┼──────┤
│(1,0) │(1,1) │      │      │      │  ← tile 行 1
├──────┼──────┼──────┼──────┼──────┤
│(2,0) │      │      │      │      │  ← tile 行 2
├──────┼──────┼──────┼──────┼──────┤
│(3,0) │      │      │      │ 3×1!!│  ← tile 行 3 (只有 3 行有效)
└──────┴──────┴──────┴──────┴──────┘
```

**索引方式**：
```python
tile_data = gA[:, (i, j)]    # 取第 (i,j) 个 tile，shape = (TileM, TileN)
element = gA[(m, n), (i, j)] # tile(i,j) 内的 (m,n) 位置
```

---

### 知识点 4：Identity Tensor — 坐标追踪与边界检查

```python
cC = cute.make_identity_tensor(mC.shape)   # cC[m,n] = (m, n)
cC = cute.zipped_divide(cC, tiler_mn)      # 同样的切分
```

**为什么需要？**

当 tensor 尺寸不能被 tile 整除时，最后的 tile 会越界。经过复杂的 layout 变换后，无法用简单的 index 判断是否越界。

**解决方案**：创建坐标 tensor，对它做完全相同的变换，最后判断坐标是否在范围内：

```python
# kernel 中：
if cute.elem_less(thr_cCi[i], shape):   # 即 m < M 且 n < N ?
    thr_tCi[i] = thr_tAi[i] + thr_tBi[i]
```

> 如果能保证 M、N 被 tile 整除，则可以省略 identity tensor 和边界检查。

---

### 知识点 5：`@cute.kernel` — Kernel 定义与启动

```python
@cute.kernel
def elementwise_add_kernel(gA, gB, gC, cC, shape, thr_layout, val_layout):
    ...
```

- 将 Python 函数 **JIT 编译**为 CUDA kernel
- 首次调用时编译，后续复用缓存
- 函数体内可用 `cute.arch.threadIdx`、`cute.arch.blockIdx` 等 GPU 内置变量
- 支持 CuTe 全套布局代数原语

**启动方式**：

```python
elementwise_add_kernel(...).launch(
    grid=[num_tiles, 1, 1],
    block=[num_threads, 1, 1],
)
```

---

### 知识点 6：Launch 配置的计算

```python
grid  = [cute.size(gC, mode=[1]), 1, 1]       # tile 总数
block = [cute.size(tv_layout, mode=[0]), 1, 1] # 每 block 线程数
```

| 参数 | 取值 | 来源 |
|------|------|------|
| `grid.x` | `RestM × RestN` = 20 | `gC` 的第 2 模态大小（总 tile 数）|
| `block.x` | 6 | `tv_layout` 的第 1 模态（T 维度）大小 |

**对应关系**：每个 block 处理一个 tile，block 内有 6 个线程。

---

### 知识点 7：Kernel 内部 — 两级索引

```python
# 第 1 级：blockIdx 选 tile
blkA = gA[:, bidx]          # shape = (TileM, TileN) = (4, 6)

# 第 2 级：threadIdx 分元素
thr_tAi = cute.local_partition(blkA, thr_layout, tidx, val_layout)
                             # shape = (2, 2) = 当前线程的 4 个元素
```

**数据流层级**：
```
全局 tensor (15×25)
  └─ zipped_divide → tile 网格 (4×5 = 20 个 tile)
       └─ blockIdx.x → 1 个 tile (4×6)
            └─ local_partition → 当前线程的 4 个元素 (2×2)
```

---

### 知识点 8：`local_partition` — 线程取自己的数据

```python
thr_tAi = cute.local_partition(blkA, thr_layout, tidx, val_layout)
```

内部逻辑：
1. 用 `thr_layout` 将 `tidx` 映射到 tile 中的二维起始位置
2. 从起始位置出发，按 `val_layout` 的模式取出多个元素
3. 返回当前线程独占的子 tensor（shape = val_layout 的 shape）

等价理解：`thr_tile[tv_layout[tidx]]` — 用 tv_layout 查表获取当前线程的元素偏移。

---

### 知识点 9：`make_copy_atom` — 定义搬运指令

```python
copy_atom = cute.make_copy_atom(cute.nvgpu.CopyUniversalOp(), mA.element_type)
```

Copy Atom 是数据搬运的最小原子操作，定义了用什么硬件指令搬什么类型的数据。

| 参数 | 含义 | 本例 |
|------|------|------|
| 第 1 参数 (Op) | 硬件搬运指令 | `CopyUniversalOp()` — 通用 ld/st |
| 第 2 参数 (dtype) | 数据类型 | `float16` |

**常用 Op 列表**：

| Op | 硬件指令 | 场景 |
|----|----------|------|
| `CopyUniversalOp()` | `ld.global/st.global` | 通用标量搬运 |
| `CpAsyncOp()` | `cp.async` | Ampere: gmem→smem 异步 |
| `LdMatrixOp()` | `ldmatrix` | smem→rmem, 匹配 Tensor Core |
| `TmaLoadOp()` | TMA | Hopper: 硬件整 tile 搬运 |

**层级关系**：
```
Copy Atom (单线程, 单次, 几个元素)
    ↓  + thr_layout + val_layout
TiledCopy (多线程, 协作搬一个 tile)
    ↓  + loop over tiles
完整搬运 (覆盖整个 tensor)
```

---

### 知识点 10：`make_rmem_tensor_like` — 寄存器 Fragment

```python
thrA = thr_copy_A.partition_S(blkA)       # 当前线程在 gmem 中负责的视图
frgA = cute.make_rmem_tensor_like(thrA)   # 在寄存器中开同 shape 的空间

cute.copy(tiled_copy_A, thrA, frgA)       # gmem → register
# ... 在寄存器中计算 ...
cute.copy(tiled_copy_C, frgC, thrC)       # register → gmem
```

**为什么需要？**

GPU 计算只能在寄存器上进行。Global memory 延迟 ~400 cycles，寄存器 ~1 cycle。

```
Global Memory (HBM)     — 容量大, 延迟高
  └→ Shared Memory      — 容量中, 延迟低 (可选中转)
       └→ Register      — 容量小, 速度最快 ← fragment 在这里
```

**关键术语**：
- `partition_S`: Source 端分配（我该从哪搬）
- `partition_D`: Destination 端分配（我该往哪写）
- `fragment`: 一个线程在寄存器中持有的那小块数据

---

## 四、总结：CuTe DSL 写 Kernel 的标准范式

```
┌─────────────────────────────────────────────────────┐
│  Step 1: 定义布局                                    │
│    thr_layout → 线程怎么排                           │
│    val_layout → 每线程管多少元素                      │
│    make_layout_tv → 得到 tiler + tv_layout           │
├─────────────────────────────────────────────────────┤
│  Step 2: 切分 tensor                                 │
│    zipped_divide(tensor, tiler)                      │
│    → ((tile内), (tile网格))                          │
├─────────────────────────────────────────────────────┤
│  Step 3: Kernel 内两级索引                            │
│    blockIdx  → 选 tile                              │
│    threadIdx → local_partition 选元素                │
├─────────────────────────────────────────────────────┤
│  Step 4: 计算 + 边界检查                             │
│    identity_tensor + elem_less 防越界                │
│    在寄存器 (fragment) 中完成计算                     │
├─────────────────────────────────────────────────────┤
│  Step 5: Launch                                     │
│    grid  = tile 总数                                │
│    block = 线程数 (tv_layout mode[0])               │
└─────────────────────────────────────────────────────┘
```

这套范式从简单的 elementwise add 到复杂的 GEMM/FlashAttention 都适用：
- **GEMM**：多了 smem 中转 + MMA 计算 + K 维度循环
- **FlashAttention**：多了 softmax + K/V 的循环 tile
- 但骨架（切分 → 分配 → 搬运 → 计算）完全一致
