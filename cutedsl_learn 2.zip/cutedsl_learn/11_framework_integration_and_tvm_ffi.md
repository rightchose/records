# CuTe DSL 框架集成 + TVM FFI（学习笔记）

> 来源：
> - https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/framework_integration.html
> - https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/compile_with_tvm_ffi.html
> 主题：torch.Tensor 怎么进 CuTe DSL kernel（DLPack）、static vs dynamic layout 在「框架边界」的落地、以及用 TVM FFI 削掉 host 端调用开销。

---

## 〇、一句话总览

```
torch.Tensor ──进 CuTe kernel──▶ 两条路：
  ① 隐式（直接传）   → 走 DLPack → fully DYNAMIC layout  （省事，但每次有转换开销）
  ② 显式（from_dlpack）→ fully STATIC layout            （可缓存复用 + 可精细放开某些维）

更快一档：TVM FFI —— 直接吃 torch.Tensor，把 shape 描述/校验/stream 全前移到编译期，
                     运行时只剩最薄的直传调用。
```

⚠️ **关键订正（一开始我说反了）**：**隐式直传 = dynamic，`from_dlpack` 显式 = static。** 决定 static/dynamic 的是「转换时机/方式」，不是「cute vs torch」。

---

## 一、隐式 vs 显式转换（核心区分）

| | 隐式（直接把 torch tensor 传进 JIT 函数） | 显式（`from_dlpack`） |
|---|---|---|
| 写法 | `kernel(torch_tensor)` | `from_dlpack(tensor)` |
| 产物 layout | **dynamic**：`(?,?,?):(?,?,1)`，除 leading dim 的 stride（=1）外全动态 | **fully static**：shape/stride 全编译期静态 |
| 拷贝 | — | 零拷贝，共享原内存 |
| 直觉 | DSL 啥都不假设 → 全动态（一份 kernel 吃多尺寸） | 把当前形状/步长焊成静态（针对该尺寸特化，约束最强、优化最好） |

隐式转换保留 leading dimension 的 stride：
```
ptr<f32, generic> o (?,?,?):(?,?,1)     # 末维 stride=1 保留，其余全 ?
```

显式 `from_dlpack(tensor, assumed_align=None, use_32bit_stride=False)` → fully static：
```python
y = from_dlpack(torch.randn(30,20))
y.shape        # (30, 20)
y.stride       # (20, 1)
y.element_type # Float32
```

> 呼应 dynamic_layout 页：static layout 把具体 shape/stride 焊进 IR（特化、更优化、但换尺寸要重编译）；dynamic layout 一份 kernel 通吃多尺寸。

---

## 二、When to Use Explicit Conversion？（为什么要费劲手动 from_dlpack）

两个动机：

### 动机 1：避开 DLPack 开销（性能）
```
每次 from_dlpack 调用 ≈ 2~3 us 开销
```
隐式 = 每次调 kernel 都隐式 from_dlpack 一遍 → 每次吃 2~3us。显式可**缓存转换好的 cute tensor 复用**，cache 命中就跳过：
```python
cache = {}
def run(t):
    if t not in cache:
        cache[t] = from_dlpack(t)   # miss 才转一次
    kernel(cache[t])                # hit 直接复用，零转换开销
```

### 动机 2：对「哪些 mode 算 dynamic」做细粒度控制
隐式给的是固定结果（leading stride=1、其余全 dynamic），没得选。显式 + `mark_*` 系列可精确指定每一维 static/dynamic + divisibility。

---

## 三、`mark_layout_dynamic` —— 把 static layout「整块再放开」

**需求来源**：`from_dlpack` 默认 fully static（最优化但最专用，换尺寸就重编译）。想要**一份编译产物服务多种尺寸**，就用它把 layout 放开成 dynamic。

```python
def mark_layout_dynamic(self, leading_dim: int | None = None):
```

**行为**：所有 **shape** 维放开成动态；**stride** 除两类外全放开 ——
- leading dimension 的 stride 固定 = 1（连续访存关键）
- stride-0（broadcast）维保留

```python
from_dlpack(a).mark_layout_dynamic()   # (?,?,?,?):(?,?,?,1)
from_dlpack(d).mark_layout_dynamic()   # (?,?,?,?):(?,0,0,1)   ← broadcast 维(0)保留
```

### `leading_dim` 参数干啥 —— 只管「哪一维 stride 钉成 1」，不管 shape
（⚠️ 易错：`leading_dim` 控制的是 stride，不是 shape；shape 永远全放开）

同一个 b、只换 leading_dim → **shape 部分都是 `(?,?,?,?,?)` 完全一样，只有 stride 里那个「1」的位置变**：
```python
from_dlpack(b).mark_layout_dynamic(leading_dim=0)  # (?,?,?,?,?):(1,?,?,?,?)
from_dlpack(b).mark_layout_dynamic(leading_dim=2)  # (?,?,?,?,?):(?,?,1,?,?)
```

**默认 None → 自动推断**：
1. 恰好一维 stride==1 → 它是 leading
2. 多维 stride==1 → 仅当其中恰好一维 size>1 才成功（PyTorch 会把 size-1 维 stride 规范成 1）
3. 没有 stride==1 维 → 所有 stride 保持 dynamic

支持负索引（`-1` = 最后一维）。报错例：
```python
from_dlpack(torch.ones(1,1,1)).mark_layout_dynamic()   # ❌ Can't deduce the leading dimension
from_dlpack(a).mark_layout_dynamic(leading_dim=1)       # ❌ Expected strides[leading_dim]==1, but got 16
```

### 关于打印里的 `?{i64}`
```
?{i64}
│  └ i64 = 这个动态整数的位宽 64-bit（因 use_32bit_stride 默认 False，防 cosize 溢出）
└── ? = 运行时才知道的动态值
```
`{i64}` 不是 divisibility 约束，是**整数位宽标注**。别的例子打成裸 `?` 只是省略了位宽，本质一样；设 `use_32bit_stride=True` 会变 `?{i32}`。

---

## 四、`mark_compact_shape_dynamic` —— 只放开「某一维」+ 带 divisibility

```python
def mark_compact_shape_dynamic(self, mode: int, stride_order=None, divisibility: int = 1):
```

**vs `mark_layout_dynamic`**：后者一把全放开 shape；这个**只放开 `mode` 指定的那一维**，其余维保持静态特化。

**典型场景**：varlen / 动态 shape kernel —— 只有 seqlen 维变化，其它维（head_dim 等）固定 → 只放开 seqlen 那一维，其余维保持静态拿满优化。

```python
# a: (8,4,16,2):(2,16,64,1)
from_dlpack(a).mark_compact_shape_dynamic(mode=0, divisibility=2)
# (?{div=2},4,16,2):(2,?{div=4},?{div=16},1)
#  └ mode0 放开      └ 4,16,2 还是静态！
```

### 核心增值：能带 divisibility，且会传播到相关 stride
放开 mode=0(div=2) 不只改它自己 shape，还把约束传到「乘积里含这一维」的下游 stride（实证 06 笔记的 divisibility propagation）：
```
mode=0 (div=2) → 该维 shape = ?{div=2}
              → 原 stride 16 → ?{div=4}
              → 原 stride 64 → ?{div=16}
```
链式调用多个 stride 都挂 div 标签：
```python
# 连续放开 mode1 + mode3
(8,?{div=2},16,?{div=2}):(?{div=2},?{div=16},?{div=32},1)
```

### 三个参数
| 参数 | 作用 |
|------|------|
| `mode` | 选哪一维 shape 变动态（stride 随之更新；size-1 维 stride 规范成 0） |
| `stride_order` | 指定各维内外层顺序（外→内、左→右，同 `torch.dim_order()`）。**必要时手动指定** |
| `divisibility` | 该动态维的整除约束，默认 1 |

### `stride_order` 干啥 + 何时必须手动给
放开一维后，compact 布局下**其余维 stride 要重新推导**（stride=内层各维 size 之积），必须知道维度内外顺序 → 这就是 `stride_order`。
```
自动推断 = 把各维 stride 降序排
  └ ✅ 各 stride 不同 → 唯一定序
  └ ❌ 多个维 stride 都=1（顺序分不清）→ 推断失败，必须显式给
```
**判断口诀**：有且仅有一维 stride==1（常规连续 tensor）→ 不用管；出现多个 stride==1 维（含 size-1 维、或被 permute/expand 过）→ 手动喂（最简单 `b.dim_order()`）。
```python
from_dlpack(b).mark_compact_shape_dynamic(mode=0, div=4)   # ❌ could not be deduced, specify stride_order
from_dlpack(b).mark_compact_shape_dynamic(mode=0, div=4, stride_order=b.dim_order())  # ✅
```

### 前提：只对 compact tensor 可用
非 compact tensor → 改用 **`cute.assume`** 在 host JIT 函数里给某 shape mode 附 divisibility。

---

## 五、两个 mark_* 接口对照

| | `mark_layout_dynamic` | `mark_compact_shape_dynamic` |
|---|---|---|
| shape 放开范围 | **所有**维 | **指定的一个** mode |
| 选维参数 | `leading_dim`（只钉 stride=1 位置） | `mode`（选哪维放开） |
| 带 divisibility | ❌ | ✅（且传播到 stride） |
| 适用 | 一份 kernel 通吃所有尺寸 | 只放开变化维（如 seqlen），其余维特化 + 保 div 优化 |
| 前提 | 任意 layout | **仅 compact**（非紧凑用 `cute.assume`） |

---

## 六、其它参数

- **`assumed_align`**：基址按多少字节对齐（基址须能被它整除），默认元素类型自然对齐
- **`use_32bit_stride`**：默认 False（64 位防 cosize 溢出）；小问题 `cosize ≤ Int32_MAX` 时设 True 省寄存器提性能，仅影响 dynamic layout，带运行时溢出检查
  ```python
  c = torch.empty(1000000000, 1000000000)
  from_dlpack(c, use_32bit_stride=True).mark_layout_dynamic()
  # ❌ Layout ... has int32 overflow risk. Please set use_32bit_stride to False.
  ```

---

## 七、Leveraging TVM FFI（framework_integration 页里的「导引小节」）

这一节只是**广告 + 指路牌**，不给 API/代码：
- 解决：DLPack 转换 + JIT 调用的 **host 端互操作开销**
- TVM FFI = 「一套 ML 系统的开放 ABI/FFI」，让 DSL 更好地和 PyTorch 等框架互操作
- 4 条好处：**更快的 JIT 调用 / 直接吃 torch.Tensor / 更好的报错&校验 / 跨语言无缝集成**
- 细节 → 跳到 `compile_with_tvm_ffi.html`（呼应 JIT 编译选项页的 `enable-tvm-ffi`）

---

## 八、Compile with TVM FFI（实操页）

核心：**让 JIT 函数直接吃 `torch.Tensor`、走优化调用路径，省掉 DLPack 转换那层 host 开销。**

### 8.1 怎么开
```bash
pip install apache-tvm-ffi
pip install torch-c-dlpack-ext   # 可选，torch tensor 调用更快
```
```python
cute.compile(fn, ..., options="--enable-tvm-ffi")   # 方式1
# 或 环境变量全局开（影响所有 JIT 编译）：
CUTE_DSL_ENABLE_TVM_FFI=1                            # 方式2
# 适配 cute.Tensor：
from_dlpack(a_torch, enable_tvm_ffi=True).mark_layout_dynamic()
```

### 8.2 配套核心：Fake Tensor（占位张量）
只含 shape/type/layout、**没有真数据**（索引它会报错）的编译期占位：
```python
n = cute.sym_int()                                          # 动态维（可带 divisibility）
a_cute = cute.runtime.make_fake_compact_tensor(cute.Float32, (n,))
compiled = cute.compile(add_one, a_cute, b_cute, options="--enable-tvm-ffi")
compiled(torch.arange(10, dtype=torch.float32, device="cuda"), b_torch)  # 直接喂 torch.Tensor
```
思路 = 用 fake tensor 声明 shape 约束、编译一次 → 之后反复直传真 torch tensor 复用。

### 8.3 Minimizing Host Overhead（五步配方）

核心思想：**把能搬到编译期的活（shape 描述/校验/stream 选择）全搬走，每次调用只剩最薄的直传。**

| 步骤 | 搬到编译期的 | 每次调用省掉的 host 活 |
|------|-------------|----------------------|
| 1 开 TVM FFI | — | （地基，启用优化路径） |
| 2 fake tensor 声明 shape | shape 约束描述 | 重编译 + 参数 setup |
| 3 直传 torch.Tensor | — | DLPack 转换（2~3us） |
| 4 env stream | stream 选择 | 显式传 stream 参数 |
| 5 编译进校验 | 校验逻辑 | Python 端属性检查 |

**步骤 4（env stream）**：编译期标 env stream，运行时自动取当前 PyTorch stream（调用前 sync 到 `torch.cuda.current_stream()`）：
```python
stream = cute.runtime.make_fake_stream(use_tvm_ffi_env_stream=True)
compiled = cute.compile(add_one_with_stream, a_cute, b_cute, stream, options="--enable-tvm-ffi")
with torch.cuda.stream(torch.cuda.current_stream()):
    compiled(a_torch, b_torch)   # 不用显式传 stream
```

**步骤 5（编译进校验）**：type/shape/divisibility/alignment 校验编进函数，「跑得极快、无可观测开销」，出错抛精确异常（`TypeError`=类型不符，`ValueError`=shape/divisibility/alignment 不符，`RuntimeError`=CUDA 错误）：
```python
n = cute.sym_int(divisibility=16)
a_cute = cute.runtime.make_fake_compact_tensor(cute.Float32, (n,), assumed_align=16)
```

### 8.4 还能导出 .so（AOT 雏形）
```python
compiled.export_to_c("./add_one.o", function_name="add_one")   # 导出符号 __tvm_ffi_add_one
mod = cute.runtime.load_module("./add_one.so", enable_tvm_ffi=True)
```

### 8.5 ⚠️ 最大的坑
```
fake tensor 流程「只」和 TVM FFI 兼容 —— 产生的 ABI 跟 from_dlpack 不同
   → 混用报 "incompatible ABI"
```
而且 `from_dlpack` 通常只转一次就编译+运行都复用，所以**不开 TVM FFI 的话 fake tensor 没啥收益**。不想用 TVM FFI 的底层 AOT，另见 "Ahead-of-Time (AOT) Compilation" 专页。性能：全是定性描述，无 benchmark 数字。

---

## 九、一句话总结

> **torch.Tensor 进 CuTe DSL 有两条路：隐式直传 = DLPACK + fully DYNAMIC layout（省事、每次 2~3us 转换开销）；显式 `from_dlpack` = fully STATIC layout（零拷贝，可缓存复用、可用 `mark_*` 精细放开某些维）。** 放开维度有两个接口：`mark_layout_dynamic`（整块放开 shape，`leading_dim` 只钉 stride=1 的位置）和 `mark_compact_shape_dynamic`（只放开某一维 + 带 divisibility 且传播到 stride，仅 compact tensor，必要时手动给 `stride_order`）。**再快一档用 TVM FFI**：`--enable-tvm-ffi` + fake tensor 声明 shape、直传 torch.Tensor、env stream、编译进校验——把活前移到编译期、运行时只剩最薄直传；代价是自成一套 ABI，不能和 `from_dlpack` 混用。
