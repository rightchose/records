# CuTe DSL AOT 编译（Ahead-of-Time Compilation 学习笔记）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/dsl_ahead_of_time_compilation.html
> 主题：把 JIT 的"运行时编译"反过来——提前把 Python kernel 编成 `.h`+`.o`，链进 C/C++ 或离线给 Python 加载，生产零编译延迟。是 JIT/caching 路线的**镜像补充（交付形态）**。

---

## 〇、一句话总览

```
JIT  = 用时才编（绑 Python，首次有编译延迟，能运行时 autotune/特化）
AOT  = 先编好再发货（可纯 C/C++，零延迟，但配置在构建期就焊死）

本质：AOT 用「构建期确定性 + 部署轻量」换「运行时灵活性」。
开发期用 JIT 灵活迭代+autotune，定稿后用 AOT 固化发货。
```

---

## 一、先想清楚：AOT 的优势 vs 问题（比复述卖点更重要）

### 优势（及背后动机）

| 优势 | 为什么重要 |
|------|-----------|
| **干掉 JIT 首次编译延迟** | 在线服务/推理对冷启动+尾延迟敏感；JIT 编译延迟砸在"第一个请求"或"换 shape 触发新变体编译"那刻 → 对 SLA 是灾难。AOT 把这块从运行时挪到构建时 |
| **脱离 Python，嵌纯 C/C++** | 很多推理引擎/嵌入式/车载是纯 C++，不想引入 Python 解释器。JIT 强绑 Python，AOT 产 `.h`/`.o` 直接链——这是**部署形态**的质变 |
| **Compile once, cross-compile** | 提前为 sm_90/sm_100/... 各编一份，目标机不需装工具链 |
| **可审计/可复现** | 产物落盘、版本固定、可签名、可进 CI artifact，不随环境漂移 |

### 问题（更值得提前警惕）

| 问题 | 根因 / 后果 |
|------|------------|
| **⚠️ 丢了 autotuning 灵活性** | autotuning 的威力来自"用真实输入挑参数"（12 笔记），但 AOT 必须在**不知道真实输入的构建期**锁死配置 → 要么枚举所有 shape（产物爆炸），要么只编几个通用变体（牺牲峰值）。**AOT 和 autotuning 是张力关系** |
| **⚠️ `cute.Tensor` ABI 不固定** | dynamic layout 后遗症：tensor 是动态类型，不同次编译可能产生不同 C 结构体布局 → 头文件得「每个 tensor 类型单独声明一个」。C++ 集成变脆，手填 shapes/strides 易错 |
| **⚠️ 版本/CUDA 兼容地狱** | `.o` 绑特定 CUDA runtime 版本，不匹配 ABI 不保证。**不是"编一次到处跑"**，升级 CUDA 就得重新 export，运维持续负担 |
| **不支持自定义类型** | JIT 能用 `JitArgument`/adapter 接第三方类型（09 笔记），AOT 明确**不支持**，灵活性砍一截 |
| **失去运行时特化** | 导出后所有 Constexpr 已焊死；换 head_dim/is_causal 组合得重新 export。变体管理从"运行时按需"变"构建期全量" |

### 权衡表
| 维度 | JIT | AOT |
|------|-----|-----|
| 首次延迟 | ❌ 有 | ✅ 零 |
| 部署形态 | 绑 Python | ✅ 可纯 C/C++ |
| autotuning | ✅ 真实输入挑最优 | ❌ 构建期猜 |
| 自定义类型 | ✅ | ❌ |
| 运行时特化 | ✅ 按需 | ❌ 已焊死 |
| 版本耦合 | 松（现编） | ❌ 绑死 CUDA 版本 |

> **AOT 的甜区**：输入 shape 范围已知且收敛、配置已通过 JIT autotune 锁定、要部署到纯 C++/低延迟生产环境。FA4 的 `_TUNING_CONFIG` 就是"JIT 调好 → 固化"的中间形态，AOT 把这步推到二进制级别。

---

## 二、两个 ABI 层级

| 层级 | 用谁的类型 | 用途 |
|------|-----------|------|
| **Low-Level CuTe ABI**（本页重点） | cute.Tensor 等 DSL 类型 | 镜像原 Python 接口，参数必须是 cute.Tensor |
| **High-Level TVM FFI ABI** | 框架类型（可直接传 torch.Tensor） | 框架互操作，稳定高层 ABI（见 11 笔记 TVM FFI） |

→ 框架集成更推荐 TVM FFI AOT（稳定、直接吃 torch.Tensor）；CuTe ABI AOT 适合**两端完全自控、要极致控制**的场景。

---

## 三、核心 API

**导出**：`export_to_c`（`JitCompiledFunction` 的方法）
```python
compiled_func.export_to_c(file_path, file_name, function_prefix)
# function_prefix 默认=file_name，必须唯一（防符号冲突）
```

**产物两个文件**：
- `{file_name}.h` —— C 头文件，声明运行时函数签名（镜像 Python 接口）
- `{file_name}.o` —— 目标文件，含 host entry function、fatbin data、`cuda_init`/`cuda_load_to_device` 等 helper + 版本校验元数据。可链成 static/shared lib

**C/C++ 动态加载运行时 API**（`CuteDSLRuntime.h`）：
```
CuteDSLRT_Module_Load          加载模块
CuteDSLRT_Module_Get_Function  取函数（也加载 CUDA module）
CuteDSLRT_Function_Run         运行
CuteDSLRT_Module_Destroy       销毁
CuteDSLRT_Error_t              错误状态类型
```

**静态链接生成的符号**（前缀来自 `function_prefix`，如 `print_tensor`）：
`print_tensor_Kernel_Module_t` / `print_tensor_Tensor_a_t`（tensor 专属 ABI 类型）/ `cute_dsl_print_tensor_wrapper`（入口）/ `print_tensor_Kernel_Module_Load`/`_Unload`

---

## 四、完整工作流

### 1) 导出（Python）
```python
import cutlass.cute as cute
import cutlass.cute.cuda as cuda

@cute.kernel
def print_tensor_kernel(a: cute.Tensor):
    cute.printf("a: {}", a)

@cute.jit
def print_tensor(a: cute.Tensor, stream: cuda.CUstream):
    print_tensor_kernel(a).launch(grid=(1,1,1), block=(1,1,1), stream=stream)

compiled_func = cute.compile(print_tensor)
compiled_func.export_to_c(file_path="./artifacts",
                          file_name="print_tensor_example",
                          function_prefix="print_tensor")
```

### 2) 三种集成方式
| 方式 | 怎么用 | 版本安全性 |
|------|--------|-----------|
| **C++ 静态链接** | include `.h` + 链 `.o`，编进可执行文件 | ✅ 头/目标一起生成，保证匹配 |
| **C++ 动态加载** | 运行时用 `CuteDSLRT_*` API 加载 `.so`/`.o` | 元数据嵌版本号，运行时校验，不匹配拒绝 |
| **Python 加载** | `cute.runtime.load_module(...)` 按导出名调 | 同上，运行时校验 |

**Python 加载**：
```python
module = cute.runtime.load_module("./artifacts/print_tensor_example.o")
# 或 .../libprint_tensor_example.so
a_cute = from_dlpack(torch.arange(160, dtype=torch.float32, device="cuda")
                     .reshape(16,10)).mark_layout_dynamic()
module.print_tensor(a_cute, stream=cuda.CUstream(0))   # 按导出名直接调，无需 JIT
```

**C++ 动态加载**：
```c
CuteDSLRT_Module_Load(&module, "./artifacts/libprint_tensor_example.so");
CuteDSLRT_Module_Get_Function(&func, module, "print_tensor");
// 填 tensor 参数结构体：data=nullptr, dynamic_shapes[0]=32/[1]=16, dynamic_strides[0]=16 ...
int ret;
void* args[] = {&tensor_a, &stream, &ret};
err = CuteDSLRT_Function_Run(func, args, 3);
cudaStreamSynchronize(stream);
CuteDSLRT_Module_Destroy(module);
```

**链接依赖**（页里给的是库要求，**无 gcc 命令行**）：
- 静态链接需 `libcuda_dialect_runtime.so`（或 `.a`）
- 动态加载需 `libcute_dsl_runtime.so`
- 都在 `<wheel_install_path>/lib`；`CuteDSLRuntime.h` 在 `<wheel_install_path>/include`；外加 CUDA driver/runtime

---

## 五、和 TVM FFI 的关系

```
AOT 两条路：
  本页 = Low-Level CuTe ABI → 参数必须是 cute.Tensor
  TVM FFI AOT               → 生成 TVM FFI 调用约定的 wrapper，可直接传 torch.Tensor
```
能力相当（都编成二进制运行时加载），区别在**接口层级**：TVM FFI 生成专门 wrapper 能吃 torch.Tensor；CuTe ABI 入口只收 cute.Tensor。

---

## 六、注意事项（坑）

- **版本/CUDA 兼容**：`.o` 依赖 CUDA runtime，版本必须和 CuTe DSL 一致。静态链接安全；动态/Python 加载靠元数据版本号运行时校验，不匹配直接拒绝
- **`cute.Tensor` ABI 不固定**：动态类型只含 dynamic shape/stride，不同次编译可能不同 → 头文件每个 tensor 类型单独声明一个（如 `print_tensor_Tensor_a_t`）
- **`use_32bit_strides`**：控制 cute.Tensor 里 stride 位宽（True=32 位/False=64 位，呼应 11 笔记 `?{i64}`）
- **不支持自定义类型 AOT**
- **支持的参数类型**：cute.Tensor、cute algebra 类型(Shape/Coord/Tile/IntTuple/Stride)、cuda.CUstream、整数/浮点标量

---

## 七、串联（JIT 与 AOT 是一枚硬币的两面）

```
JIT 路线（之前所有页）              AOT 路线（这页）
用时才编译                   vs    先编好发货
cute.compile → 内存 executor       cute.compile → export_to_c → .h/.o 落盘
首次调用有编译延迟                  生产零编译延迟
绑当前 Python 进程                 可脱离 Python，嵌 C/C++
靠 JIT cache 复用                 靠版本元数据保证加载兼容
运行时 autotune/特化              构建期焊死配置
```

`export_to_c` 本质 = **把 JIT 在内存里造好的编译产物序列化到磁盘 + 配一个 C ABI 入口**。它最大的工程麻烦（`cute.Tensor` ABI 不固定、每次编译可能不同）正是 11 笔记 dynamic layout 的后遗症——tensor 动态，C 结构体布局随产物走，所以头文件"一个 tensor 类型一个声明"。

---

## 八、一句话总结

> **AOT = 把 JIT 的运行时编译提前到构建期**：`cute.compile` 后用 `export_to_c` 产 `.h`+`.o`，经 C++ 静态链接 / C++ 动态加载(`CuteDSLRT_*`) / Python `load_module` 三种方式集成，生产零编译延迟、可脱离 Python 嵌 C/C++。代价是**用运行时灵活性换构建期确定性**——丢了 autotuning/运行时特化/自定义类型，还绑死 CUDA 版本、`cute.Tensor` ABI 不固定。甜区是"shape 收敛 + 配置已 autotune 锁定 + 纯 C++ 低延迟生产"；典型用法是开发期 JIT 迭代调优、定稿后 AOT 固化发货（如 FA4 `_TUNING_CONFIG` 的二进制级延伸）。
