# CuTe DSL 学习笔记 — elementwise_apply.py

基于 `cutlass/examples/python/CuTeDSL/cute/ampere/kernel/elementwise/elementwise_apply.py` 的学习总结。

---

## 1. 两层函数结构

| 装饰器 | 角色 | 执行位置 |
|--------|------|----------|
| `@cute.jit` | Host 端编排：构造 layout、切分 tensor、launch kernel | CPU（编译期） |
| `@cute.kernel` | Device 端逻辑：每个线程执行的实际计算 | GPU（运行期） |

---

## 2. 核心 API

### 2.1 `from_dlpack(tensor, assumed_align=16)`
- 把 PyTorch tensor 零拷贝转为 CuTe Tensor（共享 GPU 内存）
- DLPack 是跨框架 tensor 共享协议
- `assumed_align=16` 告诉编译器地址 16B 对齐，允许生成 128-bit 向量化 load/store

### 2.2 `mark_layout_dynamic()`
- 标记 tensor 的 shape/stride 为运行时动态（不在编译时特化）
- 静态 layout（默认）：性能更好，但换 shape 需重新编译
- 动态 layout：可用于任意 shape，稍慢

### 2.3 `cute.compile[options](func, *args)`
- 显式编译 `@cute.jit` 函数为 CUDA kernel
- `[options]` 通过 `__getitem__` 设置编译选项（如 `GenerateLineInfo(True)`）
- 编译后 `Constexpr` 参数已内联，执行时不再传
- 编译选项：`OptLevel(3)`, `GenerateLineInfo`, `KeepPTX`, `KeepCUBIN`, `GPUArch` 等

### 2.4 `cutlass.Constexpr`
- 编译期常量类型，传入的 Python 对象（函数、lambda）会被内联到生成的 CUDA 代码中
- 无运行时开销

### 2.5 `@cutlass.dsl_user_op`
- 把 Python 函数注册为 DSL 编译管线中可用的自定义算子
- 自动注入 `loc`（MLIR 源码位置）用于报错定位
- 被装饰的函数必须声明 `*, loc=None, ip=None`，调用时无需传

---

## 3. Layout 系统

### 3.1 `cute.make_layout(shape)`
- 默认列主序（mode-0 stride 最小）
- `make_layout((2, 3, 4))` → stride `(1, 2, 6)`
- 注意：与 PyTorch 默认行主序相反

### 3.2 `cute.make_ordered_layout(shape, order)`
- `order` 中数字越小 → 该维度 stride 越小 → 变化越快
- `order=(1, 0)` → 行主序（mode-1 连续）
- `order=(0, 1)` → 列主序（mode-0 连续）

### 3.3 `cute.recast_layout(new_type_bits, old_type_bits, layout)`
- 把"字节视角"的 layout 转为"元素视角"
- 例：val_layout `(16, 16)` 按 byte 定义，recast 到 float32(32bit) 后变 `(16, 4)`
- 目的：固定 128-bit 访存宽度，自动适配不同 dtype

---

## 4. TV Layout（Thread-Value Layout）

核心概念：`(tid, vid) → tile 内逻辑坐标`

### 4.1 构造步骤
```python
thr_layout = cute.make_ordered_layout((4, 64), order=(1, 0))   # 线程排布
val_layout = cute.make_ordered_layout((16, 16), order=(1, 0))  # 每线程数据块(字节)
val_layout = cute.recast_layout(dtype.width, 8, val_layout)    # 字节→元素
tiler_mn, tv_layout = cute.make_layout_tv(thr_layout, val_layout)  # 组合
```

### 4.2 `cute.make_layout_tv(thr_layout, val_layout)`
- 内部做 raked product（交错乘积）
- 返回 `(tiler_mn, tv_layout)`
  - `tiler_mn`：每个 block 处理的 tile 尺寸，如 `(64, 256)`
  - `tv_layout`：`(tid, vid) → (M, N)` 的映射

### 4.3 优化原则
- 线程 ID 应映射到内存连续维度 → coalesced access
- V layout 的 stride-1 在最内层 → 允许向量化
- 128-bit load/store 是最大向量化宽度

---

## 5. Tensor 切分

### 5.1 `cute.zipped_divide(tensor, tiler)`
- 按 tile 尺寸切分全局 tensor
- 结果：`((TileM, TileN), (RestM, RestN))`
  - mode-0：tile 内部坐标
  - mode-1：tile 网格坐标（哪个 block 处理哪个 tile）

### 5.2 `cute.select(input, mode=[1, 0])`
- 按指定顺序挑选/重排模式
- `select((RestM, RestN), mode=[1, 0])` → `(RestN, RestM)`

### 5.3 Block 重映射（remap_block）
```python
remap_block = cute.make_ordered_layout(
    cute.select(shape[1], mode=[1, 0]), order=(1, 0)
)
mInputs[i] = cute.composition(t, (None, remap_block))
```
- 交换 grid 遍历顺序，让 blockIdx.x 沿 N 方向（内存连续方向）走
- 提升 L2 cache 命中率

---

## 6. `cute.composition(A, B)` — 函数复合

数学：`composition(A, B)(x) = A(B(x))`

```
B: 新坐标 → 旧坐标
A: 旧坐标 → 内存地址
composition(A, B): 新坐标 → 内存地址
```

典型用法：
```python
# gInput: (TileM, TileN) → 内存地址
# tv_layout: (tid, vid) → (TileM, TileN)
tidfrgInput = cute.composition(gInput, tv_layout)
# 结果: (tid, vid) → 内存地址
```

与 `(None, remap_block)` 组合时：`None` 表示该模式坐标不变，只变换另一个模式。

### 具体例子

```
A = gInput: shape (4,6), stride (6,1)
    (row, col) → 地址 = row*6 + col

B = tv_layout: shape (6,4), stride (4,1)
    (tid, vid) → 线性坐标 = tid*4 + vid

composition(A, B):
    (tid=0, vid=0) → B→0 → A[0] = 地址0
    (tid=0, vid=1) → B→1 → A[1] = 地址1
    (tid=1, vid=0) → B→4 → A[4] = 地址4
    ...
```

---

## 7. Kernel 内三级切分

### 第一级：Block 级
```python
blk_crd = ((None, None), (bidx, bidy))
gInputs = [t[blk_crd] for t in mInputs]  # (TileM, TileN)
```
- `None` 保留该维度，具体值选择 → 取当前 block 的 tile

### 第二级：Thread-Value 组合
```python
tidfrgInputs = [cute.composition(t, tv_layout) for t in gInputs]
# (TileM, TileN) 空间 → (tid, vid) 空间
```

### 第三级：Thread 级
```python
thr_crd = (tidx, cute.repeat_like(None, tidfrgInputs[0][1]))
thrInputs = [t[thr_crd] for t in tidfrgInputs]  # (vid,)
```
- `tidx` 选当前线程，`repeat_like(None, ...)` 保留所有 vid 维度
- `repeat_like` 处理 vid 可能有层次化嵌套的情况

### 整体数据流

```
全局 Tensor (M, N)
    │ zipped_divide(tiler_mn)
    ▼
((TileM, TileN), (RestM, RestN))     ← 切分为 tile 网格
    │ composition(remap_block)
    ▼
((TileM, TileN), (RestN, RestM))     ← 重映射 block 遍历顺序
    │ [blk_crd]  ← blockIdx 选择
    ▼
(TileM, TileN)                       ← 每个 block 的 tile
    │ composition(tv_layout)
    ▼
(Thread, Value)                      ← 每个线程的工作
    │ [tidx, :]  ← threadIdx 索引
    ▼
(Value,)                             ← 当前线程的 fragment
    │ .load() → op() → .store()
    ▼
结果写回 global memory
```

---

## 8. `cute.repeat_like(x, target)`
- 创建与 target 同结构的 tuple，所有叶子填充为 x
- `repeat_like(None, (4, 16))` → `(None, None)`
- `repeat_like(None, ((4, 2), 8))` → `((None, None), None)`
- 用途：在索引时穿透所有层级保留整个 vid 维度

---

## 9. 边界检查

```python
idC = cute.make_identity_tensor(result.shape)   # 坐标张量：每个位置存自己的坐标
frgPred = cute.make_rmem_tensor(thrCrd.shape, cutlass.Boolean)
for i in cutlass.range_constexpr(cute.size(frgPred)):
    frgPred[i] = cute.elem_less(thrCrd[i], shape)
```
- 当 tensor 尺寸不是 tile 整数倍时判断越界

---

## 10. 编译期循环与打印

### `cutlass.range_constexpr(n)`
- 编译时完全展开的循环，不生成运行时循环代码
- 必须用于遍历异构编译期容器（如不同 layout 的 tensor list）

### `print()` 在 `@cute.kernel` 中
- 是编译期 host 上执行的，打印 layout/type 信息
- 不会在 GPU 运行时打印，纯调试用

---

## 11. Load/Store

```python
result = op(*[thrInput.load() for thrInput in thrInputs])  # global → register
thrC.store(result)  # register → global
```
- `.load()` 生成向量化加载指令
- `.store()` 生成向量化存储指令

---

## 12. Kernel Launch

```python
kernel(...).launch(
    grid=cute.product_each(mC.shape[1]),           # tile 网格各维度大小
    block=[cute.size(tv_layout, mode=[0]), 1, 1],  # 线程数 = T 维度大小
    stream=stream,
)
```
- `cute.product_each`：对多维 shape 每个模式取乘积
- `cute.size(tv_layout, mode=[0])`：取 thread 维度大小

---

## 13. 两种 Thread 分片方式对比

| | tiled_copy + get_slice | composition |
|---|---|---|
| 代码量 | 多（~10行/tensor） | 少（~3行/tensor） |
| 抽象层次 | 高层：封装 copy 原语 | 低层：手动坐标变换 |
| 适用场景 | 需要 cp.async/TMA/smem | 简单 global↔register |

简单 elementwise 场景用 composition 更直接；需要硬件特化拷贝指令（GEMM、attention）时用 tiled_copy。

---

## 14. CuTe 变量命名惯例

| 前缀 | 含义 | 坐标空间 |
|------|------|----------|
| `m` / `g` | 全局/tiled tensor | (M,N) 或 ((Tile),(Rest)) |
| `blk` | 当前 block 的 tile | (TileM, TileN) |
| `tidfrg` | 按 (tid, vid) 重组 | (Thread, Value) |
| `thr` | 当前线程的 fragment | (Value,) |
| `frg` | 寄存器 fragment | (Value,) |

---

## 15. 关于 `loc` 和 `ip` 参数

DSL API 中常见的 `*, loc=None, ip=None`：
- `loc`：MLIR 源码位置，用于 debug/profiling，`@dsl_user_op` 自动注入
- `ip`：MLIR InsertionPoint，控制 IR 插入位置，99% 情况不需要手动传
- 用户调用时无需传，定义 `@dsl_user_op` 函数时必须声明
