# CuTe DSL 控制流（DSL Control Flow 页面学习笔记）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/dsl_control_flow.html
> 主题：07（代码生成）的实战续篇 —— 既然知道了「编译期 vs 运行时」两个世界，这页讲**具体怎么写 `if`/`for`/`while`，以及怎么显式指定它走哪个世界**。

---

## 〇、贯穿全页的核心规则

```
不标注 → 默认 dynamic（lower 成 IR，运行时在 GPU 跑）
标注 const_expr / range_constexpr → 编译期（Python 解释器跑掉/展开）
```

⚠️ **铁律（两个世界不能乱串）**：
- 把 IR value（dynamic 值）塞进**原生 Python 控制流** → 报错
- 把 dynamic 值塞进 `const_expr` → 报错

DSL 的做法：walk Python 的 AST，逐语句决定「编译期原生求值」还是「dynamic → emit IR」。

---

## 一、For 循环：三种 range

| 写法 | 世界 | 行为 |
|------|------|------|
| `for i in range(n)` | **dynamic** | Python 内置，**永远** lower 成 IR（即使 n 是 Python 值） |
| `for i in cutlass.range(bound, unroll=2)` | **dynamic** | 同上，但多了**展开/流水线控制**（`unroll=`、`prefetch_stages=`） |
| `for i in cutlass.range_constexpr(n)` | **编译期** | 在 Python 解释器里跑，**代码生成前完全展开**；索引必须是 Constexpr |

**坑**：`range_constexpr` 里用 dynamic 的 `bound` → 报错，该用 `range`。

### Software Pipelining（软件流水线）

手写「预取循环 + 主循环」操作 circular buffer 很烦，编译器能自动生成：

```python
for i in cutlass.range(bound, prefetch_stages=prefetch_stages)
```

自动产出「预取初始 stage 的预取循环 + 边消费当前数据边预取未来数据的主循环」。
**实验性，仅 sm90+ 支持。**（对应 FA4 2CTA 的多 stage 预取）

---

## 二、If-Else

```python
if pred:                          # dynamic：lower 成 IR
    ...
if cutlass.const_expr(cond):      # 编译期：Python 直接选一边，另一边不进 IR
    ...
```

- 普通谓词 → dynamic
- `const_expr(...)` 包起来 → 编译期求值
- 把 dynamic 值包进 `const_expr` → **不允许**

---

## 三、While

规则完全一致：

```python
while cond:                       # dynamic IR while-loop
while cutlass.const_expr(n < 10): # 编译期
```

---

## 四、汇总表（runtime vs compile-time）

| 构造 | Runtime（动态） | Compile-time（编译期） |
|------|:---:|:---:|
| `if/while cutlass.const_expr()` | ❌ | ✅ |
| `if/while pred` | ✅ | ❌ |
| `for i in cutlass.range_constexpr()` | ❌ | ✅ |
| `for i in range()` | ✅ | ❌ |
| `for i in cutlass.range()`（展开/流水线） | ✅ | ❌ |

---

## 五、编译期元编程的威力（特化，零运行时开销）

经典例子（用 Constexpr flag 守卫一段可选代码）：

```python
def gemm(..., do_relu: cutlass.Constexpr):
    ...
    if cutlass.const_expr(do_relu):   # do_relu=True 才 emit ReLU 代码
        relu(...)
# gemm(..., False) → 生成的 kernel 里根本没有 ReLU 那段
```

→ 对应 07 的 Constexpr 折叠，也对应 FA4 里 `is_causal`/`use_2cta` 切不同变体。

---

## 六、Dynamic 控制流的限制（重点踩坑清单）

**根源**：dynamic 的 `if/for/while` 会整块 lower 成「一块结构化 IR region」（如 `scf.for`/`scf.if`），不再是普通 Python 在跑。这块 region 有严格规则：**单入口、类型固定、作用域封闭**。凡破坏该结构的写法都不支持。

> 对比：`const_expr`/`range_constexpr` 在 Python 解释器里真跑、提前展开，**不生成 IR region，所以以下四条全部不适用**。

文档原例（四条限制集中演示）：

```python
@cute.jit
def control_flow_negative_examples(predicate: cutlass.Boolean):
    n = 10

    # ❌ 限制1：dynamic 循环不能 break
    for i in range(n):
        if i == 5:
            break

    if predicate:
        val = 10
        return                       # ❌ 限制1：不能 return
        raise ValueError("...")      # ❌ 限制1：不能抛异常
        pass                         # ❌ 限制1：不能 pass

    cute.printf("%d\n", val)         # ❌ 限制3：val 出了 if 就不可见

    if predicate:
        n = 10.0                     # ❌ 限制4：不能改变量类型
```

### 限制 1：无 early-exit / 无空语句
原文：*"Early-exit break, continue, pass or raising exception from control flow body are not yet supported."*
- **不能用**：`break`、`continue`、`return`、`raise`、`pass`
- **为什么**：dynamic 循环/分支 = 一块**单入口结构化 IR region**；这些语句本质都是「从 region 中间任意跳出」，结构化 IR 不建模这种任意跳转。（`pass` 被拒因为空 traced body 没东西可 lower）
- → 解释了 FA4 里 mask/early-skip 写成谓词而非 `break`。

### 限制 2：操作只在 tracing 激活的 region 内才被记录
原文：*"Operations in the control flow body are traced only when tracing is active in that region."*
- **含义**：只有「编译器正在 trace 的 region 内」的 CuTe 操作才会进 kernel；region 外的代码只是普通 Python 跑掉，不录进 IR。
- **为什么**：呼应「代码跑两遍」—— 有副作用的 CuTe 操作必须坐落在 active tracing 区域里，否则只在编译期执行了一下，不出现在 GPU kernel。

### 限制 3：体内创建的值，体外不可见
原文：*"Values originating in control flow body are not available outside the control flow."*
- **为什么**：`val` 在 region 作用域内首次定义，只活在 region 里；且该分支运行时可能不执行 → 区外没有「确定存在的 val」可引用。
- **解法**：进 if 之前先在外层定义/初始化变量。

### 限制 4：体内不能改变量类型
原文：*"Changing type of a variable in control flow body is not allowed."*
- **为什么**：IR value 是**静态类型**的；`n` 以 Int32 进入 region 就要全程同一类型，赋成 `10.0`(Float) 会让跨 region 边界类型不一致，类型系统无法调和。
- 注意：改**值**没问题（`n = 20` ✅），改**类型**不行（`n = 20.0` ❌）。

### 限制汇总

| 限制 | 不能做 | 根本原因 |
|------|--------|----------|
| 1 无 early-exit | `break`/`continue`/`return`/`raise`/`pass` | 结构化 IR region 不建模「中途任意跳出」 |
| 2 tracing 范围 | 依赖「region 外操作进 kernel」 | 只有 active tracing region 内的操作才录进 IR |
| 3 作用域封闭 | 体外用体内创建的值 | 值只活在 region 作用域；分支可能不执行 |
| 4 类型稳定 | 体内改变量类型 | IR value 静态类型，跨边界类型必须一致 |

### 规避手段

```python
# 限制3：变量先在外层定义
val = 0
if predicate:
    val = 10
cute.printf("%d\n", val)        # ✅

# 限制1：用谓词代替 break（mask 思路，FA4 常见）
for i in range(n):
    do_work = (i < 5)
    if do_work:                  # 用条件控制，而非 break
        ...

# 限制4：类型从一开始就定对
n = 10.0                         # 一开始就是 float
if predicate:
    n = 20.0                     # ✅ 同类型
```

**终极规避**：若控制流本就是编译期能定的（条件/边界是 Constexpr），直接改用 `const_expr`/`range_constexpr` —— 它们走 Python 真执行，以上四条全不适用。

---

## 七、核心区分（一句话）

```
constexpr / const_expr / range_constexpr
   → Python 解释器在编译期求值/展开（索引必须静态），不受六节四条限制

普通 range / if / while  +  cutlass.range
   → dynamic，lower 成 IR 给运行时（受四条限制）
   （cutlass.range 额外给 unroll= 和 prefetch_stages= 控制）
```

---

## 八、对 FA4 工作的意义

- **编译期固定层数循环**（按 head_dim 切）用 `range_constexpr` 全展开；**运行时循环**（按 seqlen 迭代 KV block）用 `range`/`cutlass.range`，加 `unroll`/`prefetch_stages` 做软件流水线（对应 2CTA 多 stage 预取）
- 「dynamic 体内不能 `break`」→ 解释 FA4 mask/early-skip 为何用谓词而非 `break`
- `is_causal`/`use_2cta`/`head_dim` 用 Constexpr + `const_expr` 守卫 → 切出不同 kernel 变体（`_TUNING_CONFIG`）
