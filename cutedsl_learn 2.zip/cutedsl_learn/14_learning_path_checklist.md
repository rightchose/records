# CuTe DSL / GPU 编程 学习路径 Checklist（练功清单）

> 这不是知识笔记，是**可执行的练习清单**。配套阅读笔记 06–13（在同目录）。
> 核心信念：**GPU 高性能编程的本质是「数据布局工程学」——计算几乎免费，胜负全在数据以什么形状、在什么时间、出现在哪一级存储。内功 = Layout 代数。**

---

## 〇、一句话学习路径

```
吃透 Layout 代数（用 PyCuTe 当练功房）
   → 用「一块数据的旅程」当读码视角
   → 用「搬运 vs 计算」当调优第一问
   → 把一个 kernel（FA4）彻底吃透，胜过读十个
```

周边机制（JIT/caching/autotune/AOT/debugging）已走通（笔记 10–13），现在回头把这把钥匙磨亮。

---

## 一、Layout 代数手算练习（最高优先级 ⭐）

**判断标准**：给你 `(8,4):(1,8)`，问 `coalesce` / `composition` 后是什么，能否**纸上手算**？
能 → 抓住了本质；不能 → 其余学得再熟也是空中楼阁。

**练法**：在 PyCuTe 里 `print` 对答案，先手算再验证。
路径：`cutlass/python/pycute/`，`from pycute import Layout, coalesce, composition, complement, logical_divide`

- [ ] **crd2idx 点积**：`Layout((4,8),(8,1))(2,3)` 手算 = ?（答案 19，笔记 06）
- [ ] **column-major 默认**：`Layout((4,8))` 的 stride = ?（前缀积）
- [ ] **coalesce ×5**：构造 5 个 layout，手算"相邻维 `shape*stride==下一维stride` 则合并"，PyCuTe 验
- [ ] **composition ×5**：手算两个 layout 复合，注意整除前提（divisibility）
- [ ] **complement ×3**：求补空间
- [ ] **logical_divide ×5**：把一维切成 tile（GEMM/FA 切块的核心），看 (Shape,Stride) 怎么变
- [ ] **right_inverse ×2**：求逆映射
- [ ] 目标：形成肌肉记忆，看到 layout 运算能预判结果形状

---

## 二、Swizzle / bank conflict 手算（FA4 直接相关）

配套笔记 04（swizzle deep dive）、06 §3。

- [ ] 手算一整列地址经 swizzle 后的 bank 分布，验证"无 swizzle 撞 bank / 有 swizzle 打散"
- [ ] 理解三参数 MBase/BBits/SShift 各控制什么
- [ ] 在 PyCuTe `swizzle.py` 里跑几个例子对答案
- [ ] 能解释 FA4 smem layout 为什么这样 swizzle

---

## 三、"两个世界"条件反射（编译期 vs 运行时）

目标：看一行 CuTe 代码，**瞬间**判断它编译期跑还是 GPU 上跑。

- [ ] 每读一行 `@cute.jit` 代码，先问"这行搭架子还是 GPU 干活？"
- [ ] `print` vs `cute.printf` 不再需要想（笔记 07/10）
- [ ] constexpr vs dynamic 一眼分清（笔记 07/09）
- [ ] control flow 四条限制能自然解释（为什么不能 break/改类型，笔记 08）
- [ ] 看到 `?{div=4}` 知道是动态值+整除约束；`?{i64}` 知道是位宽（笔记 06/11）

---

## 四、"一块数据的旅程"读码视角（核心技能 ⭐）

**别跟代码行号走，跟一块数据走。** GPU kernel 的逻辑是数据的旅程，不是控制流。

练习对象：FA4 forward，**选一个 head_dim 变体**，追一块 Q tile：

- [ ] HBM → TMA load → smem：进 smem 时什么 swizzle？为什么？
- [ ] smem → 寄存器：怎么分块进寄存器？
- [ ] 寄存器 → MMA → 累加器：MMA 的 tile 形状？累加在哪（TMEM）？
- [ ] softmax 在线计算：数据在哪、exp2 走 SFU 还是模拟（ex2_emu）？
- [ ] correction → epilogue → 写回 HBM：输出 layout？
- [ ] **每一步的 layout 都用 PyCuTe 手算/验证一遍**
- [ ] 2CTA 变体：追 tx_count×2、TMEM 跨 CTA 释放的数据流（笔记 FA4/2CTA）

---

## 五、调优第一问：搬运 vs 计算

**所有调优都是先定位瓶颈、再下手。瓶颈无非两类。**

- [ ] 拿到 kernel 先问：memory-bound 还是 compute-bound？
- [ ] 会用 roofline 思路估：算力 vs 带宽哪个先到顶
- [ ] 理解 FA4 ex2_emu 调参本质 = "exp2 在 SFU 上是不是瓶颈"（笔记 FA4/ex2_emu）
- [ ] 理解寄存器零和分配 = "谁负载重谁多拿"（笔记 FA4/寄存器预算）
- [ ] 会 dump SASS 看真实寄存器用量/指令（`CUTE_DSL_KEEP_CUBIN` + `nvdisasm`，笔记 10）

---

## 六、把"特化↔通用"这根轴刻进脑子（统一心智模型 ⭐）

所有机制都在这根轴上，不是零散知识点：

```
特化(快) ←──────────────────────────────────→ 通用(灵活)
from_dlpack静态  constexpr  mark_compact  mark_layout  全dynamic
AOT(焊死)                                            JIT(运行时挑)
```

- [ ] 每学一个机制，先定位它在这根轴的哪一端
- [ ] 能解释 JIT→autotune→`_TUNING_CONFIG`→AOT 这条交付链（笔记 12/13）
- [ ] 理解 AOT 和 autotuning 的张力（构建期焊死 vs 运行时挑）
- [ ] 能回答"这个 kernel 该用 static 还是 dynamic layout"并说出代价

---

## 七、里程碑（学完算数）

- [ ] **M1**：随手给一个 layout 运算，纸上手算结果（§一）
- [ ] **M2**：解释 FA4 任一 smem swizzle 为什么这么设计（§二）
- [ ] **M3**：完整复述一块 Q tile 在 FA4 里的全程旅程 + 每步 layout（§四）
- [ ] **M4**：拿到陌生 kernel，10 分钟内判断瓶颈类型并给出调优方向（§五）
- [ ] **M5**：给定部署场景，能决策 JIT/AOT、static/dynamic、要不要 autotune（§六）

> M3 是分水岭：能完整追完一块数据的旅程并验算每步 layout，说明内功成了，其余 kernel 都是变奏。

---

## 八、反模式（别这么学）

- ❌ 横向铺更多文档/example —— 不如把 FA4 一个变体吃透
- ❌ 跟代码行号读 kernel —— 要跟数据旅程读
- ❌ 在 GPU 上调 layout 逻辑 —— 先在 PyCuTe 纸上验算
- ❌ 背机制 API —— 要理解它在"特化↔通用"轴的位置
- ❌ 调优靠试 —— 先定位"搬运 vs 计算"瓶颈再动手
