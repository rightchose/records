# Blackwell CLC（Cluster Launch Control）—— 硬件级动态 tile 调度

> 主题：Blackwell 新增的 CLC 机制——把"动态 pull 式 tile 调度"从软件下沉到硬件，
> 解决 persistent kernel 的负载不均。
> 关系：补上 `15_blackwell_hardware.md` 里 2CTA/cluster 那条线的**调度侧**
>      （2CTA 是 cluster 怎么"算"，CLC 是 cluster 怎么"领活"）。
> 来源：CUTLASS 文档 blackwell_cluster_launch_control + 一轮"它解决哪类不均 / 哪些算子受益"的讨论。

---

## 〇、一句话

> CLC 让 GEMM kernel **像非 persistent 那样按 tile 数启动 grid**，但运行时靠硬件指令
> `clusterlaunchcontrol.try_cancel` **动态领取下一块 tile**，从而在"到底有多少 SM 可用"
> 未知时，自动把活均衡到实际空闲的 SM 上。
>
> 本质：**不是发明新解法，而是把"动态 pull 调度（work-stealing）"从软件
> （有 atomic 争用、有开销）硬件化，让你几乎免费拿到动态均衡。**

---

## 一、解决什么：动态 vs 静态分配的老矛盾

GEMM 分 prologue / mainloop / epilogue 三段。CLC 之前两种调度各有缺陷：

| 方案 | 优点 | 缺点 |
|------|------|------|
| **非 persistent**（每 tile 一个 block） | 天然负载均衡 | prologue/epilogue 开销完全暴露 |
| **静态 persistent**（Worker 常驻处理多 tile） | 零开销隐藏 prologue/epilogue | **负载不均**：别的 kernel 占了部分 SM，可用 SM 数运行时未知 |

**CLC = 两者优点合一**：启动像非 persistent（grid = tile 数），执行像 persistent（Worker 常驻领多块），
但领取是**动态**的。

---

## 二、工作机制

核心概念 **`ClcID`** = 从 3D grid 来的一个 tile 坐标。规则：

1. 资源够时，一个 `ClcID` 直接作为 Worker 启动。
2. 已有 Worker 用 `try_cancel` 指令**查询/抢占**下一个 `ClcID`。
3. 每个 `ClcID` 必经这两条路之一被处理。
4. Worker 先用自己的 `blockIdx` 当第一个 tile（全静态、无需查询），之后靠 CLC 查询拿后续 tile。
5. `try_cancel` 返回：成功（带新 `ClcID`）或 拒绝（通常因所有 tile 已处理完 → 退出 persistent 循环）。
6. **粒度是 cluster 级**：2×2 cluster 一次查询消费 2×2 个 `ClcID`，不是单 CTA。

伪代码循环：算当前坐标 → `fetch_next_work()` 返回 (是否有效, 新 ClcID) → 无效就停。

---

## 三、关键 API（CUTLASS 侧）

- **`PipelineCLCFetchAsync`** —— 异步管理 CLC 查询的生产者-消费者 pipeline
  - `transaction_bytes = 16`（CLC 返回 16B 响应）
  - `producer_arv_count = 1`（单个选举出的线程发 `try_cancel`）
  - `producer_blockid = 0`（cluster 第一个 CTA 当生产者）
  - `consumer_arv_count` = 所有消费者 warp 的线程数
- **`PersistentTileSchedulerSm100`** —— 动态 tile 调度器
  - `advance_to_next_work`：选举出的调度线程发查询，结果**广播到 cluster 内所有 CTA 的同一 smem 地址**
  - `get_current_work`：从 smem 按 pipeline state 读回 CLC 响应

---

## 四、CUTLASS 怎么用（对得上 warp-specialized 设计哲学）

在 `sm100_gemm_tma_warpspecialized.hpp` 里按 warp 分工：

| Warp | 角色 |
|------|------|
| 0 | MMA |
| **1** | **Scheduler（CLC pipeline 生产者）** |
| 2 | Mainloop Load |
| 3 | Epilogue Load |
| 4-7 | Epilogue |

- **Scheduler 单独占一个 warp 当生产者**，专门发 CLC 查询（和 FA4 里 softmax/correction/other 的
  warp 专精同一种哲学）。
- 消费者 = MMA / Load / Epilogue + Scheduler 自己（它要靠成功信号判断 grid 跑完没）。
- **CLC pipeline 深度 = 3**，跨 wave 重叠 CLC 操作隐藏查询延迟。
- 第一个 tile 是预载的 `blockIdx`，全静态、零查询开销。

---

## 五、它解决哪一类不均（别当银弹）

| 不均来源 | CLC | 为什么 |
|----------|:---:|--------|
| **SM 被别的 kernel 占用**（多租户/MPS，可用 SM 运行时未知） | ✅ 强 | 动态领取，空闲 SM 自然多领 |
| **wave quantization / tail**（tile 数除不尽 SM 数） | ✅ | 快的 SM 先抢下一块，磨平尾巴 |
| **tile 之间工作量不均**（grouped GEMM / 变长 K / MoE） | ✅ 部分 | 算完便宜 tile 立刻领下一个，不被静态绑死 |
| **单个 tile 内部就不均** | ❌ | CLC 只调度 tile，不改 tile 内部 |
| **跨 kernel / 全 GPU 调度** | ❌ | 只均衡一次 launch 内的 tile |

**相对软件方案（全局 tile 计数器 + atomicAdd、Stream-K）的增量价值：**
1. **无全局 atomic 争用**——几百 SM 抢同一原子变量会成瓶颈，CLC 是硬件队列无此问题。
2. **开销极低**——配合 pipeline 深度 3 把查询延迟藏掉，接近静态 persistent 的"零开销"。
3. **和 cluster launch 原生集成**——Blackwell 本就把 cluster 当一等公民。

**冷水**：粒度是 cluster 不是 CTA（最小均衡单位变粗）；只在 grid 内；SM100 only；
pipeline 类和 scheduler 类必须配对才正确（复杂度转移到同步）。

---

## 六、LLM 里哪些核心算子受益

判断标准一条：**「tiled GEMM 结构」 ×「tile 之间不均 / 有 tail」**，两者都满足才真受益。

| 算子 | 受益 | 不均来源 |
|------|:---:|---------|
| **MoE grouped GEMM（expert FFN）** | ★★★ | expert 间 token 数差异（routing 倾斜）——**最大受益者** |
| **varlen prefill GEMM** | ★★★ | batch 内序列不等长 |
| **causal / varlen attention（FA）** | ★★★* | causal mask 让靠后 query block attend 更多 key + 变长（*看 kernel 是否构建在 cluster scheduler 上） |
| dense 投影 GEMM（QKV / FFN up-down） | ★★ | 工作量均匀，**只吃 tail + 共享 SM** 红利 |
| LM head / 大 N 投影 | ★★ | 大矩阵 tail |
| norm / act / rotary / residual | ✗ | memory-bound 且每元素恒定，非 GEMM |
| all-to-all / all-reduce | ✗ | 不是 compute tile（MoE EP 不均要在 DeepEP/dispatch 层解决） |

**核心规律**：**不均越是"数据相关、运行时才知道"（MoE token 分布、变长、causal），
CLC 红利越大；工作量恒定的 dense 算子只能吃 tail 小红利；非 GEMM 的 memory-bound 和通信算子沾不上边。**

> 对 megatron-mlp 这条线，最相关的两个：**MoE grouped GEMM** 和 **varlen causal attention(FA4)**。

---

## 七、和已有笔记的连接

- **2CTA（`15_blackwell_hardware.md`）= 计算侧**：`tcgen05.mma.cta_group::2` 让 MMA 跨 2 CTA 算。
- **CLC（本篇）= 调度侧**：cluster 怎么动态领活。
- 两者都建立在 Blackwell 把 **cluster 当一等公民**这个共同基础上。
- warp 专精（Scheduler 独占一 warp 当 CLC 生产者）和 FA4 的 softmax/correction/other 分工是同一思路。
