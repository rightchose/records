# CuTe DSL 进阶：Ampere Tensor Core GEMM 知识点总结

源文件：`cutlass/examples/python/CuTeDSL/cute/ampere/kernel/dense_gemm/tensorop_gemm.py`

## 一、概述

这是一个面向 **Ampere Tensor Core** 的 GEMM 实现 (C = A * B)，相比 SIMT SGEMM 升级了：

| 对比项 | sgemm.py (SIMT) | tensorop_gemm.py (Tensor Core) |
|--------|-----------------|-------------------------------|
| 计算单元 | FPU (FMA) | Tensor Core (m16n8k16) |
| 数据类型 | FP32 | FP16 输入, FP32 累加, FP16 输出 |
| Tile 尺寸 | 128×128×8 | 128×128×32 |
| smem→rmem | autovec_copy | **ldmatrix** (专用指令) |
| smem 布局 | padding | **swizzle** (更优的 bank-free 方案) |
| 写回策略 | rmem→gmem 直写 | rmem→**smem**→gmem (向量化写回) |
| Batch | 不支持 | 支持 (L 维度) |
| Grid 优化 | 无 | **Threadblock Rasterization** |
| Smem 复用 | 无 | A/B 和 C 的 smem **共享同一块内存** |

**默认配置**：
- Tile: `128×128×32`, MMA atom: `m16n8k16`
- atom_layout: `2×2×1` (4 个 warp), num_threads: `128`
- num_stages: 3

---

## 二、新增知识点（相比 SGEMM）

---

### 知识点 1：Swizzle — 替代 Padding 的 Bank Conflict 解决方案

```python
def _make_smem_layout_AB(self, dtype, major_mode, copy_bits, smem_tiler):
    swizzle_bits = int(math.log2(major_mode_size * dtype.width // copy_bits))
    swizzle_bits = min(swizzle_bits, 3)

    layout_atom_outer = cute.make_layout((major_mode_size, 8), stride=(1, major_mode_size))
    layout_atom = cute.make_composed_layout(
        cute.make_swizzle(swizzle_bits, 3, 3),
        0,
        layout_atom_outer,
    )
    layout = cute.tile_to_shape(layout_atom, smem_tiler, (0, 1, 2))
```

**Swizzle vs Padding**：

| 方法 | 原理 | 优缺点 |
|------|------|--------|
| Padding | 每行多加几个元素，错开 bank | 简单但浪费 smem 空间 |
| Swizzle | 对地址的低位做 XOR 变换 | 零空间浪费，无额外开销，需配合 ldmatrix |

**`make_swizzle(B, M, S)`**：
- `B` (bits): swizzle 的位宽（1~3）
- `M` (mask): 参与 XOR 的 base 位
- `S` (shift): XOR 的 shift 位
- 效果：`addr[M:M+B] ^= addr[S:S+B]`

**`make_composed_layout(swizzle, offset, layout_atom)`**：
- 先用 `layout_atom` 计算逻辑偏移
- 再用 `swizzle` 对偏移做 XOR 变换 → 物理地址

**`tile_to_shape(layout_atom, smem_tiler, order)`**：
- 将 layout atom 铺满整个 smem tile (128×32×3)
- `order=(0, 1, 2)`: 铺砖的维度优先级

---

### 知识点 2：Tensor Core MMA Atom — `MmaF16BF16Op`

```python
op = cute.nvgpu.warp.MmaF16BF16Op(
    self.ab_dtype,        # Float16
    self.acc_dtype,       # Float32
    self.mma_inst_shape   # (16, 8, 16)
)
```

**对比 SIMT 的 `MmaUniversalOp`**：

| MMA Op | 指令 | Shape | 参与线程 |
|--------|------|-------|---------|
| `MmaUniversalOp(fp32)` | FMA | 1×1×1 | 1 线程 |
| `MmaF16BF16Op(fp16, fp32, (16,8,16))` | `mma.sync.m16n8k16` | 16×8×16 | 32 线程 (1 warp) |

- 一个 warp (32线程) 协作完成一个 16×8×16 的矩阵乘
- 输入 FP16，累加 FP32，是 Ampere Tensor Core 的核心指令

---

### 知识点 3：`atom_layout_mnk` — 多 Warp 拼接

```python
atom_layout_mnk = (2, 2, 1)  # M方向2个warp, N方向2个warp, K方向1个
num_threads = 2 * 2 * 1 * 32 = 128

tC = cute.make_layout(self.atom_layout_mnk)
tiled_mma = cute.make_tiled_mma(op, tC, permutation_mnk=...)
```

**含义**：将 MMA atom 在 M×N 方向复制排列

```
一个 CTA (128 threads = 4 warps):
┌────────────────┬────────────────┐
│ Warp0 (16×8)   │ Warp1 (16×8)   │  ← N 方向 2 个
├────────────────┼────────────────┤
│ Warp2 (16×8)   │ Warp3 (16×8)   │  ← N 方向 2 个
└────────────────┴────────────────┘
       M 方向 2 个

每个 warp 做 16×8×16 的 MMA
4 个 warp 合起来覆盖 32×16×16 的子问题
```

**`permutation_mnk`**：

```python
permutation_mnk = (
    atom_layout_mnk[0] * mma_inst_shape[0],      # 2*16 = 32
    atom_layout_mnk[1] * mma_inst_shape[1] * 2,  # 2*8*2 = 32
    atom_layout_mnk[2] * mma_inst_shape[2],      # 1*16 = 16
)
```

控制 tiled_mma 的"一次性"覆盖范围：32×32×16。tile 的 128×128×32 通过多次迭代覆盖。

---

### 知识点 4：`ldmatrix` — Tensor Core 专用的 smem→rmem 搬运

```python
atom_copy_s2r_A = cute.make_copy_atom(
    cute.nvgpu.warp.LdMatrix8x8x16bOp(
        self.a_major_mode != utils.LayoutEnum.ROW_MAJOR,  # transpose?
        4  # 4 matrices (ldmatrix.x4)
    ),
    mA.element_type,
)

tiled_copy_s2r_A = cute.make_tiled_copy_A(atom_copy_s2r_A, tiled_mma)
```

**`LdMatrix8x8x16bOp`**：
- 对应 PTX 指令 `ldmatrix.sync.aligned.x4.m8n8.shared.b16`
- 一个 warp 一次加载 4 个 8×8 矩阵（每个元素 16 bit）从 smem 到寄存器
- 加载后的寄存器布局直接匹配 Tensor Core MMA 指令所需的格式
- 参数 `transpose`: A 为列优先时不转置，行优先时转置

**`make_tiled_copy_A(atom, tiled_mma)`**：
- 自动构造与 tiled_mma 的 A 矩阵 TV layout 匹配的 TiledCopy
- 保证从 smem 读出的数据排布直接能喂给 MMA 指令

**对比 SGEMM 的 `autovec_copy`**：

| 方式 | 指令 | 效率 |
|------|------|------|
| `autovec_copy` | 普通 load (ld.shared) | 通用但低效 |
| `ldmatrix` | 专用指令 | 一次搬整个 8×8 matrix，零 bank conflict |

---

### 知识点 5：`retile` — 不同 copy 和 mma 视角的寄存器映射

```python
tCrA_copy_view = thr_copy_ldmatrix_A.retile(tCrA)
```

**问题**：`tCrA` 是按 MMA 的 TV layout 分配的寄存器 fragment。但 `ldmatrix` 有自己不同的 TV layout。

**`retile` 的作用**：为同一块寄存器数据提供另一种"视图"（不拷贝数据），使得：
- 写入时用 copy 的视角 (`tCrA_copy_view`)
- 计算时用 mma 的视角 (`tCrA`)
- 两个视角指向同一组物理寄存器

```
物理寄存器: [r0, r1, r2, r3, ...]
    │
    ├── tCrA (MMA 视角):        partition_A 的 shape
    └── tCrA_copy_view (copy 视角): ldmatrix 期望的 shape

写入: cute.copy(tiled_copy_s2r_A, tCsA_p[...], tCrA_copy_view[...])
计算: cute.gemm(tiled_mma, tCrC, tCrA[...], tCrB[...], tCrC)
```

---

### 知识点 6：Threadblock Rasterization — Grid 重映射

```python
raster_factor = 8  # (当 grid_dim_n > 5 时)
rasterization_remap_grid_dim = (
    grid_dim[0] * raster_factor,
    (grid_dim[1] + raster_factor - 1) // raster_factor,
    grid_dim[2],
)

# kernel 内部反映射：
def raster_tile(self, i, j, f):
    new_i = i // f
    new_j = (i % f) + (j * f)
    return (new_i, new_j)
```

**目的**：让相邻 CTA 在 N 方向上连续，共享 A 矩阵的 L2 cache。

**原始映射** (无 rasterization):
```
CTA grid (M方向 × N方向):
(0,0) (0,1) (0,2) (0,3) ...
(1,0) (1,1) (1,2) (1,3) ...
GPU 按行扫描分配 → 相邻 CTA 的 A 不同，cache 利用率低
```

**Rasterization 后** (f=4):
```
物理 grid 被拉宽了，但逻辑映射让连续 blockIdx.x 对应不同 N 位置：
blockIdx.x: 0,1,2,3 → tile (0,0),(0,1),(0,2),(0,3) ← 同一行不同列，共享 A!
blockIdx.x: 4,5,6,7 → tile (1,0),(1,1),(1,2),(1,3)
```

**效果**：相邻的 CTA 访问同一行的 A 数据，L2 cache 命中率大幅提升。

---

### 知识点 7：`@cute.struct` — Shared Memory 结构化分配

```python
@cute.struct
class SharedStorageAB:
    a: cute.struct.Align[
        cute.struct.MemRange[mA.element_type, cute.cosize(sA_layout)],
        16,
    ]
    b: cute.struct.Align[
        cute.struct.MemRange[mB.element_type, cute.cosize(sB_layout)],
        16,
    ]

@cute.struct
class SharedStorageC:
    c: cute.struct.Align[
        cute.struct.MemRange[mC.element_type, cute.cosize(sC_layout)],
        16,
    ]

# 分配 smem，AB 和 C 共享同一块（union）
smem = cutlass.utils.SmemAllocator()
storage = smem.allocate(
    max(SharedStorageAB.size_in_bytes(), SharedStorageC.size_in_bytes()),
    byte_alignment=16,
)
sA = SharedStorageAB(storage).a.get_tensor(sA_layout)
sB = SharedStorageAB(storage).b.get_tensor(sB_layout)
sC = SharedStorageC(storage).c.get_tensor(sC_layout)
```

**关键设计**：
- `@cute.struct`: 定义 smem 的结构化内存布局（类似 C struct）
- `Align[..., 16]`: 16 字节对齐
- `MemRange[dtype, size]`: 一段连续内存
- **A/B 和 C 共用同一块 smem**：mainloop 结束后 A/B 不再需要，epilogue 才用 C → 节省 smem

---

### 知识点 8：Epilogue — rmem→smem→gmem 两段写回

```python
# 1. 类型转换 + epilogue op
tCrD = cute.make_fragment_like(tCrC, self.c_dtype)
tCrD[None] = epilogue_op(tCrC.load()).to(self.c_dtype)  # fp32 → fp16

# 2. Register → Shared Memory (按 MMA 的 TV layout)
cute.autovec_copy(tCrD, tCsC)

# 3. Sync
cute.arch.sync_threads()

# 4. Shared Memory → Register (按 Copy 的 TV layout，向量化)
cute.autovec_copy(tCsC_epilogue, tCrC_epilogue)

# 5. Register → Global Memory (128-bit vectorized store)
cute.copy(tiled_copy_C, tCrC_epilogue[...], tCgC_epilogue[...], pred=tCpC[...])
```

**为什么不直接 rmem→gmem？**

MMA 指令输出的寄存器分布是非连续的（由 Tensor Core 的硬件 layout 决定），直接写 gmem 无法 coalesced。

```
MMA 输出的 C fragment:
  Thread0 拥有 C[0,0], C[1,0], C[0,2], C[1,2]... (分散)
  → 直接写 gmem 每次只能写 1 个 fp16 → 效率低

通过 smem 中转:
  rmem → smem (按 MMA layout 写入，无 conflict，因为有 swizzle)
  smem → rmem (按 Copy layout 读出，连续 128-bit)
  rmem → gmem (128-bit vectorized store, coalesced!)
```

---

### 知识点 9：Copy 的 `cache_mode`

```python
atom_async_copy = cute.make_copy_atom(
    cute.nvgpu.cpasync.CopyG2SOp(
        cache_mode=cute.nvgpu.cpasync.LoadCacheMode.GLOBAL
    ),
    mA.element_type,
    num_bits_per_copy=ab_copy_bits,
)
```

**`LoadCacheMode.GLOBAL`**：
- 对应 `cp.async.cg`（cache at global level）
- 数据只缓存到 L2，不缓存到 L1
- 适合流式访问模式（GEMM 的 A/B 数据通常只用一次）
- 避免污染 L1 cache

---

### 知识点 10：Batch 维度处理

```python
# Tensor shape: (M, K, L) / (N, K, L) / (M, N, L)
# L 是 batch 维度

gA = cute.local_tile(
    mA[None, None, bidz],   # ← 用 blockIdx.z 索引 batch
    tiler=self.cta_tiler,
    coord=tiler_coord,
    proj=(1, None, 1),
)
```

- Grid 的 Z 维度对应 batch: `grid = (ceil_M, ceil_N, L)`
- 每个 CTA 用 `bidz` 选择 batch 中的一个样本

---

### 知识点 11：`make_fragment_A/B/C` — 按 MMA 需求分配寄存器

```python
tCrA = tiled_mma.make_fragment_A(tCsA[None, None, None, 0])
tCrB = tiled_mma.make_fragment_B(tCsB[None, None, None, 0])
tCrC = tiled_mma.make_fragment_C(tCgC)
```

**对比 `make_rmem_tensor_like`**：

| API | 用途 |
|-----|------|
| `make_rmem_tensor_like(src)` | 通用：创建与 src 同 shape 的寄存器 tensor |
| `tiled_mma.make_fragment_A(ref)` | 专用：创建匹配 MMA 指令 A 操作数的寄存器 fragment |
| `tiled_mma.make_fragment_B(ref)` | 专用：匹配 B 操作数 |
| `tiled_mma.make_fragment_C(ref)` | 专用：匹配 C 累加器 |

`make_fragment_*` 会确保寄存器的 layout 精确匹配硬件 MMA 指令的要求。

---

### 知识点 12：K 维度残余处理 — 按元素级 predicate

```python
# 先 fill 0（保证 predicate off 的位置不影响计算）
tAsA.fill(0)
tBsB.fill(0)
cute.arch.sync_threads()

# 第 0 个 k-tile：逐 k-block 检查
for k in range(tApA.shape[2]):
    if cute.elem_less(cutlass.Int32(-1), tAcA[0, 0, k, 0][1]):  # k 坐标有效？
        cute.copy(tiled_copy_A, tAgA[..., k, 0], tAsA[..., k, 0], pred=tApA[..., k])
```

**与 SGEMM 的区别**：
- SGEMM：为残余 tile 单独创建一个 `tApA_residue_k` predicate tensor
- TensorOp：先 fill 0，然后用 identity tensor 的 K 坐标做 if/else 条件控制
- 效果相同：保证越界位置读到 0，不影响累加结果

---

## 三、整体数据流

```
Global Memory (A: fp16, B: fp16)
  │
  │  cp.async.cg (128-bit, vectorized, cache-global)
  ▼
Shared Memory (swizzled layout, 3-stage pipeline)
  │  sA: (128, 32, 3)  sB: (128, 32, 3)
  │
  │  ldmatrix.x4 (8×8×16b, Tensor Core 专用)
  ▼
Register File (fragment_A, fragment_B)
  │
  │  mma.sync.m16n8k16 (Tensor Core)
  ▼
Register File (fragment_C: fp32 accumulator)
  │
  │  epilogue_op + fp32→fp16 转换
  ▼
Register File (fragment_D: fp16)
  │
  │  autovec_copy (写入 smem，按 MMA layout)
  ▼
Shared Memory (sC, 复用 sA/sB 的空间)
  │
  │  autovec_copy (读出，按 Copy layout)
  ▼
Register File (epilogue fragment)
  │
  │  CopyUniversalOp 128-bit vectorized store
  ▼
Global Memory (C: fp16)
```

---

## 四、与 SGEMM 的关键差异总结

| 方面 | SGEMM (SIMT) | TensorOp GEMM |
|------|--------------|---------------|
| **MMA** | FMA (1×1×1) | m16n8k16 Tensor Core |
| **smem 防 bank conflict** | padding (+4) | swizzle (XOR 变换) |
| **smem→rmem** | autovec_copy | ldmatrix (专用指令) |
| **寄存器视角** | 统一视角 | retile (copy/mma 两套视角) |
| **写回** | rmem→gmem (标量) | rmem→smem→gmem (向量化) |
| **Grid 优化** | 无 | Threadblock Rasterization |
| **Smem 管理** | 简单分配 | @cute.struct + union 复用 |
| **数据精度** | fp32 全程 | fp16→fp32→fp16 混合精度 |
| **Batch** | 不支持 | bidz 索引 batch |

---

## 五、核心设计哲学

这个 kernel 体现了 Tensor Core GEMM 的两个核心设计原则：

1. **数据搬运和计算用不同的视角看同一份数据**
   - smem 有 swizzle 布局 → 对 ldmatrix 友好
   - ldmatrix 加载后 → 寄存器自动匹配 MMA 输入格式
   - MMA 输出后 → 寄存器对 MMA 友好但对 gmem 写不友好
   - 通过 smem 中转 → 换个布局再写出

2. **层层流水线掩盖延迟**
   - gmem→smem: cp.async 3-stage pipeline
   - smem→rmem: register pipeline (produce i+1, consume i)
   - MMA 计算和搬运交错执行
