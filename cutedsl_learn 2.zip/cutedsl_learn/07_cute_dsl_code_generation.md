# CuTe DSL 代码生成机制（DSL Code Generation 页面学习笔记）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/dsl_code_generation.html
> 主题：CuTe DSL 是怎么把 Python 代码变成 GPU 二进制的 —— 一个 **Hybrid DSL**，把「AST 改写」和「Tracing」两种编译技术揉到一起。

---

## 〇、一句话总览

```
你写的 Python（@jit 函数）
   = 一个"用来生成 GPU kernel 的元程序"
   │
   │  AST 管控制流结构 + Tracing 管张量算术（Hybrid）
   ▼
  IR  ──后端 lower──▶  PTX/SASS  ──▶  GPU 二进制
```

核心矛盾：**想要 Python 的表达力，又要生成结构化的高性能 GPU 代码** —— 这两者天然打架，Hybrid 是缝合方案。

---

## 一、前置概念：AST 是什么

**AST = Abstract Syntax Tree，抽象语法树** —— 把源代码的语法结构表示成的一棵树。

```python
c = a + b * 2
```
解析成：
```
        Assign(=)
        /      \
   Name(c)    BinOp(+)
              /     \
          Name(a)  BinOp(*)
                   /     \
              Name(b)  Num(2)
```

- 每个节点 = 一个语法构造；树结构编码优先级和嵌套（`*` 比 `+` 深，先算）
- **丢掉表面字符（空格/括号/注释），只留语法骨架**，所以叫「抽象」
- Python 自带 `ast` 模块，`ast.parse(...)` 能直接拿到这棵树

**关键认知**：AST 树的大小只跟「写了多少行代码」有关，跟「循环跑多少次」**无关** —— 一个百万次循环在树里就是**一个 `For` 节点**。

---

## 二、两条纯路线，各自的死穴

### 2.1 AST Rewrite（静态分析语法树）

**做法**：执行前把函数解析成语法树，把 `for/while/if` 直接翻译成结构化 IR。

```
✅ 优点：看得到整个程序 —— 每个分支、每个循环都原样保留（不展开）
❌ 死穴：只能用 Python 的一个"受限子集"
```

**「受限子集」怎么理解**：
- 根因不是「Python 动态」本身，而是**「静态翻译」这个动作** —— 要在执行前把语法树硬翻成 GPU 固定指令，而很多 Python 动态特性的语义只有「真跑起来」才确定，没法静态翻译。
- GPU 执行模型是**静态的**（无运行时类型检查/GC/异常/动态对象），控制流必须编译期定好结构。
- 所以这个限制**只压在「要下放到 GPU runtime 的那段代码」**（主要是规整的 `for/if`）；而「只在编译期跑、用来生成 kernel」的元编程代码，**Python 全部动态特性仍可用**。

判断口诀：**这行最终要在 GPU 上跑吗？要 → 老实写（受限）；只是编译期搭架子 → 随便写（全 Python）。**

### 2.2 Tracing（追踪）

**做法**：用 proxy（代理）参数把函数**实跑一遍**，重载运算符把每个 tensor 操作录成扁平 trace，lower 成 IR。

**优点**：
- **Near-zero compile latency**：没有静态分析/改写的前置开销，「跑一遍 = IR 建好」，延迟几乎为零。**ideal for straight-line arithmetic（直线算术）** —— 直线代码无控制流，正好避开下面三个死穴，此时纯赚（最快 + 无正确性损失）。
- **No need to parse Python source**：不解析源码、直接让解释器跑 → 白嫖 CPython 全部动态能力，支持字典分派、列表推导、动态对象等大量动态特性（而 Python 这类特性极多，AST 静态翻译根本翻不全）。

**死穴（全部来自控制流）**：
| 死穴 | 原因 | 后果 |
|------|------|------|
| 没走到的分支消失 | trace 只录走过的路 | 换输入走另一支 → kernel 错 |
| 循环被展开 | 实跑 N 次录 N 条 | IR 爆炸；N 被固化 |
| 数据相关控制流冻结 | proxy 跑时取了某走向 | 固化成单一路径 |

> 「不解析源码」既是它**灵活**的原因，也是它**丢控制流**的原因 —— 它压根没去看 `if/for` 长什么样。

### 2.3 一句话对比

**AST「看得全但管得死」，Tracing「自由但失忆」。**

---

## 三、Tracing 的实现机制：proxy + 运算符重载 + IR builder

⚠️ 注意：文档没写实现细节，这是基于 tracing 类 DSL（JAX/PyTorch FX/Triton）通用范式的还原。

**关键纠正**：Tracing 产物是 **IR，不是机器码**：
```
Python 解释器 ──录操作──▶ IR ──后端 lower──▶ PTX/SASS
   (Tracing 干这段)         (Object-Stage 干这段)
```

三件道具配合：

1. **proxy**：代替真实数据，内部不存数据，只存「我对应 IR 里哪个 SSA value」的句柄
   ```
   a → proxy{ ir_value: %0 }
   ```
2. **运算符重载**：`a + b` 时 `proxy.__add__` 不算数，而是向 IR builder emit 一条指令，返回指向新 value 的 proxy
   ```python
   def __add__(self, other):
       new_val = ir_builder.emit("arith.addf", self.ir_value, other.ir_value)
       return proxy(ir_value=new_val)
   ```
   → IR 里多一行 `%2 = arith.addf %0, %1`
3. **IR builder**：每次 emit 往当前插入点追加 op，函数跑完一整棵 IR 就建好

**本质**：同一段 Python，因为传进去的是 proxy 而非真值，"执行"的副作用从「算数值」变成「建 IR」。

---

## 四、Hybrid：缝合方案

### 4.1 出发点（关键观察）

> **GPU kernel 在 runtime 时，结构其实很简单。**

复杂的部分都是**编译期决策**（怎么切 tile、选哪个变体、布局怎么算）；运行时剩下的是干净的循环 + 算术。既然「复杂在编译期、简单在运行时」可分离，就**按时间分而治之**。

### 4.2 分工：一句话

> **AST 管结构（控制流），Tracing 管算术（张量运算）。**

妙处：每一方被分到的活，恰好都**避开了自己的死穴** —— AST 只碰规整控制流（不碰它头疼的动态特性），Tracing 只碰算术（不碰它会翻车的控制流）。

| | 强项 | 死穴 | Hybrid 派它干 |
|---|------|------|--------------|
| AST | 静态看结构，`for/if` 原样保留 | 动态特性翻不了 | 只管控制流骨架 |
| Tracing | 跑一遍录算术，快+支持动态 Python | 丢分支、展开循环 | 只管张量算术 |

### 4.3 三阶段编译流水线

```
① Pre-Staging（AST 改写）
   解析 @jit 函数语法树，在 for/while/if 周围插入回调
   → 控制流结构被"显式标记"，还没执行
   │
② Meta-Stage（Python 解释器实跑，传 proxy）← 缝合点
   同一次执行里：
     • 张量算术  → proxy 运算符重载 → emit 算术 op       (Tracing)
     • for/if    → ①插的回调触发     → emit 结构化控制流 IR (AST)
     • Constexpr → Python 直接算出常量 → 折叠进 IR（特化）
   → 产物：一棵结构完整的 IR
   │
③ Object-Stage（编译器后端，与 Python 无关）
   IR → lower → 优化(tiling/向量化/内存提升) → PTX/SASS → device binary
```

**最关键的洞见在 ②**：因为 ① 已在 `for` 旁插了回调，Tracing 跑到循环时——
```
纯 Tracing：真循环 N 次 → emit N 条 → 展开（死穴）
Hybrid：    回调触发 → emit 一条 scf.for 结构 → 不展开 ✅
            然后只 trace 循环体里那几条算术
```
两者都通过**同一个 IR builder** emit，只是 emit 的东西不同（结构 vs 算术）。

### 4.4 成果：两边优点全拿，死穴全消

```
            控制流        张量算术      动态 Python    编译速度
纯 AST       ✅           ⚠️难翻        ❌受限子集      慢
纯 Tracing   ❌丢/展开     ✅           ✅全支持        极快
───────────────────────────────────────────────────────
Hybrid       ✅(AST)     ✅(Tracing) ✅(元编程层)   可接受
```
- 真正的循环（不展开 → IR 小、编译快、寄存器友好）
- 所有分支保留（换输入也正确）
- 动态 shape 可用（dynamic 走 proxy，一份 kernel 多种尺寸）
- 元编程可用（Constexpr 在 meta-stage 求值 → 特化多变体）

---

## 五、核心心智模型：代码跑两遍（Run Twice）

> 你写的同一段 @jit Python 函数，会**执行两遍，在两个完全不同的世界里**。

```
第 1 遍：Meta-Stage（编译期 / host CPU）
   • 何时：调用 @jit 函数那一刻（触发编译）
   • 参数：proxy（不是真数据）
   • 目的：搭建 kernel 的 IR（不是算结果）

第 2 遍：Runtime（运行时 / GPU）
   • 何时：kernel 被 launch、真实数据喂进来
   • 参数：真实 tensor 数据
   • 目的：真正干活、算出结果
```

### 5.1 体现一：两个 print

```python
@cute.jit
def f(a, b):
    print(a)          # 第1遍(CPU编译期) → 打印 <Float32 proxy>
    cute.printf(a)    # 第2遍(GPU运行时) → 打印 7.000000
    return a + b
```
| | 哪一遍 | 打印什么 | 调什么 |
|---|--------|---------|--------|
| `print(a)` | 第1遍/编译期/CPU | `<proxy>` | shape、stride、tile size |
| `cute.printf(a)` | 第2遍/运行时/GPU | `7.000000` | 真实 tensor 数值 |

### 5.2 体现二：Constexpr vs dynamic

```python
@cute.jit
def f(a):
    b = 5.0           # Constexpr：第1遍就算掉、折叠进 IR（常量烤进 kernel）
    return a + b      # a 是 dynamic：第1遍只是 proxy，真值等第2遍 GPU 上才有
```
- **Constexpr** → 特化（一次定死，生成针对性 kernel；如 head_dim/is_causal/use_2cta 多变体）
- **dynamic** → 一份 kernel 跑多种尺寸（如 seqlen，无需重编译）

---

## 六、两种 code-generation 模式（`@jit` 的 `preprocess` 开关）

| 模式 | 写法 | 是否 Hybrid |
|------|------|------------|
| **Preprocessor（默认）** | `@cute.jit` 或 `@jit(preprocess=True)` | ✅ Hybrid：AST 改写 + Tracing，捕获所有循环分支再 trace 算术 |
| **Tracing-only** | `@jit(preprocess=False)` | ❌ 纯 Tracing：最快，但**仅在 100% 保证直线算术时用**，有控制流会静默生成错代码 |

- **默认就是 Hybrid，别乱动**。
- 关掉的唯一理由：确定无 `if/for`、想省那点编译开销。
- ⚠️ 精确参数名拼写（`preprocess` vs `preprocessor`）与默认值，建议到本地 `cutlass.cute` 的 `jit` 装饰器定义处核实。

---

## 七、对 FA4 工作的现实意义

- kernel 里 `for warpgroup`、causal 的 `if` **不被无脑展开** → AST Rewrite 保成结构化循环/分支
- `head_dim`/`is_causal`/`use_2cta` 用 Constexpr **触发不同 kernel 变体**（`_TUNING_CONFIG` 那张表）→ Meta-Stage 的「部分求值 + 折叠进 IR 做特化」
- 同一 kernel 处理不同 **seqlen 不重编译** → seqlen 走 dynamic/proxy 路径
- 调试分工：`print` 看编译期 shape/stride/tile，`cute.printf` 看 GPU 上真实数值

---

## 八、文档没覆盖的（避免误记）

- ❌ 没讲 code caching
- ❌ 没有 `@cute.kernel` 装饰器（只有 `@cute.jit` / `@jit`）
- ❌ 没点名 MLIR，只泛称 "IR"，最终 lower 到 PTX/SASS

---

## 九、一句话总结

> **CuTe DSL = Hybrid DSL：利用「GPU kernel 运行时结构简单」，按时间分流 —— AST 在执行前给控制流插桩（管结构），Tracing 在 meta-stage 跑一遍录算术（管计算），两者在同一次执行里通过同一个 IR builder 缝成一棵 IR，再由后端 lower 成 GPU 二进制。** 各自避开死穴，同时拿到「结构保留 + 算术精确 + 动态 shape + 元编程 + Python 表达力」。理解的钥匙是 **"代码跑两遍"**：第1遍在 CPU 编译期用 proxy 搭 kernel，第2遍在 GPU 运行时用真数据执行。
