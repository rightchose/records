# 20. Core Matrix 与 SMEM 操作数寻址 —— LBO / SBO 两个步长

> 锚点：承接笔记 17(tma_smem_desc_mbarrier)、19(MMA 命名)。
> 主题：`tcgen05.mma`(UMMA) / `wgmma` 从 SMEM 取 A/B 操作数时，为什么描述符里要有
> **两个** byte offset(Leading dim / Stride dim)。一句话：**SMEM 操作数不是"扁平 2D 数组"，
> 而是"core matrix 拼出来的 2D 网格"，走网格需要两个步长。**

---

## 0. 一句话结论

| | 普通 2D 数组 | MMA 的 SMEM 操作数 |
|--|------|------|
| 最小单元 | 一个元素 | **一个 core matrix(小方块)** |
| 寻址 | 一个 stride(行 pitch) 就够 | **两个 offset(LBO + SBO)**，在 core matrix 网格里二维走位 |

普通数组一行连续 → 一个 stride；MMA 操作数是**块拼块的网格** → 两个 stride。

---

## 1. 为什么普通矩阵一个 stride 就够

内存里存规则 2D 数组，寻址是：

```
addr = base + row * leading_stride + col * elem_size
```

一行内连续，所以只需要一个 `leading_stride`(行间距)。**一个 stride 足以描述一个规则 2D 数组。**

---

## 2. MMA 操作数 = core matrix 平铺出的网格

tensor core 从 SMEM 读操作数，最小读取单元不是元素，而是一个固定小方块 —— **core matrix**：

- 典型 **8 行 × 16 字节 = 128 字节**；fp16 时就是 **8×8 个元素**。
- 一个完整的 M×K(A) 或 K×N(B) tile，是很多 core matrix 在**两个方向平铺**拼出来的：

```
[CM][CM][CM][CM]   ← 沿一个方向重复
[CM][CM][CM][CM]
[CM][CM][CM][CM]   ← 沿另一个方向重复
```

要在这个**二维的 core-matrix 网格**里定位第 (i, j) 个格子，一个步长不够，需要两个：

| 名字 | 含义 |
|------|------|
| **LBO** = Leading dimension byte offset | 沿**主方向(leading dim)**跳到相邻 core matrix，加多少字节 |
| **SBO** = Stride dimension byte offset | 沿**另一方向(stride dim)**跳到相邻 core matrix，加多少字节 |

硬件定位公式：

```
core_matrix_addr(i, j) = base + j * LBO + i * SBO
```

**两个网格维度 → 两个字节偏移。** 这就是 "two strides" 的由来。

---

## 3. 关键：两级寻址，LBO/SBO 只管"格子之间"

别把 LBO/SBO 理解成"逐元素的行/列 stride"。分两级：

- **第一级(粗，LBO/SBO 管)**：从 base 跳到某个 core matrix 的**起点**，网格级跳步。
- **第二级(细，硬件写死)**：进了一个 core matrix，那 8 行×16 字节内部怎么排、哪个线程读哪个元素，是 core matrix 的**固定内部布局**，描述符里**没有**这层 stride。

> 推论：LBO/SBO 的值几乎总是 **core matrix 大小的整数倍**(单位是"跳几个格子"，不是"跳几个元素")。

---

## 4. 数值例子：fp16, A(M×K), core matrix = 8×8 = 128B

取 A tile **M=16, K=16** → 正好 **2×2 core matrix 网格**。

### 4.1 K-major(K 连续，K 当 leading)

物理按"先沿 K、再沿 M"连续摆(每个 128B)：

| core matrix | 覆盖 | 地址 |
|---|---|---|
| CM(0,0) | M0-7,  K0-7  | 0   |
| CM(0,1) | M0-7,  K8-15 | 128 |
| CM(1,0) | M8-15, K0-7  | 256 |
| CM(1,1) | M8-15, K8-15 | 384 |

- 沿 K 跳一格(leading)：+128 → **LBO = 128**
- 沿 M 跳一格(stride)：+256 → **SBO = 256**
- `addr(i,j) = base + j*128 + i*256`；CM(1,1)=base+128+256=384 ✓

### 4.2 M-major(M 连续，M 当 leading)

唯一变的是"谁连续"。网格转向：

- 沿 M 跳一格(leading)：**LBO = 128**
- 沿 K 跳一格(stride)：**SBO = 256**

### 4.3 角色互换才是重点

| 想沿这个逻辑轴走一格 | K-major | M-major |
|---|---|---|
| 沿 **K** | LBO | SBO |
| 沿 **M** | SBO | LBO |

**同一个逻辑动作("沿 M 走"),挂到的 offset 从 SBO 变成了 LBO。** 这就是"leading/stride 谁是谁，随 major-order 翻转"。

---

## 5. 坑：正方 tile 数值撞车，非正方才现原形

上面 16×16 正方，两次算下来 LBO/SBO 都是 128/256，**角色换了、数值没换**，易误以为没区别。

换 **M=16, K=32**(M 方向 2 格、K 方向 4 格)：

| | leading | LBO | stride 方向要跨一整条 leading | SBO |
|--|--|--|--|--|
| K-major | K(4 格) | 128 | 沿 M 跨 4 格 K | **512** |
| M-major | M(2 格) | 128 | 沿 K 跨 2 格 M | **256** |

同一块逻辑数据，`SBO` 从 512 → 256。规律：

> **SBO = (leading 方向的 core matrix 格数) × (core matrix 大小)**
> = "跳过一整条 leading，进到 stride 方向下一排"。

leading 方向长度一变，SBO 就变；LBO 恒等于"沿连续方向跳一个 core matrix"。

---

## 6. 为什么要显式给出 —— swizzle

若 SMEM 是朴素排布，LBO/SBO 本可由逻辑维度推出。但真实操作数几乎都带 **swizzle**(打乱 core matrix 物理位置以消 bank conflict)。swizzle 后"沿 K 走一步"在物理地址上不再是干净的 `+128`。

把 LBO/SBO 做成描述符里的**显式字段**，硬件只管"照这两个偏移走网格"：

- **同一套读取逻辑，既吃朴素布局，也吃各种 swizzle 布局**；
- 上面第 4/5 节的干净整数倍是**无 swizzle** 前提；一开 swizzle 值就不再规整，但含义不变(仍是格子间跳步)。

---

## 7. 一句话索引

- **core matrix** = MMA 从 SMEM 取操作数的最小方块(典型 8 行×16B=128B，fp16=8×8)。
- 操作数 tile = core matrix 的**二维网格** → 需 **两个** offset 定位格子。
- **LBO**(leading) = 沿连续方向跳一个 core matrix；**SBO**(stride) = 跳过整条 leading、进 stride 方向下一排。
- **两级寻址**：LBO/SBO 管"跳到哪个格子"，格子**内部**布局硬件写死、不在描述符里。
- 谁当 leading **随 major-order 翻转**；`SBO = leading 格数 × core matrix 大小`，**随 tile 形状变**。
- 正方 tile 会让 LBO/SBO 数值撞车(角色仍互换)，非正方才看出差异。
- 显式化 LBO/SBO 是为了**兼容 swizzle**，让同一读取逻辑通吃各种物理布局。
