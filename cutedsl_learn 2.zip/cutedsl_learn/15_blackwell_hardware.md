# Blackwell 硬件学习笔记（B200 / B300 / TMEM）

> 主题：从硬件选型（命名层级、B200 vs B300 spec）到编程模型（TMEM/tcgen05）的 Blackwell 一代。
> 视角：服务于 FA4 kernel 工作——硬件改动如何解释 kernel 的调参/结构选择。
> ⚠️ 本笔记含若干「我先讲错、查证后纠正」的点，均原样保留并标 ⚠️，以代码/实测为准。

---

## 〇、一句话总览

```
Blackwell（B200/B300）相对 Hopper 的三个结构性新东西：
  ① 双 die 缝成一块逻辑 GPU（NV-HBI）
  ② FP4(NVFP4) 进 Tensor Core —— 推理/低精度时代的核心
  ③ tcgen05 + TMEM + 2CTA —— 累加器搬出寄存器，MMA 跨 2 SM

B300(Ultra) = B200 的「显存 + FP4 + SFU」加强版，代价是功耗和几乎砍光的 FP64。
```

---

## 一、命名层级（一通百通）

```
die ──▶ GPU ──▶ Superchip 模块 ──▶ NVL72 机柜
```

| 名字 | 是什么 | 组成 |
|------|--------|------|
| **B200 / B300** | 一颗 GPU | **2 个 die**（NV-HBI 缝成 1 块逻辑 GPU，软件透明） |
| **GB200 / GB300** | Superchip 模块 | 1 Grace CPU(ARM) + **2 颗** B200/B300（NVLink-C2C 900GB/s 连 CPU↔GPU） |
| **NVL72** | 一个液冷机柜 | 36 Grace + **72 颗** GPU，NVLink Switch 连成**一个统一显存域** |

- 区分两个「2」：**B200 内部 = 2 die → 1 GPU**；**GB200 = 1 CPU + 2 颗 GPU**（= 4 die）。
- 区分 B / GB：**B = 纯 GPU 芯片，GB = Grace CPU 抱着 Blackwell GPU 的整机模块。**
- NVL72 的「72」= 72 颗 GPU（36 模块 × 2）；NVLink Switch 让 72 颗对外像**一台巨型 GPU**（GB300 NVL72 ≈ 20TB 显存、1.1 EFLOPS FP4）。

---

## 二、B200 vs B300（Blackwell Ultra）

定性：**B300 不是新架构，是 B200 的 binned/优化加强版（SM 全开+高钟+更多显存+FP4 专项）。**

### 单卡 spec

| 维度 | B200 | B300 (Ultra) | 变化 |
|------|------|------|------|
| 芯片 / CC / SM | GB100 / 10.0 / SM100 | GB110 / 10.3 / **SM103** | Ultra 改版 |
| die | 2 | 2 | 不变 |
| **SM 启用数** | **148**（每 die 启用 74，物理 80，良率裁剪） | **160**（每 die 满血 80） | +8% |
| **HBM3e** | 192 GB | **288 GB** | **+50%**（12-hi 堆栈） |
| 带宽 | 8 TB/s | 8 TB/s | **不变**（推理拉不开差距的真因） |
| **Dense FP4** | 9 PFLOPS | **~15 PFLOPS** | **+56~67%** |
| **⭐ SFU exp** | 5 TExp/s | **10.7 TExp/s** | **翻倍**（加速 softmax） |
| BF16/FP16 | 2250 TFLOPS | 2500 TFLOPS | +11% |
| FP8 | 4500 TFLOPS | 5000 TFLOPS | +11% |
| **INT8 / FP64** | 高 | **降**（FP64: 37→1.25 TF 几乎砍光） | 被牺牲换 FP4 |
| 功耗 | 1000W | 1400W（GB300 机架） | 换吞吐 |
| 网络 | CX7 | CX8 1.6Tbps | 翻倍 |

### B300「加强」分布（一眼看清偏科）

```
显存   +50%  ⭐⭐⭐  （大模型/大batch/KV cache）
FP4    +60%  ⭐⭐⭐  （能用 NVFP4 才吃得到）
SFU exp 翻倍 ⭐⭐   （加速 attention softmax → FA4 关 ex2_emu）
BF16   +11%  ⭐     （几乎忽略）
FP8    +11%  ⭐     （几乎忽略）
带宽    0%          （没动）
INT8/FP64 降        （故意砍，腾资源给 FP4）
```

### 实战含义

- **BF16/FP8 训练**：两卡算力差仅 ~11%，**真正决策点是显存(288 vs 192GB)和成本**，不是吞吐。
- **能吃 FP4(NVFP4)**：B300 明显领先才值得上。
- **推理(token生成)**：受**显存带宽**约束、两者都 8TB/s → 差距基本消失，B200 性价比更优。
- 市场分化：**训练上 B300/GB300，推理 B200 更划算。**

### 钩子：SFU 翻倍 → FA4 在 SM103 关 ex2_emu

```
B200：SFU exp 5T，exp2 可能成瓶颈 → 需 ex2_emu 把部分分流到 FFMA
B300：SFU exp 10.7T（翻倍）→ exp2 不再瓶颈 → 全硬件 MUFU.ex2，关模拟
```
→ 硬件层面解释了 `flash_fwd_sm100.py:196` 给 SM103 **默认 freq=0（关 ex2_emu）**+ 独立 `_TUNING_CONFIG` key。

---

## 三、FP4 为什么提升这么大（含一处自我纠错）

### A. FP4 本身为什么快：位宽减半 → 吞吐翻倍

```
BF16 16bit(1+8+7)  →  FP8 8bit(1+4+3,E4M3)  →  FP4 4bit(1+2+1,E2M1，只有16个取值)
每减半位宽 → 同面积塞 2× MAC + 数据搬运减半 + 片上容量翻倍 → 吞吐 ×2
```
实测（arXiv 2512.02189）：FP8 3850 / FP4 7700 TFLOPS = **干净的 2.0×**（单次运算 datapath 比值）。

### B. ⚠️ 为什么 B300 的 FP4 又跳一大截（纠正我之前的说法）

**我先说错的**：「B300 把 FP4 datapath 加宽到 FP8 的 3×」——**不准确**。
**实测真相**：单次运算 datapath 仍是 **2×**（7700 vs 3850）。那个「3×」只出现在**整卡 dense PFLOPS 账面**（15 vs 5），不是物理通路比值。

**真正机制 = 资源再平衡（不是加宽通路）**：
```
B300 用「为 NVFP4 专门优化的新 Tensor Core」
  → NVFP4 dense +50%
  → 代价：牺牲 INT8 和 FP64
  → FP8/FP16 几乎没投资（+11%）
```

归因拆解（× 自洽验证）：
```
B300 FP4 +67% = ① 普惠(SM全开+高钟) ≈ +11%（BF16/FP8 同享）
              × ② NVFP4 专属优化   ≈ +50%（代价 INT8/FP64）★真因
              (1.11 × 1.50 ≈ 1.67 ✓)
```
⚠️ 关键：**②③(SM全开/高钟)是普惠项，BF16/FP8 也吃到（所以它们也 +11%）；FP4 偏科的唯一来源是 NVFP4 专项投资。** 别把普惠项算成 FP4 专属。

### C. 4-bit 怎么能用：NVFP4 microscaling（两级 scale）

```
真实值 ≈ FP4_value × block_scale(FP8 E4M3，每16元素一组) × tensor_scale(FP32 全局)
```
| | NVFP4 (NVIDIA) | MXFP4 (OCP 标准) |
|---|------|------|
| block | **16** 元素（更细） | 32 |
| scale | **FP8 E4M3**（非2的幂，更准） | E8M0（只能2的幂） |
- 硬件加速量化，精度逼近 FP8（差<1%），footprint 比 FP8 小 ~1.8× → 缓解带宽瓶颈。
- 论文：所有精度都跑到 96~99% 峰值 → **Tensor Core 不是瓶颈，带宽/launch 才是**；FP4 数据小正好解这个结。

---

## 四、TMEM：Hopper 的寄存器之痛 → Blackwell 的解（第三站·主菜）

### 痛点：Hopper 累加器堵在寄存器

```
wgmma 要 4 warp(一个 warpgroup)协同发 → 累加器 D 写进【线程寄存器】
  → 累加器越大越吃寄存器（每 SM 64K×32bit 死的）
  → TC 和 ALU 抢同一寄存器文件
  → ① tile 开不大  ② 流水线打不深
```
→ 接 memory 里「寄存器零和分配 512」：根子就在累加器和一切都挤寄存器。

### 解法：TMEM —— 给累加器单拉一块专属内存

```
存储层级(Blackwell)：HBM3e ──TMA──> SMEM ──> [MMA] ──累加器D──> TMEM ──> RegFile
                                                          ↑Blackwell新增第五块
```
**硬规格**（arXiv 2512.02189 实测）：
- **256 KB / SM**，专属；结构 = **512 列 × 128 lane** 32-bit 阵列；累加器透明 row-major
- **读 16 TB/s / 写 8 TB/s / SM**；端到端访问 **420 cycle**（比 Hopper 全局内存 1000 cycle 降 58%，**绕过 L2 争用**）

### Blackwell 用 TMEM 解了 Hopper 的什么

| Hopper 痛点 | TMEM 解法 |
|------|------|
| 累加器挤寄存器 | 搬到 TMEM，**寄存器解放**，ALU 不再和 TC 抢 |
| tile 开不大 | 累加器不占寄存器 → tile 放大到 **256×256×16（跨 2 SM）** |
| 流水线打不深 | 不污染寄存器 → write-out 流水叠更深 |
| 4 warp 集体发指令 | 累加器脱离线程 → **单线程发 MMA**，硬件内部分发 |
| 复杂 TV layout | TMEM 透明 row-major → **不用再操心 wgmma 的 thread-value layout** |
| 功耗/带宽 | TMEM 物理靠近 TC → 更省电 + **带宽与 SMEM 叠加(additive)不争抢** |

最深刻的是**累加器所有权从线程解耦** → 能跨 warpgroup 存活 → FA4 的 softmax/correction/MMA 才能拆不同 warpgroup 各干各的。

### 代价：TMEM↔Reg 往返（Hopper 没有）

```
Hopper：累加器在寄存器 → epilogue 直接在寄存器上算，零搬运
Blackwell：自定义 epilogue(如 softmax修正) 要 TMEM→Reg→算→写回TMEM→等完成
          且每个 warp 只能访问 ¼ TMEM → epilogue 要一整个 warpgroup
```
→ **FA4 的 correction warpgroup 就是干这个**：把累加器从 TMEM 拉出来做 softmax 修正再写回。Hopper 顺手就改了，Blackwell 得专门一组 warp 来回搬。

---

## 五、TMEM 在存储体系的定位（两处概念纠错）

### TMEM 和 SMEM 是「并列」不是「上下游」

```
   SMEM ──取操作数A/B──┐
   (片上)              ▼
                  [Tensor Core/MMA]
   TMEM ──取操作数A────┘ ▲│累加器D写回
   (片上,256KB) ◄────────┘
```
- 操作数可从 **SMEM 或 TMEM** 喂；累加器 D **只回 TMEM**。
- **带宽相加不相争**（additive）：TMEM = 在 SMEM 之外**再开一条专供 TC 的高速路**，不替代 SMEM。
- TMEM 紧挨 L2 但**绕过 L2 争用**（420 cycle 低延迟来源）。

### ⚠️ 纠错一：8 vs 3.8 TB/s 是「TMEM vs GMEM」，不是「TMEM vs SMEM」

```
TMEM 8 TB/s（片上） vs ld.global 3.8 TB/s（含片外 GMEM 路径） → 2.1×
```
- 这是 on-chip vs off-chip，**跨层，不能用来定位 TMEM 相对 SMEM**。只说明「累加器留片上别 spill 到 GMEM」。
- **TMEM vs SMEM 的同层带宽对比，论文没给** → 无法给硬数字，只能定性（带宽叠加）。

### ⚠️ 纠错二：TMEM 的 16/8 TB/s 测的是「访问 TMEM 本身」，不含 GMEM/SMEM 搬运

- 那带宽/420 cycle = Tensor Core 直接读写 TMEM 这一段，**不经 GMEM、不经 SMEM**。
- TMEM 主角是**累加器 D（MMA 当场算出、就地写回）**，不是从 GMEM 搬来的。

### tile 效率甜区（调 tile 用）

```
< 32×32   → 仅 45% 峰值带宽（太小）
64×64     → 最优（FP8 下 4KB）★
> 128×128 → 有效吞吐反降 30%（太大）
```

---

## 六、tcgen05 操作数放置 + 怎么进 TMEM

### 操作数放置规则（非对称）

`D = A·B + D`：
| 操作数 | 能放哪 |
|------|------|
| **累加器 D** | **只能 TMEM**（MMA 就地写回） |
| **A (LHS)** | **SMEM 或 TMEM**（二选一） |
| **B (RHS)** | **只能 SMEM**（且需 NVMMASharedLayout） |

- **SS 模式**：A、B 都 SMEM（最常用）；**TS 模式**：A 在 TMEM、B 在 SMEM。
- ⚠️ 纠正前述「输入都从 TMEM」的误解：**默认大家从 SMEM 喂，只有 A 可选 TMEM，B 必须 SMEM。**

### 怎么把数据弄进 TMEM —— 没有 GMEM 直达

```
GMEM ──TMA──> SMEM ──tcgen05.cp──> TMEM
              (中转站，必经)
```
tcgen05 三条搬运指令：
| 指令 | 方向 | 用途 |
|------|------|------|
| **tcgen05.cp** | **SMEM → TMEM** | 拷 A / scale factor 进 TMEM（异步） |
| tcgen05.ld | TMEM → Reg | epilogue 读累加器出来算 |
| tcgen05.st | Reg → TMEM | 算完写回 |

- **cp 和 mma 共享内部流水线，不用手动同步**：同一条「tcgen05 pipeline」按发射顺序执行，MMA 自动等最后一条 cp 完成 → 这个拷贝得由**发 MMA 的那个线程**发。
- **sub-byte(FP4) 时 cp 顺带格式转换**：`GMEM(packed) ─TMA(unpacking)─> SMEM(16B对齐) ─cp(可解压)─> TMEM(1字节容器padding)`。UMMA 要求 sub-byte（含 4-bit）padding 到 1 字节容器。

---

## 六·五、2CTA / cta_group::2 的好处（已坐实，本地 MatmulTutorial 铁证）

来源：`MatmulTutorial/examples/matmul/this-sm100/`（level1 naive → level6 优化，中文 README+注释）
+ FA4 `flash_fwd_sm100.py:167-169`。

### 操作数怎么切（level6 注释 verbatim）
> "BLOCK_M=256… With cta_group::2 UMMA_M=256, each SM handles 128 output rows.
> **SM0 reads A[0:127], SM1 reads A[128:255].**"

```
┌──────── Cluster (2 CTAs) ────────┐
│ CTA0(SM0)          CTA1(SM1)     │
│  A[0:128]           A[128:256]   │  ← A 按 M 切（私有，各算各半）
│  B（一份，pair 共用，喂法见下）   │  ← B 是共享操作数
│      └─── tcgen05.mma.cta_group::2 ───┘  仅 leader CTA 发这一条
│  TMEM M[0:128]     TMEM M[128:256]│  ← 累加器按 M 切，跨 2 SM 的 TMEM
└───────────────────────────────────┘
```
- **A = 私有操作数**：按 M 切，每 SM 只用自己半区，无跨 CTA 访问。
- **B = 共享操作数**：两个 M 半区都要完整 B → 整个 pair 逻辑上只需一份 B。
- **累加器**：跨两 SM 的 TMEM，各 128 行（解决单 SM 128-lane 装不下 M=256）。
- **仅 leader 发 MMA**：level6 warp 角色 "MMA issue (1 elected thread, leader CTA only)"；FA4 `:858/:1674` 同。

### ⚠️ B 怎么"喂"给两 SM —— 两种策略，别只记一种
我之前在这写死了"B 按 N 切、半份+跨 CTA 互访"，**那只是 MatmulTutorial 这一种喂法**，不通用。坐实的有两条路：

| 策略 | 谁用 | B 怎么到位 | 跨 CTA 访问 |
|------|------|-----------|-------------|
| **(a) split + peer SMEM read** | 本地 `MatmulTutorial` level6 | B 按 N 切，每 CTA 只 `tma_load` 半份(`LOAD_N_PER_CTA=BLOCK_N/2`)进自己 SMEM；`cta_group::2` MMA 用 **CTA-local 14-bit descriptor offset**(`addr & 0x3FFF`) 让硬件把同一偏移**铺到 pair 内两个 SM** → leader 读到的"另一半 B"实际在 peer SM 的 SMEM | **有**（硬件级 peer SMEM 读，descriptor 编码的是本地偏移） |
| **(b) TMA multicast** | CUTLASS DSL `dense_gemm.py:609-614` | `create_tma_multicast_mask(mcast_mode=1)` 把整份 B **广播到 cluster 内每个 CTA 的 SMEM** → 各 CTA 本地就有完整 B | **无**（multicast 已把数据搬到本地） |

- **peer SMEM read 不是"Blackwell UMMA 的普遍行为"**，是策略(a)的产物。策略(b)靠 multicast 提前把数据搬本地，MMA 不需跨 CTA 读。
- 共同点：**HBM→片上只搬一份 B**（无论 split 后互访 还是 multicast 广播），所以"B 流量减半"在两条路都成立。
- DSL 把这层抽象进 `tiled_mma`，看不到 PTX；硬 peer-read 证据只在 MatmulTutorial 裸 PTX（或 cutlass C++ `cute/atom/mma_traits_sm100*`，尚未读）。
- ⚠️ **诚实欠债**：策略(a)的 peer-read 已由 MatmulTutorial 代码坐实；但"硬件能跨 SMEM 读"作为 ISA 级保证，仍欠 PTX ISA / cutlass C++ atom 的正式引用。

### 好处（按重要性）
| 好处 | 机制 | 量化 |
|------|------|------|
| ① B 操作数复用 | B 被两 M 半区共用，pair 只把 B 搬到片上一份（split 后互访 或 multicast 广播，见上表）；两个独立 1SM 各搬整份 | **B 流量减半** |
| ② 算术强度翻倍 | M 拼 256，同样 B 喂出 2× MAC | FLOP/byte↑，抗 memory-bound |
| ③ TMEM/算力池化 | 两 SM 的 128-lane TMEM 拼成 M=256 累加器 | 更大 tile |
| ④ 少发指令 | leader 一条 vs 两条 | 可忽略 |

### ⚠️ 反着的铁证：level1 的 BUG = "两个 CTA 做一样的事"
```
level1(错): BLOCK_M=128 却喂 UMMA_M=256 → 两 CTA 加载【相同 A】
            → SM1 算冗余/越界垃圾 → README 实测"冗余计算50%，浪费一半算力"，仅 torch 5.4%
level6(对): BLOCK_M=256，A 真按 M 切两半 → "Eliminates ~50% tensor core waste"
```
→ "2CTA 两个 CTA 各算各的一样的东西"**是 naive 写法的 BUG**，正确写法靠 A 按 M 切让两 SM 各算有效半区。

### ⚠️ 修正我之前的话
之前说"B 共享是 multicast 的功劳、跟 2CTA 无关"**说过头**：B 共享和 2CTA 是**咬合**的——
正因 cta_group::2 把 M 拼 256、两半区共用同一份 B，B 复用才翻倍。multicast 是"怎么搬 B"的手段，
2CTA 是"为什么 B 只需搬一份"的结构原因。

---

## 七、异步执行模型：mbarrier / pipeline（串起整条数据旅程的底座）

> Blackwell 把"搬运(TMA)/计算(MMA)/读写(tcgen05)"全做成**异步**——发出去就走、硬件后台干。
> 谁来保证"用之前数据已到/算之前依赖已完成"？答案是 **mbarrier**（片上软件信号量）。
> 没有它，2CTA 跨 SM 协作、warp-specialization 全塌。

### mbarrier 是什么（8 字节 SMEM 对象，解剖）
```
一个 mbarrier = SMEM 里一个 8-byte(b64) 对象，内部三段状态：
  ┌────────────┬──────────────┬─────────────────────┐
  │ phase bit  │ arrival count│ pending tx-count    │
  │ (奇偶相位) │ (线程到达数) │ (TMA 待传字节数)    │
  └────────────┴──────────────┴─────────────────────┘
两种"完成"判据，谁清零谁说了算：
  ① arrival-count：线程 mbarrier.arrive 逐个到 → 凑齐 init_count
  ② tx-count    ：mbarrier.arrive.expect_tx N → TMA 搬够 N 字节自动减到 0
MMA 的完成走第三条路：tcgen05.commit 把 MMA 完成信号挂到 mbarrier。
```
- init：`mbarrier.init.shared::cta.b64 [bar], count`（count = 期望到达数）。
- 生产者：`mbarrier.arrive.expect_tx`（TMA 前声明要搬多少字节）或纯 `arrive`（线程到达）。
- 消费者：`mbarrier.try_wait.parity [bar], phase` 自旋等翻转。

### phase parity：barrier 无限复用的关键（⚠️ 我之前讲反过，已纠正）
```
barrier 不重新 init 就能无限轮复用 —— 靠 phase bit 翻转区分"第几轮"。
phase 序列：0 → 1 → 0 → 1 ...（每凑齐一次条件就翻一次）

⚠️ try_wait.parity(p) 里的 p = 「当前正在进行、即将被完成的那个 phase」
   不是翻转后的新值！
第1次：当前 phase=0，等的人传 0，看到从 0 翻成 1 → 放行
第2次：当前 phase=1，等的人传 1，看到从 1 翻成 0 → 放行
所以等待方传的 parity 序列 = 0,1,0,1... = 当前 phase 值本身。
```
- 代码里常见 `phase ^ 1` 来回拨：因为同一个 barrier 在生产/消费两侧、或跨循环迭代，看到的"当前 phase"交替。
- MatmulTutorial level6：`barrier_wait(empty_bar[stage], phase ^ 1)` —— 这个 `^1` 是"首轮跳过"技巧（empty_bar 初始就算满，第一次别真等）。

### full_bar / empty_bar 生产者-消费者流水（多 stage 软件流水）
```
full_bar[stage] ：生产者(TMA load)填满 stage → arrive，消费者(MMA)等它
empty_bar[stage]：消费者用完 stage → arrive，生产者等它腾空再填
            ┌── TMA load ──► full_bar.arrive ──► MMA 消费
   stage N  │                                      │
            └◄── empty_bar.arrive ◄── MMA 用完 ────┘
```
- 这就是软件多级流水(double/triple buffering)：N 个 stage 的 SMEM 缓冲轮转，full/empty 一对 barrier 卡两端。
- "parity trick"首轮跳过：empty_bar 初值设成"已满"，第一次 wait 直接过，避免冷启动死等。

### Blackwell 2SM/cluster 扩展（普通 mbarrier 装不下跨 SM）
2CTA 协作要让"对面 SM"也知道数据/计算到了，mbarrier 加了 cluster 作用域：

| 机制 | PTX | 干什么 |
|------|-----|--------|
| **2SM commit** | `tcgen05.commit.cta_group::2.mbarrier::arrive::one.shared::cluster.multicast::cluster.b64 [bar], 0x3` | MMA 完成同时给 pair 内**两个 CTA** 的 barrier 都发信号（mask 0x3 = 两位都点） |
| **remote arrive** | `mapa.shared::cluster` 算出 peer barrier 地址 + `mbarrier.arrive...shared::cluster` | 给**别的 CTA** 的 barrier 投递到达（跨 CTA 唤醒） |
| **TMA 完成路由** | TMA 的 barrier 地址 `& PEER_BIT_MASK(0xFEFFFFFF)` | 把 TMA 完成信号**路由到 leader 的 barrier**（注意：只改 barrier 地址，不改数据落点；每个 CTA 仍写自己 SMEM） |
| **full_bar init** | `init_count = CLUSTER_SIZE`（=2） | 跨 CTA 的 barrier 要等齐整个 cluster |

- ⚠️ **PEER_BIT_MASK 只作用于 barrier 地址**，不是数据目的地——数据仍各写各的 SMEM（level2 README 实证）。
- FA4 对应：TMEM 跨 CTA 释放要 cluster mbarrier（memory 笔记 `:874-879`）；非 MMA warp 按**整 cluster** 计数（`:897-907`）。

### mbarrier vs "async barrier"：不是两种东西，是两层抽象
```
async barrier = 概念/C++ API 层（cuda::barrier，arrive/wait 语义）
mbarrier      = 实现它的 PTX 原语（SMEM 里那个 8 字节对象）
```
"async barrier"是抽象语义，"mbarrier"是落到 PTX 的硬件原语——**不同抽象层级，不是并列的两套机制**。

### 演进时间线（别一股脑算 Hopper）
```
Ampere(sm80) ：基础 mbarrier / async barrier（arrival-count + phase）
Hopper(sm90) ：+ tx-count(expect_tx) + cluster 作用域（为 TMA 而生）
Blackwell    ：+ 2SM commit multicast / tcgen05 与 mbarrier 咬合
```

### 坑
- **phase parity 传错值** → 永久 hang 或提前放行读到脏数据（传"翻转后"而非"当前"）。
- **tx-count 算错**（2CTA 忘 ×cta_group_size）→ TMA 永远凑不满 N，barrier 不翻 → hang（memory 笔记 `:557` tx_count×2）。
- **TMEM 提前释放**：cluster mbarrier 没等齐就 free → 对面 SM 还在用（DEBUG_2CTA.md）。

---

## 八、named barrier vs mbarrier（CTA 内便宜同步 vs 通用软件信号量）

> 两个都叫"barrier"但完全不同档次。选错要么白白慢、要么根本同步不了跨 CTA。

| 维度 | **named barrier**（`bar.sync` / `__syncthreads`） | **mbarrier** |
|------|------|------|
| 本质 | **硬件寄存器** barrier | **SMEM 软件对象**（8 字节信号量） |
| 数量 | 每 CTA 仅 **16 个**（id 0-15） | SMEM 能放多少放多少（几乎无限） |
| 作用域 | **CTA 内**（出不了 CTA） | CTA / **cluster 跨 CTA** 都行 |
| 计数对象 | 只能数**线程**（且 count 必须是 warp 整数倍） | 线程(arrive) + **字节(tx-count)** + **MMA(commit)** |
| 相位复用 | 无（每次就是一道墙） | **phase parity** 无限轮复用 |
| 开销 | **极便宜**（1 条指令，硬件计数） | 较贵（SMEM 读写 + 自旋 try_wait） |
| 典型用途 | warpgroup 内/CTA 内线程会合 | 异步搬运/跨 CTA/生产者消费者流水 |

### 选型铁律
```
要跨 CTA / 等 TMA 字节 / 等 MMA → 只能 mbarrier（named 根本做不到）
纯 CTA 内一堆线程碰个头、立刻往下走 → 用 named barrier（便宜，1 指令）
```
- MatmulTutorial level6：epilogue 收尾用 `named_barrier_sync`（`EPILOGUE_BAR_ID=1`, 128 线程）——纯 CTA 内会合，没必要上 mbarrier。
- FA4 warp-specialization：warpgroup 内同步可用 named；跨 warpgroup 经 TMEM/跨 CTA 必走 mbarrier。
- `__syncthreads()` = named barrier id 0 的特例（整个 CTA 所有线程）。

---

## 九、SASS 级实测：看 kernel 真实寄存器 / 指令（调优收尾的"验尸刀"）

> 前面所有"寄存器零和 512 / freq 调 SFU↔FFMA / tile 多大"都是**推断**。
> 真相只有一处：编译出来的 **SASS（GPU 真实机器码）**。CuTeDSL JIT 默认把 cubin 藏在内存，要把它抠出来反汇编。

### 抠 cubin → 反汇编流程
```
① 留住编译产物：环境变量 CUTE_DSL_KEEP_CUBIN=1
   → JIT 不再用完即焚，把 .cubin 落盘（配合 CUTE_DSL_KEEP_* 系列，见 10 笔记）
② 反汇编：nvdisasm -c <file>.cubin      # -c 按控制流分块，可读性好
   或     cuobjdump -sass <file>.cubin  # 直接吐 SASS
③ 看寄存器用量：cuobjdump --dump-resource-usage  /  nvcc -Xptxas -v（编译期打印）
   或在 SASS 头部找 "REG:" 行 / ptxas info: "Used N registers"
```

### 看什么（对上前面的推断）
| 想验证的推断 | SASS 里看什么 |
|------|------|
| 寄存器零和 512、setmaxnreg 真生效 | 每 warp `Used N registers`；找 `setmaxnreg` 指令（增/减配额） |
| exp2 走 SFU 还是模拟(ex2_emu) | 数 **`MUFU.EX2`**(硬件 SFU) vs 一串 **`FFMA`**(多项式模拟) 的条数比 |
| MMA 真发的是 cta_group::2 | 找 `UTCMMA`/`tcgen05` 系 SASS（或 PTX 层 `tcgen05.mma.cta_group::2`） |
| TMEM 读写 | `tcgen05.ld/st` 对应 SASS、`UTCLDG` 类指令 |
| 是否寄存器溢出(spill) | ptxas info 的 "spill stores/loads" 字节数（非 0 = 溢出到 local，性能杀手） |
| 占用率瓶颈 | 寄存器/线程 × 线程数 vs 64K → 算 occupancy；寄存器太多 → 活跃 warp 少 |

### 和"搬运 vs 计算"第一问接上（14 笔记 §五）
```
拿到陌生 kernel：
  1) ncu/nsight 先定 memory-bound 还是 compute-bound（roofline）
  2) 若 compute-bound 且怀疑 SFU：dump SASS 数 MUFU.EX2 vs FFMA → 验证 ex2_emu 调参方向
  3) 若怀疑寄存器压力：ptxas -v 看 spill / Used registers → 验证 setmaxnreg 分配
```
- FA4 调 `ex2_emu_freq`、`num_regs_softmax` 的本质，就是反复 dump SASS + 锁频 benchmark 实测（`tune_ex2_emu.py` 两 phase 扫，memory 笔记），**无解析解，SASS+计时是唯一裁判**。
- ⚠️ **PTX ≠ SASS**：PTX 是中间表示（虚拟 ISA），ptxas 还会再优化/分配寄存器。要看"真实跑的"必须落到 SASS，别拿 PTX 的寄存器数当真。

---

## 十、还差什么（缺口地图，待续）

### 第三站没讲完（强相关，欠的）
- [ ] **tcgen05 MMA 指令本身**：单线程发射、UMMA、MMA atom 形状（对应 `flash_fwd_sm100.py:465`）
- [x] ~~2CTA / CTA pair~~ → 见 §六·五（已坐实操作数切法+好处）
- [ ] **TMA**：全程在用却没正经讲；multicast/cluster 版关系 2CTA 的 tx_count×2
- [x] ~~异步执行模型：mbarrier / pipeline~~ → 见 §七（mbarrier 解剖/phase parity/full-empty 流水/2SM 扩展）

### 纯硬件没碰（中相关）
- [ ] Cluster / DSMEM（2CTA 跨 CTA 访问的物理基础）
- [ ] L2 cache / 内存子系统（TMEM「绕过 L2 争用」的背景）
- [ ] 双 die 一致性（NV-HBI 跨 die 访存代价）
- [ ] HBM3e / 带宽墙（推理 bound 的真因）
- [ ] 硬件解压引擎

### 大概率超需求（低相关）
NVLink5/Switch 拓扑、Grace C2C、MIG/机密计算、RAS、功耗散热、Rubin 路线图

### 建议的收尾
```
补「2CTA + TMA + 异步/mbarrier」三件套 → 凑齐完整数据旅程（checklist §4 / M3 里程碑硬件版）：
GMEM ─TMA─> SMEM ─cp─> TMEM ─MMA─> 累加 ─ld─> Reg(softmax) ─st─> TMEM ─epilogue─> GMEM
            ↑也是 2CTA 跨 SM 协作的舞台，mbarrier 串起整条异步流水
```

---

## 十一、一句话总结

> **Blackwell = 双die缝成一块GPU + FP4进TensorCore + 累加器搬进TMEM。** B300(Ultra,SM103) 是 B200(SM100) 的「显存+50% / FP4+60% / SFU翻倍」加强版，BF16/FP8 仅+11%、FP64砍光——FP4 偏科来自**NVFP4专项投资(牺牲INT8/FP64)**而非通路加宽(单次datapath仍2×)。**TMEM** 是为解 Hopper「累加器挤寄存器」而生的 256KB 专属片上内存（读16/写8 TB/s、420cyc、绕L2、与SMEM带宽叠加），换来寄存器解放/更大tile/单线程发MMA/不用操心TV layout，代价是自定义epilogue要付 TMEM↔Reg 往返（FA4 correction warpgroup 就在付）。进 TMEM **没有GMEM直达**：TMA落SMEM → tcgen05.cp拷进TMEM（FP4还顺带解压）；操作数默认从SMEM喂，仅A可选TMEM、B必须SMEM、累加器D只在TMEM。**2CTA(cta_group::2)** 把 M 拼 256、A 按 M 私有切、B pair 内只搬一份(split+peer-read 或 multicast 两种喂法)、累加器跨两 SM TMEM、仅 leader 发指令——好处主在算术强度/B复用而非少指令。整条异步流水靠 **mbarrier**(8字节SMEM对象：phase+arrival+tx-count)串起，phase parity 无限复用(传"当前phase"非翻转值)，Blackwell 加 2SM commit/cluster 作用域；CTA 内便宜会合用 **named barrier**(硬件16个/CTA)，跨CTA/等TMA/等MMA 才上 mbarrier。调优最终裁判是 **SASS**(`CUTE_DSL_KEEP_CUBIN`+`nvdisasm`/`cuobjdump`)：数 MUFU.EX2 vs FFMA 验 ex2_emu、看 Used registers/spill 验 setmaxnreg——PTX≠SASS。

### 来源
- arXiv 2512.02189《Microbenchmarking NVIDIA's Blackwell Architecture》（TMEM 实测延迟/带宽）
- NVIDIA Technical Blog《Inside NVIDIA Blackwell Ultra》（160 SM、NVFP4）
- Tom's Hardware《Blackwell Ultra secrets — NVFP4 boost detailed》（FP4 +50% 牺牲 INT8/FP64）
- Colfax Research CUTLASS Tutorial 系列（操作数放置、tcgen05.cp/ld/st、2-SM UMMA、sub-byte）：
  - Part1 TMEM: https://research.colfax-intl.com/cutlass-tutorial-writing-gemm-kernels-using-tensor-memory-for-nvidia-blackwell-gpus/
  - Part2 Thread Block Clusters / 2-SM UMMA: https://research.colfax-intl.com/cutlass-tutorial-gemm-with-thread-block-clusters-on-nvidia-blackwell-gpus/
  - Sub-byte GEMM: https://research.colfax-intl.com/cutlass-tutorial-sub-byte-gemm-on-nvidia-blackwell-gpus/
  - Block-scaling: https://research.colfax-intl.com/cutlass-tutorial-hardware-supported-block-scaling-with-nvidia-blackwell-gpus/
- 本地 `MatmulTutorial/examples/matmul/this-sm100/`（level1 naive→level6 优化，2CTA 操作数切法/50%浪费、mbarrier full/empty 流水/phase parity、named_barrier_sync 的一手代码+中文 README；level2 PEER_BIT_MASK 只作用 barrier 地址的实证）
- 本地 CUTLASS DSL `cutlass/examples/python/CuTeDSL/cute/blackwell/kernel/dense_gemm/dense_gemm.py`（2cta 用 TMA multicast 喂 A/B：`:609-614` mcast mask；`:486/:494` use_2cta/leader 判定）
- 本地 FA4 `flash_attn/cute/blackwell_helpers.py` + `flash_fwd_sm100.py`（cta_group::2 PTX、mma_tiler M 翻倍）
- SASS 实测：`CUTE_DSL_KEEP_CUBIN`（见 10 笔记）+ `nvdisasm -c` / `cuobjdump -sass` / `ptxas -v`（数 MUFU.EX2 vs FFMA、Used registers/spill）
