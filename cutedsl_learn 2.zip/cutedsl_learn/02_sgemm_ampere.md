# CuTe DSL 进阶：Ampere SIMT SGEMM 知识点总结

源文件：`cutlass/examples/python/CuTeDSL/cute/ampere/kernel/dense_gemm/sgemm.py`

## 一、概述

这是一个 **FP32 SIMT GEMM** (C = A * B) 的完整实现，面向 Ampere (SM80) 架构。

**核心特性**：
- FPU（而非 Tensor Core）做 MMA
- 多阶段流水线 (multistage pipeline)：smem pipeline + register pipeline
- 向量化搬运 (vectorized copy)
- Shared memory padding 减少 bank conflict
- Predication 处理边界

**默认配置**：
- Tile shape: `128×128×8` (BLK_M × BLK_N × BLK_K)
- num_stages: 3（smem 流水线深度）
- num_threads: 256

---

## 二、整体架构

```
┌──────────────────────────────────────────────────────────┐
│  Host 端 (__call__)                                       │
│  1. 构造 sA/sB layout（含 padding）                       │
│  2. 构造 tiled_copy_A/B（gmem→smem 搬运策略）             │
│  3. 构造 tiled_mma（计算策略）                             │
│  4. 计算 grid/block → launch kernel                      │
├──────────────────────────────────────────────────────────┤
│  Kernel 端                                               │
│  1. local_tile: 按 block 索引取 tile                      │
│  2. partition: 分配 copy/mma 给各线程                      │
│  3. predicate: 构造边界检查 mask                           │
│  4. prologue: 预取 k-tile 到 smem                         │
│  5. mainloop: smem pipeline + register pipeline + gemm   │
│  6. epilogue: 结果写回 gmem                               │
└──────────────────────────────────────────────────────────┘
```

---

## 三、知识点详解

---

### 知识点 1：Shared Memory Layout 与 Padding

```python
padding_a = 4 if self.a_major_mode == utils.LayoutEnum.ROW_MAJOR else 0
sA_layout = cute.make_layout(
    (self._bM, self._bK, self._num_stages),
    stride=(1, (self._bM + padding_a), self._bK * (self._bM + padding_a)),
)
```

**三个维度**：
- `(bM, bK, num_stages)` = `(128, 8, 3)`
- 第 3 维 `num_stages` 是 smem 流水线的 buffer 数量

**Padding 的作用**：
- 当 A 是 K-major (row-major) 时，多个线程沿 M 方向读 smem 会命中同一 bank
- 加 4 个元素的 padding 错开 bank，消除 conflict

```
无 padding:  stride = (1, 128, 128*8)    → 同一列的线程间隔 128 = 4*32 bank，冲突！
有 padding:  stride = (1, 132, 132*8)    → 间隔 132，不是 32 的整数倍，无冲突
```

**sA 始终是 M-major (stride[0]=1)**：因为 MMA 需要沿 M 方向连续读取。

---

### 知识点 2：TiledCopy 构造 — gmem→smem 异步搬运

```python
# 线程布局
tA = cute.make_layout(
    (self._num_threads // self._bK, self._bK), stride=(self._bK, 1)
)
# 值布局
vA = cute.make_layout((1, 1))  # 默认标量搬运

# Copy atom: cp.async 指令
atom_async_copy_A = cute.make_copy_atom(
    cute.nvgpu.cpasync.CopyG2SOp(),
    mA.element_type,
    num_bits_per_copy=mA.element_type.width,  # 32 bits for fp32
)

# 组合成 TiledCopy
tiled_copy_A = cute.make_tiled_copy_tv(atom_async_copy_A, tA, vA)
```

**线程排布逻辑**：
- `tA` shape = `(256/8, 8)` = `(32, 8)`
- 32 个线程负责 M 方向，8 个负责 K 方向
- 整体 256 线程覆盖 tile 的 128×8 = 1024 个元素（每线程搬 4 个）

**向量化优化（当 A 是 M-major 时）**：
```python
num_vectorized = 4  # 128-bit = 4×fp32
atom_async_copy_A = cute.make_copy_atom(
    cute.nvgpu.cpasync.CopyG2SOp(),
    mA.element_type,
    num_bits_per_copy=mA.element_type.width * num_vectorized,  # 128 bits
)
vA = cute.make_layout((num_vectorized, 1))  # 每线程一次搬 4 个 fp32
```

**关键参数 `num_bits_per_copy`**：控制每次 `cp.async` 搬运的宽度（32/64/128 bits）。

---

### 知识点 3：TiledMMA 构造 — SIMT FPU 计算

```python
atoms_layout = cute.make_layout(
    (self._num_threads // 16, 16, 1), stride=(16, 1, 0)
)
op = cute.nvgpu.MmaUniversalOp(cutlass.Float32)
permutation_tiler_M = cute.make_layout((atoms_layout.shape[0], 4), stride=(4, 1))
permutation_tiler_N = cute.make_layout((atoms_layout.shape[1], 4), stride=(4, 1))
tiled_mma = cute.make_tiled_mma(
    op,
    atoms_layout,
    permutation_mnk=(permutation_tiler_M, permutation_tiler_N, None),
)
```

**`MmaUniversalOp`**：最基本的 FMA (fused multiply-add)，1×1×1 的 MMA atom。

**`atoms_layout`**：线程如何排列在 M×N 空间上
- `(16, 16, 1)` for 256 threads: 16 threads along M, 16 along N

**`permutation_tiler`**：重排元素的访问顺序
- 每个线程处理 4 个连续元素（而不是间隔 1 个）
- 优化 smem→rmem 的搬运模式，让每线程读取的数据连续

```
无 permutation: T0 T1 T2 ... T15 T0 T1 T2 ... T15 ...
有 permutation: T0 T0 T0 T0 T1 T1 T1 T1 T2 T2 T2 T2 ... T15×4
```

---

### 知识点 4：`local_tile` — GEMM 的 tile 切分

```python
gA = cute.local_tile(
    mA, tiler=self._cta_tiler, coord=tiler_coord, proj=(1, None, 1)
)
# gA: (BLK_M, BLK_K, k)
```

**与 `zipped_divide` 的区别**：`local_tile` 直接取出指定坐标的 tile 并保留迭代维度。

**参数解析**：
- `tiler=(128, 128, 8)`: CTA tile 尺寸 (M, N, K)
- `coord=(bidx, bidy, None)`: 用 blockIdx 索引 M 和 N，K 维度保留为迭代维
- `proj=(1, None, 1)`: 投影掩码
  - A 是 (M, K): 需要 M 和 K 维度 → `proj=(1, None, 1)` (跳过 N)
  - B 是 (N, K): 需要 N 和 K 维度 → `proj=(None, 1, 1)` (跳过 M)
  - C 是 (M, N): 需要 M 和 N 维度 → `proj=(1, 1, None)` (跳过 K)

**结果 shape**：
```
gA: (BLK_M, BLK_K, k) = (128, 8, K/8)   — 沿 K 方向有 k 个 tile
gB: (BLK_N, BLK_K, k) = (128, 8, K/8)
gC: (BLK_M, BLK_N)    = (128, 128)       — 没有 K 维度
```

---

### 知识点 5：`domain_offset` — 处理 K 残余

```python
residue_k = mA.shape[1] - self._bK * gA.shape[2]
gA = cute.domain_offset((0, residue_k, 0), gA)
gB = cute.domain_offset((0, residue_k, 0), gB)
```

**问题**：K 不能被 bK 整除时，最后一个 k-tile 不完整。

**策略**：把不规则的 tile 移到**第 0 个**（而不是最后一个）：
- 偏移指针，让第 0 个 tile 从 `residue_k` 位置开始
- 第 0 个 tile 只有 `residue_k` 个有效元素（用 predicate 处理）
- 后续 tile 都是完整的，主循环不需要额外的边界检查

```
原始:  [tile0_full][tile1_full]...[tileN_partial]  ← 最后一个不完整
偏移后: [tile0_partial][tile1_full]...[tileN_full]  ← 第一个不完整，主循环无忧
```

---

### 知识点 6：Partition 与 Predication

```python
thr_copy_A = tiled_copy_A.get_slice(tidx)
tAgA = thr_copy_A.partition_S(gA)   # Source: gmem 中当前线程负责的部分
tAsA = thr_copy_A.partition_D(sA)   # Destination: smem 中当前线程负责的部分
```

**Predicate tensor 构造**：
```python
mcA = cute.make_identity_tensor(mA.shape)
cA = cute.local_tile(mcA, ...)           # 同样的 tile 切分
tAcA = thr_copy_A.partition_S(cA)        # 同样的线程 partition

# 主循环的 predicate: 只检查 M 方向
tApA[rest_v, m, 0] = elem_less(tAcA[...][0], mA.shape[0])

# 残余 k-tile 的 predicate: 检查 M 和 K 方向
tApA_residue_k[rest_v, m, k] = elem_less(
    (coord_A[0], -1), (mA.shape[0], coord_A[1])
)
```

**两层 predicate 的设计**：
- `tApA`: 只检查 M/N 边界，K 方向保证完整 → 用于主循环
- `tApA_residue_k`: 同时检查 M/N + K 边界 → 只用于第 0 个不规则 tile

**`pred` 参数 stride 设计**：
```python
stride=(..., ..., 0)  # K 维度 stride=0，同一组 predicate 对所有 k 复用
```

---

### 知识点 7：Smem Pipeline — 多阶段异步预取

```python
# Prologue: 预取前 (num_stages-1) 个 k-tile
cute.copy(tiled_copy_A, tAgA[..., 0], tAsA[..., 0], pred=tApA_residue_k)
cute.arch.cp_async_commit_group()

for k_tile in range(1, k_pipe_max - 1):
    cute.copy(tiled_copy_A, tAgA[..., k_tile], tAsA[..., k_tile], pred=tApA)
    cute.arch.cp_async_commit_group()
```

**流水线结构 (3-stage)**：
```
时间 →
smem buf 0: [load tile0] ────── [compute tile0] [load tile3] ──── ...
smem buf 1: ── [load tile1] ──── [compute tile1] [load tile4] ── ...
smem buf 2: ────── [load tile2] ──── [compute tile2] [load tile5] ...
```

**关键 API**：
- `cute.arch.cp_async_commit_group()`: 提交一组 cp.async 操作
- `cute.arch.cp_async_wait_group(N)`: 等待直到未完成的 group ≤ N
  - `wait_group(k_pipe_max - 2)` = `wait_group(1)`: 最多 1 个未完成，保证我要读的 buffer 已就绪

---

### 知识点 8：Register Pipeline — smem→rmem 预取

```python
tCsA = thr_mma.partition_A(sA)   # 按 MMA 模式 partition smem
tCrA = tiled_mma.make_fragment_A(tCsA[..., 0])  # 寄存器 fragment
tCrB = tiled_mma.make_fragment_B(tCsB[..., 0])
tCrC = tiled_mma.make_fragment_C(tCgC)          # 累加器

# 预取第 0 个 k_block 到寄存器
cute.autovec_copy(tCsA_p[None, None, 0], tCrA[None, None, 0])
```

**Register pipeline 的逻辑**：
```python
for k_block in range(k_block_max):
    # 1. 预取下一个 k_block 的数据到寄存器 (produce i+1)
    k_block_next = (k_block + 1) % k_block_max
    cute.autovec_copy(tCsA_p[..., k_block_next], tCrA[..., k_block_next])
    cute.autovec_copy(tCsB_p[..., k_block_next], tCrB[..., k_block_next])

    # 2. 用当前 k_block 的数据做 gemm (consume i)
    cute.gemm(tiled_mma, tCrC, tCrA[..., k_block], tCrB[..., k_block], tCrC)
```

**好处**：消除寄存器的数据依赖（读 i+1 和计算 i 可以并行）。

**`autovec_copy`**：自动向量化的 smem→rmem 拷贝，选择最优宽度。

---

### 知识点 9：Mainloop — 双层流水线交织

```python
for _ in range(k_tile_count):           # 外层：遍历 K 方向的所有 tile
    for k_block in range(k_block_max):  # 内层：tile 内的 K 分块
        if k_block == k_block_max - 1:
            # 切换 smem buffer，等待新数据就绪
            cute.arch.cp_async_wait_group(k_pipe_max - 2)
            self.cta_sync_barrier.arrive_and_wait()

        # register pipeline: 预取下一个 k_block
        cute.autovec_copy(tCsA_p[..., k_block_next], tCrA[..., k_block_next])
        cute.autovec_copy(tCsB_p[..., k_block_next], tCrB[..., k_block_next])

        if k_block == 0:
            # smem pipeline: 发起下一个 tile 的 gmem→smem copy
            cute.copy(tiled_copy_A, tAgA[..., gmem_pipe_read], tAsA[..., smem_pipe_write], pred=tApA)

        # 计算
        cute.gemm(tiled_mma, tCrC, tCrA[..., k_block], tCrB[..., k_block], tCrC)

        if k_block == 0:
            cute.copy(tiled_copy_B, tBgB[..., gmem_pipe_read], tBsB[..., smem_pipe_write], pred=tBpB)
            cute.arch.cp_async_commit_group()
            # 更新 smem read/write 指针
```

**交织策略**：
```
k_block == 0 时:  copy_A → gemm → copy_B → commit
其他 k_block:     prefetch_reg → gemm
最后 k_block:     wait_group + sync（为下一轮准备）
```

**为什么 copy_A 和 copy_B 分开放在 gemm 两侧**：
更好地交错内存访问和计算指令，提高指令级并行度 (ILP)。

---

### 知识点 10：Epilogue — 结果写回

```python
# 等待所有 cp.async 完成
cute.arch.cp_async_wait_group(0)
self.cta_sync_barrier.arrive_and_wait()

# 应用 epilogue 操作（如激活函数）
tCrC.store(epilogue_op(tCrC.load()))

# 构造写回的 predicate
cC = cute.make_identity_tensor(gC.shape)
tCpC = thr_mma.partition_C(cC)
predC = cute.make_rmem_tensor(tCrC.layout, cutlass.Boolean)
residue_m = mC.shape[0] - self._bM * bidx
residue_n = mC.shape[1] - self._bN * bidy
for i in range(cute.size(tCrC.shape)):
    predC[i] = cute.elem_less(tCpC[i], (residue_m, residue_n))

# 写回 gmem
atom = cute.make_copy_atom(cute.nvgpu.CopyUniversalOp(), mC.element_type)
cute.copy(atom, tCrC, tCgC, pred=predC)
```

**关键点**：
- `epilogue_op`: 可插入自定义后处理（如 ReLU、scale 等）
- 写回用 `CopyUniversalOp`（普通 store），不用 cp.async
- Predicate 使用 `residue_m/n` 做边界检查（比直接用 shape 更高效）

---

### 知识点 11：`@cute.jit` 与 `@cute.kernel` 的配合

```python
class SGemm:
    @cute.jit        # Host 端 JIT：构造 layout、launch kernel
    def __call__(self, mA, mB, mC, ...):
        ...
        self.kernel(...).launch(grid=..., block=...)

    @cute.kernel     # Device 端：实际 GPU kernel
    def kernel(self, mA, mB, mC, ...):
        ...
```

**两层分离**：
- `@cute.jit`: JIT 编译 host 端逻辑（计算 layout、grid/block 等）
- `@cute.kernel`: JIT 编译 device 端 kernel（在 GPU 上执行）

---

### 知识点 12：`cute.compile` — 预编译

```python
compiled_fn = cute.compile[cute.GenerateLineInfo](
    sgemm, a_tensor, b_tensor, c_tensor, stream=current_stream
)
```

- 预编译 kernel，避免首次调用时的编译延迟
- `cute.GenerateLineInfo`: 生成调试行号信息（方便 ncu profiling）
- 返回 compiled function，后续调用直接执行

---

### 知识点 13：`mark_layout_dynamic` 与 `mark_compact_shape_dynamic`

```python
a_tensor = from_dlpack(a, assumed_align=16)
    .mark_layout_dynamic(leading_dim=(1 if a_major == "k" else 0))
    .mark_compact_shape_dynamic(mode=..., divisibility=...)
```

- `mark_layout_dynamic`: 标记某个维度的 stride 是动态的（运行时确定）
- `mark_compact_shape_dynamic`: 标记某个维度的 shape 是动态的，并指定对齐性
- `assumed_align=16`: 告诉编译器数据至少 16 字节对齐 → 可以生成向量化 load

这些信息帮助 JIT 编译器做更好的特化：静态部分编译期优化，动态部分保持灵活。

---

### 知识点 14：`NamedBarrier` — CTA 内同步

```python
self.cta_sync_barrier = pipeline.NamedBarrier(
    barrier_id=1, num_threads=num_threads
)
# kernel 中使用：
self.cta_sync_barrier.arrive_and_wait()
```

相当于 `__syncthreads()`，但使用命名 barrier（Ampere+ 支持多个独立 barrier）。

---

## 四、数据流全景

```
Global Memory
  │
  │  cp.async (tiled_copy_A/B, 128-bit vectorized)
  ▼
Shared Memory (3-stage pipeline, with padding)
  │  sA: (128, 8, 3)  sB: (128, 8, 3)
  │
  │  autovec_copy (register pipeline)
  ▼
Register File
  │  tCrA: fragment_A    tCrB: fragment_B
  │
  │  cute.gemm (FPU FMA, MmaUniversalOp)
  ▼
Register File
  │  tCrC: accumulator (fp32)
  │
  │  epilogue_op → CopyUniversalOp (scalar store)
  ▼
Global Memory (mC)
```

---

## 五、与 Elementwise Add 的对比

| 方面 | Elementwise Add | SGEMM |
|------|----------------|-------|
| 内存层级 | gmem → rmem → gmem | gmem → smem → rmem → gmem |
| 流水线 | 无 | smem pipeline + register pipeline |
| Copy 方式 | CopyUniversalOp (标量) | CpAsyncOp (cp.async, 向量化) |
| 计算 | 标量加法 | TiledMMA (FPU FMA) |
| K 维度 | 无 | 循环遍历 K tiles |
| 同步 | 无 | cp_async_wait_group + barrier |
| 边界处理 | identity_tensor + elem_less | predicate tensor + domain_offset |
| Tile 切分 | zipped_divide | local_tile |

---

## 六、总结：GEMM Kernel 的标准骨架

```
1. Host 端构造:
   - sA/sB layout (含 padding)
   - tiled_copy (选 copy atom + 向量化)
   - tiled_mma (选计算 atom + 线程排布)
   - grid/block 配置

2. Kernel 结构:
   ┌─ local_tile: 按 blockIdx 取 tile
   ├─ partition: 分配给各线程
   ├─ predicate: 构造边界 mask
   ├─ prologue: 预取前 N-1 个 stage
   ├─ mainloop: 双层流水线 (smem + register)
   │   ├─ copy next tile (gmem → smem)
   │   ├─ prefetch next k_block (smem → rmem)
   │   ├─ gemm (rmem 计算)
   │   └─ wait + sync
   └─ epilogue: epilogue_op + predicated store
```
