# Blackwell 双 die 拓扑：SM 与地址的 die 映射及跨 die 访存代价（学习笔记）

> 来源：知乎专栏文章「Blackwell 双 die 拓扑：SM 与地址的 die 映射及跨 die 访存代价」（作者 reed，中科院理学博士，收录于「CUDA高性能编程」）
> 主题：Blackwell 是 NVIDIA 第一代「多 die 封装为单一逻辑 GPU」的数据中心架构。本文用**纯 CUDA 微基准**反推出两套隐藏映射——SM→die、address→die，并量化跨 die 访存代价（+220 ns 延迟 / +42% 带宽）。
> 关联：本笔记是 NV-HBI / 封装内 NUMA 讨论从「定性推断」落到「可闭式计算 + ncu 可验证」的实测版。

---

## 〇、一句话总览

```
Blackwell 单 GPU = 封装内双路 NUMA（2 个 die，各连本地 HBM，NV-HBI 缝合）
  die ↔ CPU socket        本地 HBM ↔ 本地 DIMM      NV-HBI ↔ UPI/Infinity Fabric

三句话核心：
  ① 信号用「延迟」不用「带宽」—— NV-HBI(≥10TB/s) 比单 die 本地 HBM(~4TB/s) 还宽，
     访存只要均摊到两 die，聚合带宽看不出 die 边界；只有单次延迟暴露那多走的一跳。
  ② address→die 有闭式解 —— 8 位 popcount + 512 字节常量表 + 8GiB 反相位。
  ③ SM→die 必须逐卡推导 —— 74/74 划分普适，但 smid 标号每张卡不同。
```

为什么要拆 die：单 die 受 **reticle limit(~800mm²) 面积墙** + **良率随面积超线性下降** 两条硬约束，拆两颗小 die 高带宽缝合是标准做法，代价是引入 die 边界（本地 vs 跨边界两种访存）。

---

## 一、双 die 拓扑与硬件特点

| 项 | 单颗 die | 整颗 B200 |
|---|---|---|
| GPC | 4 | 8 |
| SM | ~74 | 148 |
| L2 partition | 2（与本侧内存控制器同侧） | 4（Hopper 的 2 倍） |
| 内存控制器 | 4 | 8 |
| HBM3e 堆栈 | 4，~4 TB/s 本地带宽 | 8 |
| die 间互连 | — | NV-HBI，聚合 ≥10 TB/s |
| 整芯片峰值带宽 | — | ~8 TB/s（HGX 7.7 / NVL72 8.0） |

**关键点 1：L2 按 die 切分**。4 个 partition 每 die 占两个，与本侧内存控制器同侧。一颗 die 要用另一颗 die 缓存/拥有的数据时，**取数 + 两侧 L2 一致性流量都必须经 NV-HBI** → NV-HBI 承载的不只是远端 HBM 读写，还有跨 die 缓存一致性，是这颗封装内 NUMA 唯一的跨域通路。

**关键点 2（反直觉）：带宽不是好观测量**。NV-HBI(≥10TB/s) > 单 die 本地 HBM(~4TB/s)。所以：
- CPU NUMA 上跨 socket「既增延迟又降带宽」，绑远端跑带宽测试即暴露。
- Blackwell 上访存只要大致均摊在两 die，无非两组控制器各出一半力，**聚合带宽不因「跨了 die」明显下降**。
- ⚠️ 要用带宽暴露 die 边界，必须人为控制每次访问落哪颗 die，而 **CUDA 没有按 die 申请内存的接口**。
- → 因此全文以**延迟**为主信号（跨 die 多出的那一跳）。这是整套方法论的起点。

NVIDIA 把双 die 细节封在驱动内，对程序员只暴露「一颗逻辑 GPU」，无任何查询 SM→die / address→die 的接口。**全部归属信息靠用户态微基准反推。**

---

## 二、测量原语：一次干净的冷 HBM 访问延迟

整套方法的量具 = 测准「从指定 SM 发出、到指定地址的单次冷 HBM 延迟」。四件事必须同时解决：

1. **冷访问**：每次计时前流式扫过远超 L2 的无关数据驱逐缓存；计时核只访问一次、不预热 → 第一跳就是冷访问。
2. **不被预取/重叠掩盖**：单线程串行依赖式访问（每拍地址依赖上一拍返回值）→ 测的是真实 load-to-use 延迟。
3. **归属到确定物理 SM**：申请 > 单 SM 一半容量的动态 shared memory，保证一个 SM 只驻留一个 block，块读自身 `%smid` 上报。
4. **单位稳定性**：DVFS 会让频率波动 → 主度量用对频率不变的 **cycles/hop**，每段测量前后各测一次实际频率剔除存疑样本。

```cpp
int v = 0;
int64_t t0 = clock64();
do {
  v = ldg_cv(input);
} while (v < 0);   // 强制 load retire 后才出循环
int64_t t1 = clock64();
output[0] = v;     // sink 写，阻止编译器消除计时
```
⚠️ **do-while + sink 写是关键**：否则 ptxas 会把第二次 `clock64` 排到 LDG 发射之后立即执行，而 LDG 异步 retire，只会测到 issue 时刻而非 retire 时刻。加上二者，`t1-t0` 才是干净的冷 HBM 延迟。

---

## 三、SM→die：干净的 74/74

方法：固定一个足够小的地址（16B 访问必完整落单 die，不跨边界），148 个 SM 各访问一次。延迟只取决于 SM 与该地址是否同 die。

结果（直方图）：**两条零重叠 band**，跨 die 比同 die 多约 **+400 cyc（~+220 ns）**，每条各 74 个 SM。

如何证明这是 SM 的固有属性而非该地址偶然：换多个落在不同 die 的独立地址重做，每个都给出清晰两组 band，且**同一 SM 在所有地址上始终落在相对的同一组**（对本 die 地址快、对另 die 地址慢，从不摇摆）→ 二分是 SM 自身的稳定属性（它所在的 die）。

→ SM→die 标签表确定可复用：对任意新地址只做一次单 SM cold load 探测，即可读出该地址在哪 die。按物理 smid 排布的映射是**确定、周期性、架构固定**的（前段每 16 SM 一行模式一致，越过中部边界后规律性旋转），可一次性导出为常量表供 kernel 入口查表。

---

## 四、address→die：三层确定性结构

量尺与被测对象互换：用已知 die 的 SM 扫地址，延迟落哪条 band 就读出地址在哪 die。沿连续地址滑动 → 三层确定结构（G = granularity，自底向上）：

### G0 = 4 KiB：die 分配原子单位
16B 步长细扫：边界精确落 4 KiB 处，**单步翻转无过渡区**（偏移 4095→4096，延迟从 +400cyc 直接跳到 −400cyc）。每个 4KiB 段整段属同一 die，跨 4KiB 即翻 die。

### G1 = 2 MiB polarity tile：8 个地址位奇偶决定
```
mask 0x1EF000 = bits {12,13,14,15, 17,18,19,20}   (bit 16 被跳过!)
die_intra(addr) = popcount(addr & 0x1EF000) & 1
```
- 每个 2MiB 块（称 chunk）恰好 256 段属 die-0、256 段属 die-1。
- 128 chunk / 65376 样本验证，符合率 **100%**。
- 沿 512 段序号看，die 标签是序号在这 8 位上的 popcount 奇偶 → **Thue-Morse 式交替序列**。
- **作用**：用地址位奇偶细粒度交织，把任意规则 stride 访问均摊到两 die，避免固定 stride 与 die 划分共振、把负载系统性压到单 die。
- ⚠️ **不对称掩码后果**（4 连续位 + 跳过 bit16 + 4 连续位）：**相距 64 KiB 同 die（popcount 不变），128 KiB 才翻 die（bit17 翻转）**。bit16 跳过原因未完全解释，「可能某种 HBM/FBPA 条带 hash 在 64KiB 处相消」。
- 每 chunk 只有两种互补内部排布（互为按位取反），用 1-bit **polarity** 记录：`整块图样 = die_intra(addr) ^ tile_polarity`。

### G2：chunk 的 polarity 取自固定序列，分配只决定切入点
- polarity **不是每次分配现掷的硬币**，而是物理 chunk 池本身的属性：`cudaMalloc(4GiB)` 的 2048 位 polarity 与逐个 `cuMemCreate(2MiB)` 申请 2048 块得到的逐位一致。
- 分配只是按顺序从池取块 → 必然复刻池的 polarity 排列。
- ⚠️「按顺序」是关键：同一段 VA 两次分配未必拿同一物理 chunk，polarity 序列也未必相同。
- 唯一自由度 = 一次分配从序列哪里切入（**全局 cursor**）：顺序分配每次前进一个分配大小；`cudaFree` 还块回池，下次同尺寸分配优先复用 → 反复 alloc/free 在少数起点轮转（≥1GiB 实测 **K=2 个 zone 交替**）。

### 三层合一：闭式判据
```
die(addr) = popcount(addr & 0x1EF000) & 1        // G0+G1: 8 位地址奇偶（立即可算）
          ^ chunk_polarity[chunk_idx mod 4096]   // G2: 4096 位(512字节) per-arch 常量表
          ^ (chunk_idx >> 12) & 1                // G2: 每 8 GiB 反相位
// chunk_idx = ((addr - alloc_base) >> 21) + O,  O = 该分配进入序列的起点
```
- **第二项** `chunk_polarity[]`：4096 位常量覆盖连续 8 GiB（4096 chunk），无更短闭式，须测出；100GiB 实测 51182/51200 匹配（余 18 位探针噪声）。
- **第三项** `(chunk_idx>>12)&1`：每越 8 GiB 边界整张表翻转一次（base / ~base / base ...），正负交替铺满全空间 → 4096 位 base + 1 位奇偶足以描述 B200 全 192 GiB。
- **per-arch 非 per-card**：跨卡 8191/8192 一致（余 1 位噪声），扫一次即可作代码常量永久用。
- **per-allocation 的只有起点 O**：分配入口对前 ~32 chunk 各探测一次、与常量表最佳匹配定出，<1 秒。

---

## 五、跨卡：结构普适，标号逐卡

- 同卡重复测量：SM→die 完全一致，确定性。
- 多卡：**双 die 结构普适**（每卡严格 74/74 + 同量级跨 die 延迟差），但 **smid→die 标号逐卡不同**（差异可微小、也可涉及绝大多数 SM）。
- 原因：die 划分是硅片层硬件常量；smid 只是运行时暴露物理 SM 的逻辑编号，很可能在制造/固件阶段为良率 binning（屏蔽失效 SM）设定，未文档化。
- ⚠️ 工程后果：**SM→die 不能跨卡假定一致，必须逐设备推导**（即便两卡碰巧一致也不能据此推广）。同卡推导一次即稳定；多 GPU 作业每进程各自推导本地映射。

---

## 六、die 亲和放置与只读带宽（核心收益）

构造干净测试内存：用 VMM 逐个申请 2MiB 物理块、探 polarity，只留 polarity=0 的块拼成整段 → 判据退化为 `die(addr) = popcount(addr & 0x1EF000) & 1`，不查表即可算任一地址 die。

kernel：`<<<148, 1024>>>` + 200KiB 动态 shared memory（每 SM 仅驻留 1 block，148 块铺满 148 SM），只读流式聚合到寄存器、工作集远超 L2、不写回 → 带宽饱和。只改「哪个块读哪些段」对应表：

| 映射 | 输入带宽 | 占 ~7.7TB/s 峰值 |
|---|---|---|
| **die-affinity**（只读本 die 段） | 6226 GB/s | 77.8% |
| **cudaMalloc**（~50% 随机跨 die） | 5800 GB/s | 72.5% |
| **die-anti**（只读对侧 die 段） | 4396 GB/s | 55.0% |

**affinity vs anti = +42% 带宽**，代价仅 kernel 入口一次 SM→die 查表。cudaMalloc 干净落中段（随机极性的预期位置）。

### 机理：+220ns 延迟为何放大成 +42% 带宽
- 两种配置 HBM 控制器侧负载**对等**（各扛一半总流量）；差异**只在中间那一跳**。
- 由 **Little 定律**：吞吐 ≈ 在飞请求数 ÷ 有效服务时间。anti 下每条 LDG 多走 NV-HBI 一跳 + 两侧 L2 各做一次 sector 查找 → 有效服务时间上升；NV-HBI 虽宽但被双向流量同时占用。
- → 空载下不显眼的单次延迟差，在**饱和下被排队效应放大**成可观带宽差。
- 跨 die 惩罚本质 = **同一份请求两次占用沿途资源**，不是单次访问慢多少。

### ncu 指纹：NV-HBI 在 L2 fabric 之上
三配置 SM 侧指标（指令/占用/scoreboard）、DRAM 实读字节全相同，唯一变化是 **L2 sector 放大**：
```
L2 sectors / L1 sectors = 1 + cross_die_fraction
  affinity(0%): 1.00×   cudaMalloc(~50%): 1.50×   anti(100%): 2.00×
```
解读：每条跨 die LDG 在**请求方 die 的 L2（未命中转发）+ 归属方 die 的 L2（未命中下 HBM）**各查一次 sector。
→ 路径钉死为：`SM → 本 die L2 → NV-HBI → 远 die L2 → HBM`。
**NV-HBI 不是挂旁边的总线，而是把两颗 die 的 L2 缝成一块分布式缓存的链路。**

> 注：148×1024 + 200KiB smem 是为「每 SM 唯一对应 1 block」干净归因选的形态，非带宽最优；提高 occupancy 或用 TMA 能进一步提高绝对带宽，但上述机理（双 L2 占用、1×/1.5×/2× 放大）同样成立。

---

## 七、工程可用性与局限

**可用性**：放置不依赖调度器——每块入口读 `%smid`→查 die→选对应 die 数据区，调度顺序不可知也无妨。即使不做精细逐块亲和，**仅把数据均分到两 die 轮用，就已显著优于全部倾斜到单 die 的退化情形**（一个对 die 无感的分配器 + 恰好与 polarity 共振的 stride 就会造成倾斜）。

**两处待解决**：
1. **分配侧**：实测的是 cudaMalloc/cuMemCreate；业务常经 **PyTorch caching allocator / cudaMallocAsync / unified memory**，这些下 polarity 与 cursor 是否同样确定**未验证**。折中：把 die 感知**下沉进分配器**（底层按 die 维护两池，对上层暴露常规接口，按调用方所在 die 选池）。
2. **地址侧**：address→die 虽可闭式求解，仍需先知某段数据在哪 die（分配时记录 / canonical 序列加偏移推算 / VMM 拼 polarity=0 内存）。

**未覆盖**：sub-1GiB 分配的 zone 数 K、内存压力/多进程行为、非 cudaMalloc 路径。
**前提**：硬件确实以足够粗粒度按 die 划分内存；若未来某代更细交织、跨 die 惩罚低于可分辨阈值，则 die 感知放置失去意义，应转以聚合带宽为优化目标（本文测量流程本身能识别这种情形）。
**未测的二阶收益**：基准全程冷（L2 命中≈0）；跨 die 访问会瞬态在两 die 的 L2 各占一 line，极限下 die 亲和等价于**把 L2 有效容量翻倍**——待工作集驻留型 kernel 量化。

---

## 八、对照「定性 NUMA 讨论」的修正点

| 之前的定性说法 | 本文实测修正 |
|---|---|
| 「跨 die 让有效带宽达不到两 die HBM 相加峰值」 | ⚠️ **需修正**：均摊**不掉**带宽（HBI 比本地 HBM 还宽）；掉带宽来自**错配时路径双占用在饱和下的排队放大**，不是均摊本身 |
| 「跨 die 多一跳延迟」 | ✅ 量化为 **+400 cyc / ~+220 ns** |
| 「L2 按 die 切分」 | ✅ 4 partition 每 die 两个，与本侧内存控制器同侧 |
| 「HBI 承载缓存一致性，不只远端 HBM 读写」 | ✅ ncu 的 1.5×/2× L2 sector 放大是直接指纹 |
| 「程序员一般不直接控 die 放置（无 API）」 | ✅ CUDA 无按 die 申请内存接口，全靠微基准反推 |

---

## 九、和 CuTeDSL / FA4 的关联（延伸思考，非原文）

- FA4 的 **2CTA（cta_group::2）** 让 cluster 内两 CTA 共享 TMEM accumulator、靠 cluster mbarrier 协作。若两 CTA 跨 die，协调流量过 NV-HBI → 硬件/runtime 倾向把一个 cluster 放单 die 内，这解释了 cluster_shape/tile 调度在 Blackwell 上对性能敏感。
- 对写 kernel 的实践心态：**平时按单 GPU 写，出现「带宽打不满 / 扩展不线性 / 延迟反常」且常规手段查不出时，把"它其实是双 die NUMA"当排查假设拉出来。**
