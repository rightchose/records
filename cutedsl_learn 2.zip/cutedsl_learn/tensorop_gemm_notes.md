# CuTe DSL 学习笔记 — tensorop_gemm.py

基于 `cutlass/examples/python/CuTeDSL/cute/ampere/kernel/dense_gemm/tensorop_gemm.py` 的学习总结。

Ampere Tensor Core GEMM，使用 `mma.m16n8k16` 指令，128×128×32 tile，3-stage pipeline。

---

## 1. 整体 Kernel 结构

```
┌─────────────────────────────────────────────────┐
│ 1. Block swizzle + 获取当前 block 的 tile       │
│ 2. 分配 shared memory                          │
│ 3. Partition：每个线程知道搬哪些数据             │
│ 4. Predication（边界检查）                      │
│ 5. Prologue：预填充 smem pipeline（2个stage）   │
│ 6. Mainloop：smem pipeline + register pipeline  │
│ 7. Epilogue：累加器 → smem → global memory      │
└─────────────────────────────────────────────────┘
```

---

## 2. Host 端（`@cute.jit __call__`）

### 2.1 三种 Copy Atom

| 阶段 | 硬件指令 | API |
|------|---------|-----|
| Global → Smem | `cp.async` 128-bit | `cute.nvgpu.cpasync.CopyG2SOp()` |
| Smem → Register | `ldmatrix.sync.aligned.m8n8.x4` | `cute.nvgpu.warp.LdMatrix8x8x16bOp(trans, 4)` |
| Register → Global | 普通 store 128-bit | `cute.nvgpu.CopyUniversalOp()` |

### 2.2 Copy Atom 层次结构

```
make_copy_atom       → 最小原语（1条指令搬的量）
    ↓
make_tiled_copy_*    → 用线程布局平铺 atom，覆盖整个 tile
    ↓
tiled_copy.get_slice(tidx)  → 当前线程的视角
    ↓
partition_S / partition_D    → 切出源/目标的分片
    ↓
cute.copy(atom, src, dst)   → 实际执行搬运
```

### 2.3 `_make_gmem_tiled_copy_AB`

将 copy atom 铺展成覆盖 tile 的方案——决定线程如何协作搬完整个 tile：

```python
copy_elems = copy_bits // dtype.width       # 128/16 = 8 元素/次
thread_layout = (num_threads//K_atoms, K_atoms)  # 线程沿连续方向排列 → coalesced
value_layout = (1, copy_elems)              # 每线程搬 1行×8列
return cute.make_tiled_copy_tv(atom_copy, thread_layout, value_layout)
```

核心原则：**相邻线程映射到内存连续方向 → coalesced access**。

### 2.4 Tiled MMA

```python
op = cute.nvgpu.warp.MmaF16BF16Op(ab_dtype, acc_dtype, (16, 8, 16))

permutation_mnk = (
    atom_lay_M * 16,         # = 32  M 方向覆盖
    atom_lay_N * 8 * 2,      # = 32  N 方向覆盖（×2 为了 ldmatrix 效率）
    atom_lay_K * 16,         # = 16  K 方向覆盖
)

tiled_mma = cute.make_tiled_mma(op, atom_layout_mnk=(2,2,1), permutation_mnk=permutation_mnk)
```

- `atom_layout_mnk=(2,2,1)`：4 个 warp 协作（2×2×1）
- `permutation_mnk=(32,32,16)`：一次 tiled_mma 计算 32×32×16 的分块

### 2.5 Block Swizzle（Threadblock Rasterization）

重排 block 调度顺序，让相邻执行的 block 形成小矩形，最大化 L2 cache 复用：

```python
rasterization_remap_grid_dim = (
    grid_dim_m * raster_factor,
    ceil(grid_dim_n / raster_factor),
    grid_dim_l,
)
# kernel 内还原真实坐标:
def raster_tile(i, j, f):
    return (i // f, (i % f) + (j * f))
```

### 2.6 Smem Layout（带 Swizzle 消除 Bank Conflict）

```python
swizzle_bits = min(log2(major_mode_size * dtype.width // copy_bits), 3)
layout_atom = cute.make_composed_layout(
    cute.make_swizzle(swizzle_bits, 3, 3), 0, layout_atom_outer
)
layout = cute.tile_to_shape(layout_atom, smem_tiler, (0, 1, 2))
```

Swizzle 对 smem 地址做 XOR 变换，让相邻行数据分散到不同 bank，消除 ldmatrix 的 bank conflict。

---

## 3. Kernel 内部

### 3.1 获取当前 Block 的 Tile

```python
gA = cute.local_tile(mA[None, None, bidz], tiler=cta_tiler, coord=tiler_coord, proj=(1, None, 1))
gB = cute.local_tile(mB[None, None, bidz], tiler=cta_tiler, coord=tiler_coord, proj=(None, 1, 1))
gC = cute.local_tile(mC[None, None, bidz], tiler=cta_tiler, coord=tiler_coord, proj=(1, 1, None))
```

- `local_tile` = `zipped_divide` + 索引
- `proj`：选择 tiler 中哪些维度参与（A 参与 M,K；B 参与 N,K；C 参与 M,N）
- 结果：`gA:(128, 32, k_tiles)`, `gB:(128, 32, k_tiles)`, `gC:(128, 128)`

### 3.2 K Residual 处理

```python
residual_k = K - BLK_K * k_tiles   # 负数
gA = cute.domain_offset((0, residual_k, 0), gA)   # 指针往 K 负方向偏移
gA = cute.make_tensor(gA.iterator.align(16), gA.layout)  # 声明对齐
```

把不规则的 K 放在第一个 tile（prologue 处理），mainloop 保持无分支全速运行。

**前提约束**：K 是连续维度且元素数是 8 的倍数 → residual_k 是 8 的倍数 → 有效 atom 的地址一定 16B 对齐。

### 3.3 Shared Memory 分配

```python
storage = smem.allocate(
    max(SharedStorageAB.size_in_bytes(), SharedStorageC.size_in_bytes()),
    byte_alignment=16,
)
sA = SharedStorageAB(storage).a.get_tensor(sA_layout)   # 带 swizzle
sB = SharedStorageAB(storage).b.get_tensor(sB_layout)
sC = SharedStorageC(storage).c.get_tensor(sC_layout)
```

- AB 和 C **复用同一块 smem**（时间上不重叠）
- `max` 取较大者，减少 smem 占用 → 提升 occupancy

### 3.4 Partition（线程分工）

```python
# Global → Smem 搬运分工
thr_copy_A = tiled_copy_A.get_slice(tidx)
tAgA = thr_copy_A.partition_S(gA)    # 源(gmem)
tAsA = thr_copy_A.partition_D(sA)    # 目标(smem)

# MMA 分工 + 分配寄存器
thr_mma = tiled_mma.get_slice(tidx)
tCrA = tiled_mma.make_fragment_A(...)  # A 寄存器
tCrB = tiled_mma.make_fragment_B(...)  # B 寄存器
tCrC = tiled_mma.make_fragment_C(...)  # 累加器
tCrC.fill(0.0)

# Smem → Register 搬运分工（ldmatrix）
tiled_copy_s2r_A = cute.make_tiled_copy_A(atom_copy_s2r_A, tiled_mma)
thr_copy_ldmatrix_A = tiled_copy_s2r_A.get_slice(tidx)
tCsA_copy_view = thr_copy_ldmatrix_A.partition_S(sA)   # smem 源
tCrA_copy_view = thr_copy_ldmatrix_A.retile(tCrA)      # register 目标（视角转换）
```

**`retile` vs `partition_D`**：寄存器 fragment 没有地址空间，只需要换视角（MMA视角 ↔ ldmatrix视角），不是重新切分内存。

### 3.5 Predication（边界检查）

三个维度不同处理方式：

| 维度 | 处理方式 | 原因 |
|------|---------|------|
| M | `tApA` predicate tensor, stride=(m_size, 1, 0 on K) | M 边界与 K 无关 |
| N | `tBpB` predicate tensor, stride=(n_size, 1, 0 on K) | N 边界与 K 无关 |
| K | `if` 分支（只在第一个 tile） | residual 只影响第一个 tile |

Predicate tensor 中 stride=0 的维度 → 共享同一组 pred，节省寄存器。

### 3.6 Prologue（预填充 Pipeline）

```python
# Stage 0: 处理 K residual
tAsA.fill(0)  # 预清零
for k in range(CPY_K):
    if cute.elem_less(Int32(-1), tAcA[0,0,k,0][1]):  # K坐标 > -1?
        cute.copy(tiled_copy_A, tAgA[...,k,0], tAsA[...,k,0], pred=tApA[...,k])
cp_async_commit_group()

# Stage 1: 正常加载
cute.copy(tiled_copy_A, tAgA[..., k_tile_index], tAsA[..., 1], pred=tApA)
cp_async_commit_group()
```

**为什么只填 num_stages-1=2 个而不是 3 个**：必须留一个空 slot 给 mainloop 第一次生产用，否则生产和消费无法并行。

### 3.7 Register Pipeline 预取

```python
num_k_block = cute.size(tCrA, mode=[2])  # BLK_K/MMA_K = 32/16 = 2
if num_k_block > 1:
    cp_async_wait_group(num_smem_stages - 2)  # 等 stage 0 就绪
    sync_threads()
    cute.copy(s2r, tCsA_p[..., 0], tCrA_copy_view[..., 0])  # 预取 k_block=0
```

- `wait_group(N)` = 等到未完成 group ≤ N
- `num_smem_stages - 2 = 1`：只等 1 个完成（stage 0），允许 stage 1 继续飞行

### 3.8 Mainloop

```python
for k_tile in range(k_tile_count):
    for k_block in range(num_k_block):   # register pipeline

        # 最后一个 k_block: 等下一个 smem stage 就绪
        if k_block == num_k_block - 1:
            cp_async_wait_group(num_smem_stages - 2)
            sync_threads()

        # ① Smem → Register: 预取下一个 k_block
        cute.copy(s2r_A, tCsA_p[..., k_block_next], tCrA_copy_view[..., k_block_next])
        cute.copy(s2r_B, tCsB_p[..., k_block_next], tCrB_copy_view[..., k_block_next])

        # ② Global → Smem: 异步预取下一个 k_tile（与计算重叠）
        if k_block == 0:
            cute.copy(tiled_copy_A, tAgA[..., k_tile_index], tAsA[..., smem_pipe_write])
            cute.copy(tiled_copy_B, tBgB[..., k_tile_index], tBsB[..., smem_pipe_write])
            cp_async_commit_group()

        # ③ MMA 计算
        cute.gemm(tiled_mma, tCrC, tCrA[..., k_block], tCrB[..., k_block], tCrC)
```

双重流水线：

```
cp.async (gmem→smem)   │  ldmatrix (smem→reg)  │  MMA (计算)
stage N+2 加载          │  k_block+1 预取        │  k_block 计算
─────────────── 三者并行，互相隐藏延迟 ───────────────
```

### 3.9 Epilogue

```python
# ① 类型转换 + epilogue 算子
tCrD = cute.make_fragment_like(tCrC, c_dtype)
tCrD[None] = epilogue_op(tCrC.load()).to(c_dtype)

# ② Register → Smem (MMA 布局)
cute.autovec_copy(tCrD, tCsC)
sync_threads()

# ③ Smem → Register (copy_C 布局，relayout)
cute.autovec_copy(tCsC_epilogue, tCrC_epilogue)

# ④ Register → Global Memory (带 predication)
for n in range(CPY_N):
    if N坐标 < mC.shape[1]:   # N 方向 if 分支
        cute.copy(tiled_copy_C, tCrC_epilogue[..., n], tCgC_epilogue[..., n], pred=tCpC[..., n])
```

**为什么经过 smem 中转**：MMA 累加器中各线程持有的数据在 M×N 中交错分布（不连续），直接写 gmem 无法 coalesce。通过 smem 做 relayout 后连续写入。

**`autovec_copy`**：不需要指定 copy atom，自动推导最大向量宽度。用于 register↔smem 的普通搬运（没有专用硬件指令的场景）。

---

## 4. Bank Conflict 与 Swizzle

### 4.1 问题

BF16 GEMM，K-major A 矩阵，`ldmatrix` 从 smem 读数据时：
- 每行 K_tile 个元素 = 若干 bank
- 相隔 4 行的线程会撞同一组 bank

| K_tile | 行间距(banks) | 冲突倍数 |
|--------|--------------|----------|
| 8 | 4 | 无冲突 |
| 16 | 8 | 2-way |
| 32 | 16 | 4-way |

### 4.2 解决

```python
swizzle = cute.make_swizzle(3, 3, 3)  # Swizzle<3,3,3>
# 对地址 bit[5:3] 和 bit[8:6] 做 XOR
# 让相邻行数据分散到不同 bank
```

---

## 5. Pipeline 设计要点

### 5.1 Smem Pipeline (3-stage)

```
Prologue: 填 2 个 stage（留 1 个空 slot）
Mainloop: 消费 read_ptr，生产 write_ptr，环形推进

wait_group(num_stages - 2) = wait_group(1)
含义: 至少 1 个 group 完成（当前要读的），允许其余继续飞行
```

### 5.2 Register Pipeline (2-deep)

```
num_k_block = BLK_K / MMA_K = 32 / 16 = 2
在计算 k_block=0 时预取 k_block=1 的数据
```

### 5.3 为什么 num_k_block>1 才提前预取

- `num_k_block=1`: mainloop 内自行 wait + ldmatrix + gemm
- `num_k_block>1`: mainloop 第一次 gemm(k_block=0) 假设数据已就绪，必须提前灌入

---

## 6. 整体数据流

```
Global Memory (A, B)
       │
  cp.async (异步，不占寄存器)
       ▼
Shared Memory (3 stages, 带 swizzle)
       │
  ldmatrix (匹配 MMA 寄存器布局)
       ▼
Register (2 k_blocks 双缓冲)
       │
  MMA (tensor core, m16n8k16)
       ▼
Accumulator Register (Float32)
       │
  epilogue_op + type cast
       ▼
Register (BF16)
       │
  autovec_copy (register → smem, relayout)
       ▼
Shared Memory (复用 AB 空间)
       │
  autovec_copy (smem → register, 新布局)
       ▼
Register (连续布局)
       │
  vectorized store (128-bit, 带 pred)
       ▼
Global Memory (C)
```

---

## 7. 关键 API 总结

| API | 作用 |
|-----|------|
| `cute.local_tile(tensor, tiler, coord, proj)` | 按 tiler 切分 + 取指定 tile |
| `cute.domain_offset(offset, tensor)` | 偏移 tensor 指针 |
| `cute.make_tiled_copy_tv(atom, thr_layout, val_layout)` | 组装搬运方案 |
| `cute.make_tiled_copy_A(atom, tiled_mma)` | 按 MMA 的 A 布局构建 smem→reg 搬运 |
| `tiled_copy.get_slice(tidx).partition_S/D(tensor)` | 按线程切分源/目标 |
| `thr_copy.retile(fragment)` | 寄存器视角转换（不分配新空间） |
| `cute.make_tiled_mma(op, atom_layout, permutation)` | 构建 tiled MMA |
| `tiled_mma.get_slice(tidx).partition_A/B/C(tensor)` | MMA 线程分工 |
| `tiled_mma.make_fragment_A/B/C(ref)` | 按 shape 分配寄存器 |
| `cute.gemm(tiled_mma, C, A, B, C)` | 执行 MMA 计算 |
| `cute.autovec_copy(src, dst)` | 自动向量化拷贝（无需指定 atom） |
| `cute.arch.cp_async_commit_group()` | 提交一组异步拷贝 |
| `cute.arch.cp_async_wait_group(N)` | 等到未完成 group ≤ N |

---

## 8. Predication 模式（通用）

```python
pred_tensor = cute.make_rmem_tensor(
    cute.make_layout(
        shape  = (CPY_outer, 主方向迭代数, 次方向迭代数),
        stride = (主方向迭代数, 1, 0),  # 次方向 stride=0 共享 pred
    ),
    cutlass.Boolean,
)
```

| | A 矩阵 | B 矩阵 | C 矩阵 |
|---|---|---|---|
| 主方向 pred | M | N | M |
| 次方向 stride=0 | K | K | N |
| 次方向处理 | if 分支 | if 分支 | if 分支 |
