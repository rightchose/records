# CuTe DSL 调试 + CuTe / PyCuTe / CuTe DSL 三者关系（学习笔记）

> 来源：
> - https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/debugging.html
> - 本地 PyCuTe 实现：`cutlass/python/pycute/`（layout.py / int_tuple.py / swizzle.py）
> 主题：① Debugging 页讲了啥、为什么；② CuTe(C++) / PyCuTe / CuTe DSL 三者怎么分工；③ PyCuTe 怎么当 CuTe DSL 的离线验算器。

---

## 〇、一句话总览

```
Debugging 页核心 = 因为「代码跑两遍」，bug 也分两层，工具必须对号入座：
   编译期世界（CPU，看 kernel 怎么"生成"出来）→ 日志/IR/PTX/CUBIN dump、print()
   运行时世界（GPU，看 kernel "跑"出啥）        → cute.printf、compute-sanitizer

PyCuTe = 第三层补充：layout 代数的「离线白盒验算器」，
         专调「我这个 composition/divide/tile 切分对不对」的逻辑 bug。
```

---

## 一、Debugging 页：核心是「两个世界，对号入座」

整页不是工具清单，而是一个**心智框架**：先判断 bug 在哪一层，再选对应世界的工具。

```
编译期世界（host/CPU，看 kernel 怎么被"生成"的）   ← 别的框架少见，产物是"生成"的
   日志 → IR → PTX → CUBIN → SASS
            │
            ▼
运行时世界（GPU，看 kernel "跑"出啥）              ← 和普通 CUDA 调试一样
   cute.printf → compute-sanitizer
```

### 1.1 Source Code Correlation —— PTX/SASS 对回 Python 行号
```bash
CUTE_DSL_LINEINFO=1
```
生成 line info（调试符号），让 profiler 能把 PTX/SASS 定位回源码行。也能用 JIT 编译选项按 kernel 开。
> 它的存在本身就是信号：正常语言不需要把机器码「对回」源码——因为它们之间没隔着四层生成。

### 1.2 DSL Debugging（编译期内部状态三件套）

**① 内置日志**（看执行流 / 内部状态）
```bash
CUTE_DSL_LOG_TO_CONSOLE=1          # 控制台
CUTE_DSL_LOG_TO_FILE=my_log.txt    # 文件
CUTE_DSL_LOG_LEVEL=20              # 0禁用/10Debug/20Info/30Warn/40Error/50Critical（默认10）
```

**② dump IR**（懂 MLIR 的人用）—— 验证 IR 是否按预期生成
```bash
CUTE_DSL_PRINT_IR=1     # 打印
CUTE_DSL_KEEP_IR=1      # 存文件
```

**③ dump PTX / CUBIN**（懂 PTX/SASS 的人用）
```bash
CUTE_DSL_KEEP_PTX=1
CUTE_DSL_KEEP_CUBIN=1
nvdisasm your_dsl_code.cubin > your_dsl_code.sass   # cubin → 可读 SASS
```

**④ 程序化拿 dump 内容**（编译产物属性）
```python
compiled = cute.compile(foo, ...)
compiled.__ptx__     # PTX 代码
compiled.__cubin__   # CUBIN 二进制
compiled.__mlir__    # IR 代码
```

**⑤ 改 dump 目录**：`CUTE_DSL_DUMP_DIR`（默认当前工作目录）

### 1.3 Kernel Functional Debugging（运行时/功能调试）

**① `print()` vs `cute.printf()`（全页最该记住的一条）**

| | 何时执行 | 看什么 | 影响 kernel? |
|---|---------|--------|-------------|
| `print()` | **编译期**（meta-stage，CPU） | 静态值：fully static layout、shape/stride | 不影响生成的 kernel |
| `cute.printf()` | **运行时（GPU 上）** | 真实 tensor 数值 | **改变生成的 PTX**，有开销（类似 CUDA C printf） |

> 这是"两个世界"在调试上的最直接体现：看「形状」用 `print`，看「数值」用 `cute.printf`，用错根本看不到想看的东西。

**② 处理挂死 kernel**（`CTRL+C` 杀不掉时）
```bash
# CTRL+Z 挂起，然后：
kill -9 $(jobs -p | tail -1)        # 杀最近挂起的进程
```

**③ compute-sanitizer**（查内存错误 + 竞态）
```bash
compute-sanitizer --some_options python your_dsl_code.py
```

**④ `set_name_prefix`**（给 kernel 起带信息的名字，方便 profiling 认出）
```python
@cute.jit
def launch_kernel():
    kernel.set_name_prefix("your_custom_name_prefix")   # → 名字变 "your_custom_name_prefix_xxx"
    kernel(...).launch(grid=..., block=...)
```

### 1.4 这页没讲的（避免误记）
- ❌ 没讲显式 **assertions**（在 JIT 编译选项页的 `enable-assertions`）
- ❌ 没专门讲 **type-safety 报错**（在 jit_arg_generation 页）
- line info 归在 Source Code Correlation；GPU 端调试靠 `cute.printf` + sanitizer + PTX/CUBIN/SASS dump

---

## 二、补充：编译产物链条（PTX / ptxas / CUBIN / SASS / nvdisasm）

调试时反复出现的几个名词，关系厘清：

```
你写的 Python (@cute.jit)
   │  Hybrid(AST+Tracing)
   ▼
  IR (MLIR/CuTe IR)        ← KEEP_IR / __mlir__
   │  后端 lower
   ▼
  PTX                      ← KEEP_PTX / __ptx__   （虚拟 ISA，跨架构，文本）
   │  ptxas 汇编
   ▼
  CUBIN（ELF 文件，内含 SASS）← KEEP_CUBIN / __cubin__   （绑定具体 SM 架构，二进制）
   │  nvdisasm 反汇编
   ▼
  SASS（可读机器码文本）       ← nvdisasm cubin > .sass
```

**关键纠错（容易说错）**：
- **SASS ≠ CUBIN**。SASS 是「指令集本身」（GPU 真执行的机器指令）；CUBIN 是「装着 SASS 的 ELF 文件」（含元数据）。应说「cubin **里包含** SASS」。
- **ptxas 产出 cubin，不是 .sass 文件**。ptxas 内部把 PTX 编成 SASS，但落地产物是 cubin（SASS 封在里面，直接打开是乱码）。
- **nvdisasm 才把 cubin 里的 SASS 反汇编成可读文本**。

| | PTX | CUBIN |
|---|-----|-------|
| 是什么 | 虚拟 ISA，中间汇编（文本） | 真实机器码容器（ELF 二进制） |
| 架构绑定 | 不绑定（跨代，运行时再 JIT） | 绑定具体 SM（sm_90 编的不能跑 sm_80） |
| 谁生成 | 编译器后端 | `ptxas` 把 PTX 汇编而来 |
| 类比 CPU | 还没绑平台的汇编/字节码 | 编好的 `.o`/可执行二进制 |

**为什么要看 CUBIN/SASS**：PTX 还是「虚拟」的，真正决定性能的**寄存器分配、指令调度、实际发了哪些 SASS** 只有在 CUBIN 这级才定死 → 极致调优（看寄存器用量、bank conflict、指令是否如预期）必须 dump cubin 再 nvdisasm。

---

## 三、CuTe / PyCuTe / CuTe DSL 三者关系

很多人会混，先分清这是**三个不同层**：

```
① CuTe (C++)        CUTLASS 3.x 的核心 C++ 模板库。Layout 代数 + Tensor 抽象，
                    编译期靠 C++ 模板特化。→ 真正在生产 kernel 里跑的那套。

② PyCuTe            cutlass/python/pycute/，纯 Python 重实现的 CuTe **布局代数**。
                    不 codegen、不碰 GPU，只把 Layout/composition/complement 那套
                    数学用 Python 跑一遍。→ 教学/原型/验证 layout 的"算盘"。

③ CuTe DSL          cutlass/python/CuTeDSL/，会 JIT 成 PTX/CUBIN 的 Python DSL。
                    Hybrid(AST+Tracing) → 真生成 GPU kernel。→ 本系列一直在学的。
```

| 维度 | CuTe (C++) | PyCuTe | CuTe DSL |
|------|-----------|--------|----------|
| 语言 | C++ 模板 | 纯 Python | Python（JIT） |
| 生成 GPU 代码? | ✅ 生产用 | ❌ 不生成 | ✅ JIT 成 PTX/CUBIN |
| 覆盖范围 | 全套（layout+kernel） | **只有 layout 代数** | 全套 |
| 能断点/单步? | ❌（编译期模板） | ✅ 普通 Python | ❌（meta-stage 在跑生成） |
| 定位 | 生产引擎 | 白盒练功房/参考实现 | Python 出活的生产工具 |

**一句话**：PyCuTe 是「**只算布局、不生成代码**」的参考实现；CuTe DSL 是「**真把 Python 编成 GPU kernel**」的生产工具。前者是后者 layout 部分的「可读教科书版」。三者共用同一套**内功 = Layout 代数**，只是三种「招式」。

### 3.1 PyCuTe 有多朴素 —— Layout 就是俩字段 + 几个方法

`cutlass/python/pycute/layout.py`：

```python
class Layout(LayoutBase):
  def __init__(self, _shape, _stride=None):
    self.shape  = _shape
    self.stride = prefix_product(self.shape) if _stride is None else _stride
    # ↑ 默认 stride = shape 前缀积 = column-major（列优先）

  def __call__(self, *args):           # coord → index
    return crd2idx(args, self.shape, self.stride)   # 就是 坐标·stride 点积

  def size(self):   return product(self.shape)        # 定义域大小
  def cosize(self): return self(self.size()-1) + 1    # 值域大小
  def __str__(self): return f"{self.shape}:{self.stride}"   # 打印 "(4,8):(1,4)"
```

笔记 06 的 `index = coord · stride` 在这就是 `crd2idx` 的字面实现。

### 3.2 笔记里那些"高大上"的代数运算，在 PyCuTe 里全是几十行 Python

| 笔记里的代数运算 | layout.py 函数 | 行号 |
|----------------|---------------|------|
| Coalescence（合并相邻 mode） | `coalesce` | :137 |
| Composition（复合） | `composition` | :190 |
| Complement（补空间） | `complement` | :232 |
| Inversion（求逆） | `right_inverse`/`left_inverse` | :260/:287 |
| tile 切分 | `logical_divide`/`tiled_divide` | :297/:348 |

`coalesce` 的核心规则就一个 `if`（layout.py:154）：
```python
# 相邻两维若 前一维 shape*stride == 后一维 stride → 内存连续 → 合并成一维
elif result_shape[-1] * result_stride[-1] == stride:
    result_shape[-1] = result_shape[-1] * shape
```
同样的逻辑在 C++ CuTe 里是模板递归（看不见、打不了断点），在这是一个 `if`。

### 3.3 能直接跑的例子

```python
from pycute import Layout, coalesce, complement, composition, logical_divide

L = Layout((4, 8), (8, 1))    # row-major 4×8
print(L)            # (4, 8):(8, 1)
print(L(2, 3))      # 2*8 + 3*1 = 19   ← 笔记06 的例子
print(L.size(), L.cosize())   # 32 32

print(Layout((4, 8)))                      # (4, 8):(1, 4)   默认 column-major
print(coalesce(Layout((2, 4), (1, 2))))    # (8):(1)         连续 → 合一维
print(complement(Layout(4, 2), 24))        # (2, 3):(1, 8)
print(logical_divide(Layout(16, 1), Layout(4, 1)))  # 把 16 切成 4×4 tile
```

---

## 四、PyCuTe 当 CuTe DSL 的 debug 工具（能，但有圈）

**能调的：layout 代数算错了（逻辑 bug）**

```
CuTe DSL 里写了一串 composition/logical_divide/coalesce 切 tile
   → 结果不对，不确定是「切分逻辑错」还是「kernel 算术错」
        │
        └─ 把同样的 (Shape,Stride) 抄进 PyCuTe 纯 Python 跑一遍
           print 每步 layout → 一眼看出 tile 切成了什么形状
```

PyCuTe 在这里补上了 CuTe DSL 调试的盲区：

| | CuTe DSL 里 | PyCuTe 里 |
|---|------------|-----------|
| layout 是什么 | proxy/IR value，`print` 出 `(?,?):(?,1)`，**看不到具体值** | 纯 Python 对象，`print` 出完整 `(4,8):(8,1)` |
| 能断点单步? | ❌（断在 IR builder 里） | ✅ 随便断点/单步/改了重试 |
| 能 REPL 交互试? | ❌（要整个编译） | ✅ 直接 `logical_divide(...)` |

**不能调的（边界）**：
```
❌ GPU 数值错       → cute.printf（运行时世界，PyCuTe 碰不到 GPU）
❌ 内存越界/race    → compute-sanitizer
❌ kernel 生成对不对 → dump IR/PTX
❌ 性能/bank conflict→ 看 SASS
❌ 动态值参与的约束  → PyCuTe 是"全静态算盘"，只能代入具体数；?{div=4} 这类动态约束不处理
```

> ⚠️ PyCuTe 验的是「代数规则对不对」，不是「动态约束传播对不对」。CuTe DSL 里大量 layout 是 dynamic 的，用 PyCuTe 验得**先假设一组具体 shape 代进去**算。

**定位（在调试体系里的位置）**：
```
debug 入口从右往左：
  cute.printf 看数值 ──错──▶ 怀疑 layout 切错?
                                │
                       ┌────────┴────────┐
                       ▼                 ▼
                dump IR 看生成       PyCuTe 离线验算 ← 这一格
                (黑盒，看产物)       (白盒，重演代数)
```

PyCuTe 不是官方 debugging 页列的工具（那页没提它），而是**民间最佳实践**：唯一能给 CuTe layout 代数**打断点、单步、交互试**的工具。和官方工具互补——一个查「数学对不对」（静态/离线），一群查「机器跑得对不对」（动态/在线）。

---

## 五、一句话总结

> **Debugging 页的核心是「代码跑两遍 → bug 分两层 → 工具对号入座」**：编译期看生成链（日志/IR/PTX/CUBIN/SASS dump、`print`），运行时看执行（`cute.printf`/compute-sanitizer）；那一堆 `CUTE_DSL_*` 环境变量本质都是「把生成链各级产物摊开核对」的开关。**三者关系上**，CuTe(C++) 是生产引擎、CuTe DSL 是 Python 出活工具、**PyCuTe 是只算布局不生成代码的白盒参考实现**——三者共用同一套 Layout 代数内功。正因为 PyCuTe 纯 Python、能断点、能 print 出确定的 `(Shape,Stride)`，它顺带成了 **CuTe DSL 的「layout 代数离线验算器」**，专治「我这个 composition/divide/tile 对不对」的逻辑 bug；一旦涉及 GPU 执行/数值/动态约束/性能，就回到 `cute.printf`/sanitizer/IR-PTX dump 那套在线工具。
