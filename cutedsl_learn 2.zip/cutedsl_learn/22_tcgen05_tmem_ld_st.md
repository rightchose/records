# 22. tcgen05 TMEM 读写 —— ld / st / pack / wait 全解

> 锚点：承接 note 21(tcgen05 同步范式 fence/pipeline)、note 15(blackwell_hardware TMEM/warp 专精)。
> 主题：`tcgen05.ld` / `tcgen05.st` 如何在 **TMEM ↔ 寄存器** 间搬数据 —— lane 分区、shape/num、
> pack::16b、16x32bx2 split、red 归约、`.sync`/`.aligned` 辨析。来源：PTX ISA 9.7.17.8。
> 一句话：**ld/st 是 TMEM↔RF 的 warp 级集体桥；TMEM 是 128 lane × N column，lane 按 warp 硬分区。**

---

## 0. 一句话结论

| 指令 | 方向 | 用途 |
|--|--|--|
| **`tcgen05.ld`** | TMEM → 寄存器 | 读 MMA 累加结果，交线程做 softmax/epilogue/写回 |
| **`tcgen05.st`** | 寄存器 → TMEM | 初始化累加器 / 中间结果放回 TMEM 给下一次 MMA |

- 都是 **warp 级集体**(`.sync.aligned`)、**异步**(需 `wait::ld`/`wait::st` 或 fence 同步)。
- TMEM 只有 async proxy(tcgen05 系)能碰，普通 `ld.shared` 读不了。

---

## 1. TMEM 物理布局 + lane 访问约束(9.7.17.8.1)

TMEM 是二维结构：

```
        column 0  1  2  ...  (N 方向, 自由维/K或N —— 全 warpgroup 共享)
lane 0   ┌──────────────────────┐
lane 1   │                      │
 ...     │       TMEM            │
lane 127 └──────────────────────┘
  ↑ 128 条 lane (M 方向, 累加器的行 —— 按 warp 硬分区)
```

**访问约束(核心)：**

| 维度 | 谁能访问 | 性质 |
|--|--|--|
| **column(列/N)** | 一个 warpgroup 全部 4 warp 都能访问所有列 | **共享** |
| **lane(行/M)** | 一条 lane 只能被 warpgroup 里某一个 warp 访问 | **硬分区** |

分区表：
```
warp 0 → lane 0-31    warp 1 → lane 32-63
warp 2 → lane 64-95   warp 3 → lane 96-127
```

**为什么这么分**：一个 warp=32 线程↔32 lane；一个 warpgroup=4 warp=128 线程↔铺满 128 lane。
→ **读完整 128-lane 累加器必须凑齐一整个 warpgroup**，每 warp 管自己那 32 lane 切片。
→ 这正是 note 15 warp 专精(softmax/mma/correction warp 各管 M 切片)能成立的物理根基。

---

## 2. ld 完整语法(9.7.17.8, 三个家族)

```
// 普通 load
tcgen05.ld.sync.aligned.shape1.num{.pack}.b32           r, [taddr];
tcgen05.ld.sync.aligned.shape2.num{.pack}.b32           r, [taddr], immHalfSplitoff;
// 浮点 load + 归约
tcgen05.ld.red.sync.aligned.shape3.num.redOp{.abs}{.NaN}.f32  r, redval, [taddr];
// 整数 load + 归约
tcgen05.ld.red.sync.aligned.shape3.num.redOp.type            r, redval, [taddr];

.shape1 = {.16x64b, .16x128b, .16x256b, .32x32b}
.shape2 = {.16x32bx2}          // 两次分离访问, 见 §4
.num    = {.x1,.x2,.x4,.x8,.x16,.x32,.x64,.x128}
.pack   = {.pack::16b}
.shape3/4 = {.32x32b} / {.16x32bx2}
.redOp  = {.min, .max}         .type = {.u32, .s32}
```

- **`.shape` × `.num` = 总数据量**：shape=基础访问块，num=重复因子。
- **`taddr` 是集体基址**：warp 内所有线程必须填**同一个** taddr(否则未定义)；shape 决定 32 线程怎么摊到 lane/column。
- **`r` = 花括号 32-bit 寄存器向量**，大小见 Table 52(下面有公式)。

---

## 3. 寄存器数量公式(推导 + CUTLASS 坐实)

> **每线程寄存器数 = (lane 数 × 位宽) ÷ 32 线程 ÷ 32 bit × num**

shape 读法 = `<lane 数>x<每 lane 位宽>`：`16x256b`=16 lane×256 bit；`32x32b`=32 lane×32 bit。

| shape.num | 计算 | 寄存器 | CUTLASS 实证(copy_sm100.hpp) |
|--|--|--|--|
| `32x32b.x1` | 32×32/32/32=1 | 1 | `SM100_TMEM_LOAD_32dp32b1x`: `uint32_t[1]` |
| `16x64b.x1` | 16×64/32/32=1 | 1 | ✓ |
| `16x128b.x1` | 16×128/32/32=2 | 2 | ✓ |
| `16x256b.x1` | 16×256/32/32=4 | 4 | `SM100_TMEM_LOAD_16dp256b1x`: `uint32_t[4]` |
| `16x256b.x32` | 4×32=128 | 128 | `SM100_TMEM_LOAD_16dp256b32x`(巨型 struct) |

**关键**：shape 名里的 "256b" ≠ 寄存器位数 —— 它是 16 条 lane 横向总位宽，要 ÷32 线程摊到每线程。
CUTLASS 命名 `dp`(data path) = PTX 的 lane。

---

## 3.5 如何挑对变体 —— lane 被 MMA 钉死，你只在挑 column 读法

> 原文：*With the large number of options, the natural question is how to pick the correct variant.
> The number of lanes is most affected by the MMA instruction used; different `tcgen05.mma`
> variants result in different output layouts, and different `tcgen05.ld` shapes are suited for
> different situations.*

§2 摆出 shape×num×pack 一大堆组合，自然会问：**到底该挑哪个？** 答案分两层，关键是先认清
**这些变体不是平行的自由选项 —— lane 维度是被上游 MMA 反向约束死的**。

### 逻辑链(一句话)

```
tcgen05.mma 变体  →  决定累加器在 TMEM 的 output layout  →  钉死 ld 的 lane 部分
                                                           ↓
                                        剩下的自由度只在 column 方向(读多宽 / 要不要 split / 要不要 pack)
```

### 为什么 lane 由 MMA 决定(不是你自由挑)

累加器不是随便摆进 TMEM 的，是 **tensor core 按 MMA 指令形状写进去的**(见 §1 lane 按 warp 硬分区)：

- 不同 `tcgen05.mma` 变体(M=128 vs M=256 的 2CTA、不同 N、不同 dtype)把结果元素铺到
  **不同的 lane×column 位置** —— 这就是 "output layout"。
- 等于 MMA 已经规定好"哪个 warp/线程负责累加器里哪几行(M 方向)"。
- 所以读回来时 **lane 划分必须跟 MMA 的 output layout 对上**：`16x…`(一 warp 覆盖 16 lane 的半区结构)
  还是 `32x…`(一 warp 铺满 32 lane)，是被 MMA 反推出来的，不是你选的。
  → 对不上 = 线程读到的不是自己该负责的那部分数据。

### "different ld shapes are suited for different situations" = 剩下的自由度

lane 被钉死后，你真正在权衡的只有 **column 方向**：

| 自由度 | 变体 | 适用 situation / 权衡 |
|--|--|--|
| **一次读多宽** | `32b`/`64b`/`128b`/`256b` | 越宽 → 每线程拿更多寄存器、指令更少；但要求列方向连续 + 扛得住寄存器压力 |
| **是否 split** | `16x32bx2`(+immHalfSplitoff) | 累加器被劈成两块分离列区时用(§4) |
| **是否 pack** | `pack::16b` | 仅 fp16 累加器(§5)，省寄存器/搬运减半 |

即"situation"= 累加器的 **dtype、在 TMEM 里连不连续、寄存器预算、要不要顺带转类型**。

### 一句话总结怎么挑

1. **先看 MMA**：它定死累加器在 128 lane 上的分布 → 定死 ld 的 **lane 部分**(`16x…` vs `32x…`)。
2. **再按场景调 column**：一次读多宽 / 要不要 split / 要不要 pack，在寄存器压力与访问连续性间权衡。

**潜台词**：别把这几十个变体当平行自由选项 —— lane 维度是 MMA 反推的硬约束，你真正在挑的只是 column 读法。
→ 参见 note 19 §MMA 变体决定 output layout。

---

## 4. `.16x32bx2` + immHalfSplitoff —— 两次分离访问

shape2/shape4 独有。原文：*对 TMEM 做两次 `.16x32b` 访问；第一次基址=taddr，第二次=taddr+immHalfSplitoff。*

```
taddr ───────────────► 第 1 次 16x32b 访问  ┐
taddr + immHalfSplitoff ► 第 2 次访问        ┘  一条指令、两个可隔很远的区域
```

- **和 `.num` 重复不同**：num 是**连续**重复；`16x32bx2` 是**两个分离区域**(差一个立即数偏移)。
- 用途：TMEM 里数据被劈成两半、分处不同列区时，一条指令取回两半。
- **这解答了 Figure 193 的"两个 16-bit 为何分开"**：它们是两次 split 访问取到的相邻列元素。

---

## 5. pack::16b —— 16-bit 数据专用打包

原文：*把**相邻两列(adjacent columns)** 的两个 16-bit 元素，在 load 时打包成一个 32-bit 元素。*

```
TMEM(D 不打包存, 见下 §5.0):        ── ld.pack::16b ──►  RF: [32-bit: col1|col0]
  col0 word: [浪费高16 | 16b_A]                          一个寄存器装两个 16-bit
  col1 word: [浪费高16 | 16b_B]  ← 相邻两列,各占一个 word
```

**为什么要 pack**：寄存器文件按 32-bit 工作。16-bit 数据若不 pack → 每个 16-bit 独占一个 32-bit
寄存器(高 16 位浪费、寄存器翻倍、指令翻倍)。pack → 满载、搬运减半、可做 half2 SIMD。
pack **不改变 TMEM 存储**(TMEM 里始终不打包)，只在 **TMEM→RF 搬运途中把浪费压实**。

### 5.0 官方依据：matrix D 在 TMEM 里"不打包"(9.7.17.10.4.1)

原文：*matrix D 的 sub-word 元素**不会**打包进一个 32-bit Tensor Memory word。例如元素是 16-bit 时，
一个 TMEM word 只在**低 16 位**装一个 16-bit 元素(高 16 位浪费)。*

```
D 是 16-bit 时, 一个 TMEM word(32-bit):
  ┌────────────────┬────────────────┐
  │  高16位: 浪费   │ 低16位: 1个元素  │
  └────────────────┴────────────────┘
       31                          0
```

**为什么 D 要不打包存**：D 是累加器，tensor core 要按 word 粒度**反复原地读改写**(`D += A×B`)。
两个 16-bit 挤一个 word → 更新其一要读-改-写整个 word 还得护住另一半 → 累加通路复杂化。
让每元素独占一 word，累加读改写最规整 —— **用空间浪费换累加通路简单**。
→ 这就是上面图里"相邻两列两个 16-bit 在 TMEM 上分开"的**官方根据**：它们本就各占一个 word。
→ 也印证触发条件 `acc.width==16`：只有 16-bit 累加器在 TMEM 才有"浪费的高16 + 可合并相邻列"结构。
fp32(32-bit) D 填满 word、无浪费、无可合并相邻 16-bit → 永远不 pack。

**⚠️ 不是"开销"，是"16-bit 数据的功能开关"**：数据 fp32 就用不上(走 `.b32`, 常态)；数据 16-bit 才该用。
`st.unpack::16b` 是逆操作(reg 32b → TMEM 两个 16b)。**reduce 家族无 pack(与归约互斥)**。

### 触发条件(硬代码坐实, blackwell_helpers.py:318-327)

CUTLASS 选中 `Pack.PACK_16b_IN_32b` 的**唯一**分支：
```python
elem_ty_acc.width == 16 and elem_ty_d.width == 16   # 累加器本身就是 16-bit(fp16 累加)读出
```
对比另两个分支(均 `Pack.NONE`)：
| 累加器 | 读出 dtype | pack? |
|--|--|--|
| fp16(16) | 16 | ✅ pack |
| fp32(32) | 16 | ❌ NONE(窄化 store, 非 pack) |
| fp32(32) | 32 | ❌ NONE(普通 `.b32`) |

**根本条件 = TMEM 里数据以 16-bit 存**(fp16 累加器)，此时"相邻两列两个 16-bit"才真实存在。
fp32 累加器 TMEM 存的是 32-bit 单元，没有可合并的相邻 16-bit → 永远 NONE。

### FA4 反例(坐实, flash_fwd_sm100.py:2313-2332) —— 别混淆两种"16-bit 打包"

FA4 forward 的 P 矩阵(softmax 后的 bf16)回写 TMEM **不用硬件 unpack**，用**软件 recast**：
```python
tSrP_r2t_f32 = cute.make_fragment(..., Float32)           # 寄存器声明为 fp32
tSrP_r2t = cute.make_tensor(
    cute.recast_ptr(tSrP_r2t_f32.iterator, dtype=q_dtype), # 同批寄存器 recast 成 bf16 视图
    tSrS_t2r.layout)
softmax.apply_exp2_convert(tSrS_t2r, tSrP_r2t, ...)       # 两个 bf16 挤进每个 32-bit
cute.copy(thr_tmem_store, tSrP_r2t_f32[...], tStP_r2t[...])# St32x32b(fp32) 存, 无 .unpack
```
store atom = `St32x32bOp, Float32`(1924 行)，**无 `.unpack::16b`**。全 FA4 仓 `PACK_16b_IN_32b`零实例化。

| | fp16 累加器读出 | FA4 P 回写 |
|--|--|--|
| dtype | acc=16, d=16 | acc=32(fp32), d=16(bf16) |
| 手段 | 硬件 `ld.pack::16b` | 软件 recast + `St32x32b` |
| 用硬件 pack? | ✅ | ❌ |

FA4 选软件方案：exp2 转换本就在寄存器发生且结果天然 bf16，recast 成 fp32 视图走通用 St32x32b 更省事、与 fp8 等路径统一。

---

## 6. `.red` 归约变体 —— load 时顺带归约

`tcgen05.ld.red` = 一条指令 load + reduce：

| qualifier | 取值 | 含义 |
|--|--|--|
| `.redOp` | `.min`/`.max` | 只有极值, 无 sum |
| `.abs`(可选) | — | 参与归约的是**绝对值** → `.max.abs`=amax |
| `.NaN`(可选) | — | 任一输入为 NaN → 结果为 canonical NaN(NaN 优先传播) |
| 类型 | `.f32` / `.u32`,`.s32` | 浮点/整数 |
| 额外操作数 | `redval` | 参与归约的初值/累积值 |

- 形状受限：只支持 `.32x32b`(shape3) 和 `.16x32bx2`(shape4)，不支持 16x64/128/256b。
- **不加 `.NaN`**：min/max 通常"忽略 NaN"(返回非 NaN 那个)；**加 `.NaN`**：反过来 NaN 优先。
- `.max.abs` 组合像**求最大绝对值(amax)** → 偏**量化 scale/归一化**用途。
  **注意**：FA4 softmax row-max 是普通 ld 读回后在寄存器算，**不走这条 red 路径**，别想当然。

---

## 7. `.sync` vs `.aligned` —— 两件不同的事

两者在 `tcgen05.ld/st/wait` 里都 mandatory，但语义正交：

| | `.sync` | `.aligned` |
|--|--|--|
| 管什么 | **运行时**：会合等待 | **代码/编译期**：全员到齐约束(收敛性) |
| 语义 | 等到 warp 所有线程都执行该指令**才继续** | warp 所有线程**必须都执行同一条**该指令 |
| 类比 | 集合点:先到的等后到的 | 队列纪律:不许掉队/走岔路(发散) |
| 违反 | (本身即等待动作) | **未定义行为**(死锁/错乱) |

**组合作用**：`.aligned` 保证"人都会来"(前提)，`.sync` 保证"来了等齐再走"(动作)。缺 aligned→有人没来→死锁。

**"有 sync 必有 aligned" 是错的**：`shfl.sync`/`vote.sync`/`bar.sync` **只有 sync 无 aligned** ——
它们带 `membermask` 显式指定参与线程、**允许 warp 发散**，与 aligned(禁发散)互斥。
`tcgen05.ld/st/wait` 两个都要，只因它们是**无 membermask、写死整 warp** 的 collective(既要全员到齐又要会合等待)。

---

## 8. 与 note 21 同步机制的衔接

ld/st 异步 → 完成时序靠 note 21 那套：
- **non-pipelined 生产者**(21 §7 例B)：`tcgen05.ld` 后必须 `tcgen05.wait::ld` 显式等完成再发跨线程信号
- **register dependency**(21 §10, 6.4.5)：直接消费 ld 目标寄存器值的下游靠 RAW 免同步；但碰同一 TMEM 地址/跨线程仍需 `tcgen05.wait::ld`
- **st 完成**：FA4 用 `cute.arch.fence_view_async_tmem_store()`(flash_fwd_sm100.py:2337,2340) 确保 st 对后续 mma 可见
- **proxy 可见性**(21 §11)：TMEM 只 async proxy 能碰，不涉跨 proxy；跨 proxy 冲突只在 SMEM

---

## 9. 速查

| 我想 | 用 |
|--|--|
| 读 fp32 累加器 | `tcgen05.ld...32x32b`/`16x256b`...`.b32` (无 pack) |
| 读 fp16 累加器省寄存器 | `...pack::16b` (CUTLASS 自动选) |
| 写 fp32 累加器/中间结果回 TMEM | `tcgen05.st...b32` (St32x32b) |
| 写 bf16 中间结果(如 FA4 的 P) | 软件 recast + `St32x32b` (非硬件 unpack) |
| 一次读两个分离 TMEM 区域 | `...16x32bx2..., [taddr], immHalfSplitoff` |
| load 时求 min/max/amax | `tcgen05.ld.red...{.abs}{.NaN}` |
| 等 ld 完成(跨线程/防覆盖) | `tcgen05.wait::ld` |
| 读满 128-lane 累加器 | 凑齐整个 warpgroup(4 warp, 每 warp 32 lane) |
