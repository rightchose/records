# 18. Blackwell 低精度格式 + block-scaled MMA + tcgen05 PTX 实战

> 锚点：CUTLASS DSL `cutlass/python/CuTeDSL/cutlass/cute/nvgpu/tcgen05/mma.py`
> 与 `warpgroup/mma.py`；FA4 `flash_attn/cute/mma_sm100_desc.py`。
> 主题：tcgen05.mma 支持的 GEMM、与 Hopper wgmma 的区别、FP8/FP6/FP4 各格式、
> MX vs NV 缩放、MXFP8 block-scale GEMM 的计算逻辑与 PTX 指令流。

---

## 1. tcgen05.mma 支持哪些 GEMM（vs Hopper wgmma）

### 普通族 `tcgen05.mma.cta_group.kind`（累加器无 scale）
| Op 类 | A/B dtype | 累加器 | 指令 K |
|------|------|------|------|
| `MmaTF32Op` | TF32 | F32 | 8 |
| `MmaF16BF16Op` | F16/BF16 | F16 或 F32 | 16 |
| `MmaI8Op` | S8/U8 | S32 | 32 |
| `MmaFP8Op` | E4M3/E5M2 | F16 或 F32 | 32 |
| `MmaF8F6F4Op` | {E5M2,E4M3,E3M2,E2M3,E2M1} 混合 | F16/F32 | 32 |

### Block-scaled 族 `…​.kind.block_scale`（`BlockScaledMmaOp`，仅 sm_100a/sm_103a）
带 `sf_dtype` + `sf_vec_size` 两个一等操作数。
| Op 类 | PTX kind | sf_dtype | block | K | 名 |
|------|------|------|------|------|------|
| `MmaMXF8F6F4Op` | mxf8f6f4 | E8M0(写死) | 32 | 32 | MXFP8/6/4 |
| `MmaMXF4Op` | mxf4 | E8M0(写死) | 32 | 64 | MXFP4 |
| `MmaMXF4NVF4Op` | mxf4nvf4 | E8M0 **或 E4M3** | 16 | 64 | NVFP4 |
| `SM103MmaMXF4*` | (B300 专用) | 同上 | 同上 | 96 | B300 加速 |

形状约束（`mma.py:248-278`）：cta_group=ONE → M∈{64,128}；TWO → M∈{128,256}。累加器统一在 **TMEM**。

### tcgen05 vs wgmma 核心区别
| 维度 | Hopper **wgmma** | Blackwell **tcgen05.mma** |
|------|------|------|
| 发起单位 | warpgroup(128 线程)协同 | **单线程**发起，整 CTA/cluster 异步 |
| 累加器 | **RMEM**(寄存器) | **TMEM**(专用 Tensor Memory) |
| M 维 | 固定 64 | 1CTA:{64,128}；2CTA:{128,256} |
| 2CTA | 无 | **独有**(M 翻倍、跨 CTA TMEM、仅 leader 发) |
| A 来源 | RMEM 或 SMEM | **TMEM** 或 SMEM(为链式 GEMM) |
| dtype | F16/BF16/F8/I8/TF32 | + FP6/FP4 + MX/NV 微缩放 |
| block scale | 无 | 原生(SFA/SFB) |
| 可运行时改字段 | 仅 `accum_c` | NEGATE_A/B、ACCUMULATE、SFA、SFB |
| 描述符 | 64-bit smem desc | 32-bit instr desc + smem desc，累加走 TMEM |

> 三大本质差异：累加器 RMEM→TMEM；A 可来自 TMEM(链式 GEMM 省 smem 往返)；2CTA。

---

## 2. 为什么 FP8/FP6/FP4 同属 `MmaF8F6F4Op`

`_F8F6F4_TYPES`(`mma.py:53-59`)= 一条 PTX 指令 `kind::f8f6f4` 合法的 5 种类型，
共用 **8-bit 容器 + 同一条 datapath**：

- 无论 FP8/FP6/FP4，在 SMEM/TMEM 里都 **padding 到 1 字节**(FP6 补 2bit、FP4 补 4bit)。
- A、B 类型可不同 → mixed-input UMMA，运行时由 idesc 选类型 → 一个类覆盖 5 dtype。
- SASS 层：FP8/FP6 都编译成 **QMMA**；FP4 在此 kind 下也回退 QMMA。

### 算力换算（`instruction_k` 直接 = 吞吐倍率）
| Op | kind | K | 相对 FP8 |
|------|------|------|------|
| FP8/`f8f6f4` | f8f6f4 | **32** | **1×** |
| FP4/`mxf4`,`nvf4` | OMMA 通路 | **64** | **2×** |
| FP4/SM103 | (B300) | **96** | **3×** |

- **关键反直觉**：在 `f8f6f4` 里 **FP8=FP6=FP4 吞吐全等**(都 1× FP8 速率)，
  FP6/FP4 在此只省存储/带宽，不省算力。
- 想要 FP4 的 2×/3×，必须切到专用 `mxf4`/`nvf4`(packed `.b4x16`，走 **OMMA**)。
- **K=64 vs 96 纯粹是芯片代次**：SM100/B200=64，SM103/B300(Blackwell Ultra)=96，
  96/64=1.5 正是 B300 对 B200 的 FP4 吞吐提升(datapath 加宽)。
- 越窄的精度原生 K 越大(同阵列每 cycle 塞更多元素)；FP6/FP4 走 padded f8f6f4 则退回 K=32。

### QMMA / OMMA（SASS 层 Tensor Core 指令）
- HMMA(16-bit) / IMMA(int) / **QMMA**(8-bit 容器，FP8 及 padded FP6/FP4，1×) /
  **OMMA**(packed 窄位宽 FP4 专用通路，2×)。
- 走哪条由 PTX `kind` 决定，不由 dtype 决定 → 这就是 `f8f6f4` 塞 FP4 不提速的原因。

---

## 3. 低精度格式全景

### FP8（8-bit 浮点；ExMy = 1 符号 + x 指数 + y 尾数）
| 格式 | 位 | bias | 最大正规 | Inf | 用途 |
|------|------|------|------|------|------|
| **E4M3(FN)** | s/4/3 | 7 | ±448 | 无(仅 NaN) | 前向/权重/激活(偏精度) |
| **E5M2** | s/5/2 | 15 | ±57344 | 有(IEEE 风) | 反向/梯度(偏范围) |
- 后缀：**FN**=finite(无 Inf，省编码扩范围)；**UZ**=单零；**B11**=指数 bias 11；
  `E4M3B11FNUZ` 是异构厂商方言。NV Blackwell 实吃 OCP 的 **E4M3FN / E5M2**。
- TE FP8 训练标配：fprop=E4M3，dgrad/wgrad=E5M2。

### FP6 为何有用（FP8=FP6 同算力下）
算力相同 ≠ 端到端相同。FP6 价值在**非算力**维度：
1. 容量：6bit 比 FP8 省 25%(权重/KV cache 显存)，HBM 可 packed 存。
2. 带宽：decode/memory-bound 阶段是带宽瓶颈，6bit 少搬 25% 字节 → 更快。
3. 精度：比 FP4 多 2bit，是 FP8/FP4 之间的精度甜点。
> NV 让 FP6 与 FP8 共物理电路(同吞吐)；AMD CDNA4 让 FP6 与 FP4 共电路(2× FP8)。
> compute-bound 极限吞吐场景 FP6 无意义，该直接上 packed FP4(OMMA)。

### FP4：元素只有一种，差别在缩放
- 元素格式只有 **E2M1**(s/2/1，16 个值：0,±0.5,±1,±1.5,±2,±3,±4,±6)，精度极差，离不开 block scale。
- **MXFP4**(`mxf4`)：E8M0 scale(只能 ×2ⁿ)/ 块 32 / OCP 标准 / 4.25 bit/元素。
- **NVFP4**(`mxf4nvf4`)：E4M3 scale(可非 2 幂精细缩放)/ 块 16 / **两级缩放**
  (per-16 E4M3 微 scale + per-tensor FP32 全局 scale)/ NVIDIA 专有 / 4.5 bit/元素 / **更准**。
- 两者数据都 E2M1，吞吐都走 OMMA(2×/3×)完全一致；选谁只看精度/存储/标准。

### E8M0（`Float8E8M0FNU`）—— 不是数据，是 scale
- 8 指数 + 0 尾数 + 无符号，只表示 2 的幂。是 MX 微缩放的共享 scale。
- MXFP8/6/4：per-32 E8M0；NVFP4：per-16 E4M3。

### 关键不对称：有 MXFP8，没有 "NVFP8"
- block-scaled FP8(`MmaMXF8F6F4Op`)的 `sf_dtype` **写死 E8M0、块 32**(`mma.py:1323-1324`)；
  只有 FP4 的 nvf4 才允许 E4M3 精细 scale。
- 原因：FP8 元素精度已够好，per-tensor scaling 或 MXFP8 足矣；FP4 精度太差才需 NVFP4 抢救。
- FP8 的"格式之分"实际是 **per-tensor scaling(TE) vs MXFP8**，而非 MX/NV 之分。

---

## 4. FP8 算术的硬件真相
- **SIMT/CUDA core 层无任何 FP8 原生算术**：FP8/6/4 只是存储+转换类型，
  只有 `cvt`(如 `cvt.rn.f16.e4m3`)。逐元素 FP8×FP8 必须升 FP16/FP32 再乘。
- 唯一"算" FP8 的是 **Tensor Core MMA**，且**累加器强制 F16/F32**，从不产出 FP8 乘积。
- block-scale 时乘 scale = 指数加(E8M0 是 2 的幂)，不引入 FP8 乘法器。

---

## 5. MXFP8 block-scaled GEMM 的计算逻辑

### 数学（K 维按 32 切块，scale 提到块外）
scale 在 32-block 内是常数，可提到求和外：
```
D[m,n] = Σ_blocks 2^(SFA[m,b]+SFB[b,n]) · ( Σ_{k∈block b} A[m,k]·B[k,n] )
                  └─ 常数(指数加) ─┘       └─ 裸 FP8 点积(QMMA) ─┘
```
### 硬件每条 MMA(K=32 = 一个 block)三步
1. 裸 FP8 点积 `Σ a·b`(QMMA，与无 scale FP8 GEMM 完全一样)；
2. ×`2^(SFA+SFB)` → E8M0 纯指数，对 partial sum 做**一次指数加**(几乎零成本)；
3. `+=` 进 TMEM 的 **FP32** 累加器。

### 三个"刚好"让 scale 白送
- block=32 = 指令 K=32(scale 粒度锁到指令 K)；
- E8M0 是 2 的幂(dequant = 移位)；
- scale 提到块外(32 次裸乘喂 QMMA，scale 只在块和上施加一次)。
→ MXFP8 算力 ≈ 普通 FP8(都 K=32，1×)。

### 数据放哪
| 数据 | 位置 |
|------|------|
| A/B FP8 | SMEM(A 可 TMEM)，64-bit smem desc 寻址 |
| **SFA/SFB(E8M0)** | **TMEM**；A→`M×(K/32)`，B→`(K/32)×N` |
| 累加器 D | TMEM，FP32 |

### scale 规模示例：A = 1024×512
- block 沿 K，每 32 元素 1 scale → 每行 512/32=16 个 → **SFA = 1024×16 = 16384 个 E8M0**。
- 存储：A 数据 512KB，scale 16KB(每元素 +0.25bit，等效 8.25bit，占 3.125%)。
- 物理 TMEM layout 需 swizzle/padding(M→128 倍数、K/32→对齐)，此例尺寸整，逻辑≈物理。

---

## 6. tcgen05 PTX 指令流（一个 MXFP8 tile 的生命周期）

### 指令家族
| PTX | 作用 |
|------|------|
| `tcgen05.alloc`/`dealloc` | 分配/释放 TMEM(累加器+scale) |
| `tcgen05.cp` | SMEM→TMEM(搬 scale / A) |
| `tcgen05.mma … .block_scale` | 核心异步 MMA |
| `tcgen05.commit` | 完成时 arrive mbarrier |
| `tcgen05.ld`/`st` | TMEM↔RMEM 读回结果 |
| `tcgen05.wait::ld/st` | 等 ld/st 完成 |

> `tcgen05.mma` 单线程发起(隐含 `elect_one`)、异步，靠 `commit` 通知 mbarrier。

### 流程
```ptx
// 1. 分配 TMEM
tcgen05.alloc.cta_group::1.sync.aligned.b32 [tmem_d],  n_cols_D;
tcgen05.alloc.cta_group::1.sync.aligned.b32 [tmem_sf], n_cols_SF;

// 2. 搬数据：A/B FP8 → SMEM(TMA)；scale → SMEM → TMEM
cp.async.bulk.tensor.2d.shared::cluster.global.mbarrier::complete_tx::bytes
    [smem_a], [tma_desc_A,{coord}], [mbar_ab];
cp.async.bulk.tensor.2d... [smem_b], [tma_desc_B,{coord}], [mbar_ab];
cp.async.bulk... [smem_sfa], [tma_desc_SFA,{coord}], [mbar_sf];
tcgen05.cp.cta_group::1.32x128b [tmem_sf_a], [smem_sfa];   // SMEM→TMEM

// 3. 构造 descriptor
desc_a = base_a | (smem_a_addr >> 4);   // 64-bit smem desc (make_smem_desc_base|start_addr)
desc_b = base_b | (smem_b_addr >> 4);
idesc  = make_instr_desc(...);          // 32-bit (a_fmt=e4m3,b_fmt=e4m3,c_fmt=f32,M,N,...)

// 4. 沿 K 发 MMA：K=512 → 16 条，每条吃 K=32(=1 scale block)
@elect_one
tcgen05.mma.cta_group::1.kind::mxf8f6f4.block_scale.scale_vec::1X
    [tmem_d], desc_a, desc_b, idesc, [tmem_sf_a], [tmem_sf_b], enable_input_d;
//   第1条 enable=0(覆盖), 其余 enable=1(累加到同一 tmem_d)
//   硬件: Σ_32 a·b → ×2^(SFA+SFB) → += FP32

// 5. 提交完成
tcgen05.commit.cta_group::1.mbarrier::arrive::one.b64 [mbar_mma];

// 6. 读回累加器
tcgen05.wait::st.sync.aligned;
tcgen05.ld.sync.aligned.32x32b.x128.b32 {r0,...}, [tmem_d];   // TMEM→RMEM (make_tmem_copy)
tcgen05.wait::ld.sync.aligned;

// 7. 释放
tcgen05.dealloc.cta_group::1.sync.aligned.b32 [tmem_d], n_cols_D;
tcgen05.relinquish_alloc_permit.cta_group::1.sync.aligned;
```

### PTX ↔ DSL 操作数对应
| PTX 操作数 | DSL / 含义 |
|------|------|
| `idesc` | `make_instr_desc`(32-bit) |
| `desc_a/desc_b` | `make_smem_desc_base \| start_addr`(64-bit) |
| `[tmem_sf_a]/[tmem_sf_b]` | `Field.SFA/SFB`，scale 在 TMEM |
| `enable_input_d` | `Field.ACCUMULATE`(accum_c) |
| `.cta_group::1/2` | `CtaGroup.ONE/TWO`(2CTA M 翻倍) |
| `.scale_vec::1X` | block=32(MXFP8)；nvf4 块16 用 2X/4X |

> 注：PTX 操作数的精确 token 顺序以 PTX ISA(8.7+, sm_100)为准，此处按角色列出。

---

## 7. 一句话索引
- tcgen05 vs wgmma：累加器 TMEM、单线程异步、2CTA、A 可来自 TMEM。
- f8f6f4 一类：8-bit 容器共用 QMMA，FP8=FP6=FP4 算力(1×)，只省存储。
- K = 吞吐倍率：f8f6f4=32(1×)、mxf4/nvf4=64(2×)、SM103=96(3×)。
- FP4 元素只 E2M1，分 MXFP4(E8M0/32) 与 NVFP4(E4M3/16/两级)；无 NVFP8。
- E8M0 = 2 的幂 scale，MXFP8 GEMM = 裸 FP8 点积 + 指数加 scale + FP32 累加。
