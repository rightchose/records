# 23. tcgen05.cp（SMEM→TMEM 拷贝）+ tcgen05.shift（TMEM 行滚动）

> 锚点：承接 note 21（tcgen05 同步范式）、note 22（TMEM ld/st）。本篇补齐 TMEM 指令族的另外两条：
> `tcgen05.cp`（装载操作数进 TMEM，含低精度解压 + warp 级复制填充）和 `tcgen05.shift`（TMEM 原地行下移）。
> 来源：PTX ISA 9.7.17.9.2（cp）/ 9.7.17.9.3（shift）。
> 末尾附 **FA4 实测**：哪些真用了、哪些没用（纠正"shift 用于滑窗"的推断）。

---

## 0. TMEM 指令族全景（补全 note 22）

```
HBM ──TMA──> SMEM ──tcgen05.cp──> TMEM <──ld/st──> RF(寄存器)
                                   │
                              tcgen05.shift（TMEM 内原地行下移）
```

| 指令 | 方向 | 本仓笔记 |
|--|--|--|
| `tcgen05.ld` | TMEM → 寄存器 | note 22 |
| `tcgen05.st` | 寄存器 → TMEM | note 22 |
| **`tcgen05.cp`** | **SMEM → TMEM** | **本篇 §1-§4** |
| **`tcgen05.shift`** | **TMEM 内部（行下移）** | **本篇 §5** |

---

## 1. tcgen05.cp 语法与定位

```
tcgen05.cp.cta_group.shape{.multicast}{.dst_fmt.src_fmt} [taddr], s-desc;
                                        └──── 带 {} = 可选 ────┘
```
功能：**从 SMEM 异步拷贝到 TMEM**。`[taddr]`=目标 TMEM 地址；`s-desc`=SMEM 源描述符（描述源在 SMEM 的布局，类似 note 20）。

- **必选**：`.cta_group`（::1 / ::2，是否连 peer CTA）+ `.shape` + `taddr` + `s-desc`
- **可选**：`.multicast`（warp 复制填充，§3）、`.dst_fmt.src_fmt`（低精度解压，§2）
- 定位：**通用 SMEM→TMEM 装载通道**，不带任何可选修饰时就是原样拷贝。

---

## 2. 低精度解压 `.dst_fmt.src_fmt`（可选，4/6-bit 专属）

**取值集合就锁死了它的用途**：
```
.src_fmt = { .b6x16_p32 , .b4x16_p64 }   ← 源只有 6-bit / 4-bit，没别的
.dst_fmt = { .b8x16 }                      ← 目标只有 8-bit
```
读法：`b6x16_p32` = 位宽 **6** × **16** 个 + padding 到 **32**。

- 带 fmt ⟺ 做 **4/6-bit → 8-bit 解压**（无其他组合）。
- **裸 cp（不带 fmt）= 通用原样拷**，任何精度都能用。
- src/dst **成对出现**，不能只写一个。

**结论（精确）**：**指令通用，但"格式转换 feature"专为 4/6-bit 设计**。
- 低精度权重在 SMEM 用 4/6-bit 紧凑存（省带宽/容量），MMA 要吃 8-bit → `cp` 在搬运路径上顺手解压，零额外开销。
- 呼应 note 22 的"顺带操作"家族：`ld.red`=读顺带归约；`cp .fmt`=SMEM→TMEM 顺带解压。
- 关联 note 18（低精度 blockscale MMA）：4/6-bit 量化权重 → cp 解压成 8-bit 进 TMEM 喂 MMA。

| 场景 | 要不要 fmt |
|--|--|
| 低精度 4/6-bit（需解压） | ✅ `.b8x16.b6x16_p32` / `.b8x16.b4x16_p64` |
| 正常 8/16-bit（原样拷） | ❌ 裸 cp |

---

## 3. warp 复制填充 `.multicast`（建议改叫 warp-replicate-fill）

> ⚠️ **命名纠偏**：PTX 叫 multicast，但①和 TMA 的 CTA 级 multicast 撞名，②对 warpx2 不准确（不是纯复制）。
> 建议记为 **warp 复制填充 / warp 铺展**，与 TMA 的 CTA 广播分家。

### 3.1 为什么需要它 —— shape lane 数不足 128
前置（note 22）：TMEM 128 lane 按 warp 硬分区 —— **warp i → lane 32i~32i+31**。
`.shape` 第一个数 = lane（M 行方向）覆盖多少 lane：

| shape | lane 数 | 占几 warp | multicast |
|--|--|--|--|
| `.128x256b` / `.128x128b` | 128 | 全 4 warp | ❌ 不需要（**切分/分布**：各 warp 拿不同 32 行） |
| `.64x128b` | 64 | 2 warp 的量 | ✅ **要 warpx2** |
| `.32x128b` | 32 | 1 warp 的量 | ✅ **要 warpx4** |

**核心规律**：lane 铺满 128 = 切分（分布，各不同）；lane 不足 128 = 复制/铺展到多 warp。
→ **multicast(warpx2/warpx4) 只在操作数 lane 维 < 128、需要复制到空 warp 地盘时才出现。**

### 3.2 warpx2 / warpx4 语义
- **warpx4**：一份数据（32 lane）**复制到全部 4 warp**，内容全同。
- **warpx2**：4 warp 分 **2 对**，**跨对复制**（两对拿相同完整数据）+ **对内切半**（一对里两 warp 各存 32 lane）。
  - `.warpx2::02_13` → 对 (warp0,warp2) 和 (warp1,warp3)【lane 相隔远】
  - `.warpx2::01_23` → 对 (warp0,warp1) 和 (warp2,warp3)【lane 相邻】
  - 选哪个 = **匹配上游 MMA 的 warp tiling**（哪些 warp 组队共享操作数），选错=数据落错 warp lane 区=结果错。

### 3.3 taddr / s-desc 都是单参数（关键理解）
- **taddr 只写一个**（逻辑地址）；硬件给每个 warp **自动补 lane 基址（0/32/64/96）**，column/warp 内偏移相同，物理落点 lane 各不同。
- **s-desc 只写一个**（源读一次）—— 这正是 multicast "读一份源、播多目标"的本质、省 SMEM 带宽的来源。
- 但**参数单一 ≠ 各 warp 拿到的数据相同**：warpx4 全同；warpx2 跨对相同、对内各半。

### 3.4 具体例子
**例1 `.32x128b.warpx4`**（源 R0~R31，32 lane = 1 warp 量）：
```
A(32×K) 读一次 → warp0(lane0-31)=R0-31 / warp1(32-63)=R0-31 / warp2 / warp3  全同
```
**例2 `.64x128b.warpx2::02_13`**（源 R0~R63，64 lane 需 2 warp 装）：
```
对A(0,2): warp0=R0-31(上半,lane0-31)  warp2=R32-63(下半,lane64-95)
对B(1,3): warp1=R0-31(上半,lane32-63) warp3=R32-63(下半,lane96-127)  ← 对B=对A副本
验证：warp0+warp2=完整64行 ✓
```

### 3.5 用途 —— 共享操作数 / 大操作数分发
- **warpx4 = 共享操作数广播**：多 warp 用同一份小操作数（M=32 tile，切 N 分工时 A 被 4 warp 共用）→ SMEM 读一次广播到 4 warp lane 区，省 4× 带宽 + 免跨 warp 读 TMEM（跨 warp 读要同步，贵）。
- **warpx2 = 大操作数切分**：操作数 64 行装不进单 warp 32 lane → 一对 warp 各存半份，再复制给另一对。
- **与 2CTA 同哲学、下沉到 warp 层**：CTA 间用 TMA `multicast::cluster` 广播共享 B；warp 间用 cp `warpx4` 广播共享操作数。

> ⚠️ **纠错（本次对话）**：warpx4 广播的操作数 **M 必须=32**（不是 128）。M=128 是 `.128x...` **切分**（各 warp 不同 32 行），**不用 multicast**。
> 更深的"为什么 M<128 要复制而非留空" 牵涉具体 MMA atom 对操作数 lane 布局的要求，位级未坐实。

---

## 4. cp 与 TMA multicast 的区分（三处 multicast 分家）

| 原 PTX 名 | 建议命名 | 层级 | 播的是 | 动作 |
|--|--|--|--|--|
| TMA `multicast::cluster` | **CTA 广播** | 跨 CTA(cluster) | 数据(HBM→SMEM) | 复制给多 CTA |
| `tcgen05.cp` warpx2/4 | **warp 复制填充** | CTA 内(warp) | 数据(SMEM→TMEM) | 复制/铺展到多 warp |
| `tcgen05.commit multicast` | **信号广播** | 跨 CTA(pair) | barrier 信号 | 通知 pair 两 CTA |

同名不同事，共享"一对多分发"内核。层级不同因内存层级不同：TMA 播给 CTA（SMEM 是 CTA 私有）；cp 播给 warp（TMEM 按 warp 分 lane）。

---

## 5. tcgen05.shift —— TMEM 原地行下移

```
tcgen05.shift.cta_group.down  [taddr];      // .cta_group = ::1 / ::2
```
**功能**：异步地把 TMEM 里矩阵的**所有行（除最后一行）整体向下移一行**（row[i]→row[i+1]），for a warp。

### 5.1 逐条要点
- **异步**（initiates）：发出即返回，后台执行 → 需 note 21 的 wait/fence/commit 同步后才能读。
- **移位单位 = 32-byte 元素**：`shifting of 32-byte elements`。**注意是 byte 不是 bit**！
  - shape/ld/st 记法的 `32b` = 32 **bit**（column 位宽）；shift 的 `32-byte` = 32 **byte** = 256 bit。两个"32"单位不同，勿混。
  - **32-byte = MMA 在 K 维的粒度（K-block）**（用户坐实）→ shift 按 K 粒度滚动，天然对齐 MMA 消费，移完不错位。
  - "下移一行"=语义（方向/距离）；"32-byte"=搬运的原子/量化单位（一行由多个 32B 元素组成，按 32B 块搬，量化对齐）。
- **taddr lane 必须 32 对齐** = 对齐到 warp 边界（32 lane/warp）→ shift 以一个 warp 的 lane 区为单位。
- **cta_group**：::1 只移当前 CTA 的 TMEM；::2 连 peer CTA 一起移（呼应 2CTA 累加器池化）。
- **全 kernel 的 cta_group 必须一致**（所有 tcgen05 指令统一 ::1 或 ::2）。

### 5.2 用途（设计意图级）
沿 K 维滚动、窗口重叠复用的算法：
- **滑动窗口注意力**（首推）：KV 随序列滚动，每步 shift 一格 + 补新 KV，中间复用。
- **滚动累加器 / 流式**：固定大小 TMEM 窗口滚动，丢最旧纳最新。
- **卷积 / 时序滑窗**：重叠部分原地保留，只更新边缘。
- **核心价值**：把"滚动一格"从昂贵的 ld→重排→st，压成 **TMEM 内原地、异步、K 粒度对齐**的一条指令。

---

## 6. FA4 实测（`flash_attn/cute/`，纠正推断）

在 `/Users/mengran/Downloads/cluade_code/flash-attention/flash_attn/cute` 搜索坐实：

| 指令 | FA4 用了吗 | 证据 |
|--|--|--|
| `tcgen05.mma` | ✅ 大量 | `flash_fwd_sm100.py:465+`（QK^T/PV，cta_group/major_mode） |
| `tcgen05.ld`（TMEM→reg） | ✅ 大量 | `Ld32x32bOp` + `make_tmem_copy`：`:1911`(读S)、`:2274`(t2r 算softmax)、`:2683`(读O)、`:2760`(epilogue) |
| `tcgen05.st`（reg→TMEM） | ✅ 大量 | `St32x32bOp`：`:1917`(scale)、`:1924`(P，**fp8 用Rep8/否则16**)、`:2332`(r2t 写P)、`:2709`(写O) |
| **`tcgen05.shift`** | ❌ **没用** | 7 处 `shift` 全是别的：`shl/shr_u32`(位移)、`MaxShift/num_shift`(swizzle 字段)、`ptr_shift`(指针偏移) |
| `tcgen05.cp`（SMEM→TMEM） | ⚠️ 未见直接调用 | operand 可能走 SMEM descriptor 直接喂 mma，不经 cp 进 TMEM（待确认） |

**关键纠正**：
- FA4 **不用 `tcgen05.shift`** 做 TMEM 滚动 —— 之前"shift 用于 FA4 滑窗"是推断，实测不成立。FA4 的 causal/local **mask 走位运算**（`mask.py`），不是 TMEM 行 shift。
- `Ld32x32bOp`/`St32x32bOp` 的 `32x32b` = **32 lane × 32 bit**（bit），再次印证 §5.1 的 bit/byte 区分。
- P 矩阵写回 `St32x32b` 的 Repetition 随精度变（fp8→8，否则16），呼应 note 22 "P 用软件 recast + St32x32b"。

---

## 7. 一句话总结
- **cp** = 通用 SMEM→TMEM 装载；可选加挂 **4/6-bit→8-bit 解压** 和 **warp 复制填充**（lane<128 时复制到多 warp，warpx4 全同/warpx2 对内切半）。taddr/s-desc 各一个，硬件按 warp 补 lane 偏移。
- **shift** = TMEM 内原地异步行下移，单位 **32-byte（=MMA K 粒度，非 bit）**，为滑窗/滚动算法服务。
- **FA4 实测**：重用 ld/st + mma，**不用 shift、未见 cp**；mask 靠位运算而非 TMEM 滚动。
