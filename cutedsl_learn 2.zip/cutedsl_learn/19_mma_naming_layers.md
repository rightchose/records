# 19. MMA 命名学 —— UMMA / WGMMA(发射机制) vs HMMA/IMMA/QMMA/OMMA(SASS 通路)

> 锚点：承接笔记 18(tcgen05 vs wgmma)。本篇专讲"为什么叫这些名字"，
> 关键是分清**两个层级**：PTX/架构指令名 ≠ SASS/数据通路名。别把 UMMA 和 QMMA 并列。

---

## 0. 两层不要混

| 层级 | 是什么 | 在哪看到 | 例子 |
|------|------|------|------|
| **PTX / 架构指令名** | MMA **怎么发射、累加器在哪** | `.ptx`、CUTLASS DSL | **WGMMA** / **UMMA** |
| **SASS / 数据通路名** | tensor core 内部走**哪条精度通路** | `cuobjdump -sass` / nvdisasm | **HMMA/IMMA/QMMA/OMMA** |

一句话：**WGMMA/UMMA 说"怎么发指令"，HMMA/QMMA 说"用什么算"**。
所以 "FP8 走 UMMA 指令、走 QMMA 数据通路"——两者是上下两层，不是同义词。

---

## 1. PTX 层：WGMMA(Hopper) → UMMA(Blackwell)

### WG = **W**arp**G**roup

- 1 warp = 32 线程；**1 warpgroup = 4 连续 warp = 128 线程**(warp 0-3、4-7…)。
- `wgmma.mma_async` 必须由**一整个 warpgroup 的 128 线程协同发射**，累加器矩阵 C 切碎摊到这 128 线程的 RMEM 里。名字直接点出"发射主体 = 这组 warp"。

### U = **U**niversal

Blackwell `tcgen05.mma` 打破了 warpgroup 这层约束，四个维度都"统一"了：

| 维度 | WGMMA (Hopper) | UMMA (Blackwell) |
|------|------|------|
| 发射粒度 | 128 线程 warpgroup 协同 | **单线程 elect 发射** |
| 累加器 | 分散在 128 线程 **RMEM** | 统一的 **TMEM**(CTA/2CTA 共享) |
| 操作数寻址 | A: RMEM/SMEM, B: SMEM(不对称) | A/B 统一 SMEM desc(+ A 可 TMEM 链式) |
| dtype | 一条条分家 | 一族指令统一覆盖 F16→FP4 |

> FA4 体现：`flash_fwd_sm90.py` 按 warpgroup 分角色做 warp-group GEMM；
> `flash_fwd_sm100.py` 16 warp 切 4 warpgroup，但 **MMA 只由 leader 单线程发**(UMMA)。

### 1.5 MMA 变体决定 output layout → 反向钉死 ld 的 lane

UMMA 累加器在 TMEM，但**具体怎么铺**由 MMA 变体决定，而这直接约束了下游 `tcgen05.ld` 该挑哪个 shape：

> *The number of lanes is most affected by the MMA instruction used; different `tcgen05.mma`
> variants result in different output layouts, and different `tcgen05.ld` shapes are suited for
> different situations.*

- 不同 `tcgen05.mma` 变体(M=128 vs M=256 的 2CTA、不同 N、不同 dtype)把结果元素铺到
  **不同的 lane×column 位置**(output layout) → 规定了"哪个 warp 负责累加器哪几行"。
- 所以读回时 ld 的 **lane 部分**(`16x…` vs `32x…`)是被 MMA **反推**出来的硬约束，不是自由挑的；
  你真正能选的只是 **column 方向**的读法(读多宽 / split / pack)。
- **完整推导见 note 22 §3.5** —— "lane 被 MMA 钉死，你只在挑 column 读法"。

---

## 2. SASS 层：H/I/Q/OMMA，字母 = 相对 FP32 的位宽比例

| SASS | 字母含义 | 精度通路 | 相对 FP32 |
|------|------|------|------|
| **HMMA** | **H**alf | FP16 / BF16 / TF32 | 1/2 (16-bit) |
| **IMMA** | **I**nteger | INT8 / INT4 | — |
| **QMMA** | **Q**uarter | **FP8**，及 f8f6f4 里 pad 到 8-bit 的 FP6/FP4 | 1/4 (8-bit) |
| **OMMA** | one-eighth | **打包 FP4**(mxf4/nvf4)的 2× 通路 | 1/8 (4-bit) |

### 和笔记 18"为什么 FP8/FP6/FP4 同算力"对应

- **f8f6f4 模式**：FP8/FP6/FP4 全部 lower 成 **QMMA** —— 都塞进 8-bit 容器走同一条 Quarter 通路，所以**同吞吐(1×)**，FP6/FP4 只省存储不省算力。
- 只有**专用 mxf4/nvf4** 才 lower 成 **OMMA**(真打包 4-bit)，拿到 **2×**(B300/SM103=3×，instruction_k 96/64=1.5× 再叠加)。

---

## 3. 完整对照：FP8 在两代上的双层名字

| | Hopper FP8 | Blackwell FP8 |
|--|------|------|
| PTX 指令 | `wgmma.mma_async` (**WGMMA**) | `tcgen05.mma` (**UMMA**) |
| SASS 通路 | **QMMA** | **QMMA** |
| 累加器 | RMEM | TMEM |

→ 同一个 FP8，PTX 名随架构变(WGMMA→UMMA)，SASS 通路名不变(都是 QMMA)。

---

## 4. 一句话索引
- **WG = WarpGroup(128 线程)**；WGMMA = warpgroup 协同发射、累加器摊 RMEM。
- **U = Universal**；UMMA = 单线程发射、累加器 TMEM、A/B 统一 SMEM 寻址、一族覆盖所有 dtype。
- **WGMMA/UMMA(PTX，怎么发) ≠ HMMA/IMMA/QMMA/OMMA(SASS，用什么算)**，分两层。
- 字母比例：H=半(16b)、I=整数、**Q=四分之一(8b,FP8)**、O=八分之一(4b,打包FP4)。
- f8f6f4 → QMMA(1×，FP8=FP6=FP4)；专用 mxf4/nvf4 → OMMA(2×/3×)。
