# CuTe DSL GEMM Autotuning（学习笔记 · General 系列收尾篇）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/autotuning_gemm.html
> 主题：怎么用 CuTe DSL 给 GEMM 做 autotuning。本质是前面所有概念（特化/JIT caching/static-dynamic/separate compile-execute）的**实战汇总**——把"造出一堆 kernel 变体 + 自动挑最快的"工程化。

---

## 〇、一句话总览

```
没有一套 kernel 参数对所有输入都最优（小矩阵≠大矩阵）
   ↓
autotuning 三步：① 定义搜索空间  ② 逐个 benchmark 选最快  ③ 缓存结果省下次开销
```

---

## 一、为什么 GEMM 需要 autotuning

```
不同输入 (shape (m,n,k)、dtype) → 最优 kernel 参数不同
   → 没有"一招鲜"，只能针对实际输入挑参数
```
集成进框架时，这是"达到最优性能的必备步骤"。

---

## 二、可调旋钮（以 Blackwell persistent GEMM 为例）

| 旋钮 | 含义 |
|------|------|
| `mma_tiler_mn` | 每条 MMA 指令处理的矩阵 tile 尺寸 |
| `cluster_shape_mn` | 一个 cluster 内每维的 CTA 数（合法组合看 PTX ISA，跟 dtype 相关） |
| `use_2cta_instrs` | 是否用 Blackwell 的 2-CTA 指令（对应 FA4 笔记的 2CTA 机制） |
| `use_tma_store` | 是否用 TMA 指令把结果写回 global memory |

> ⚠️ 搜索空间是 **kernel-specific** 的；这页**没把 stages 列为旋钮**。

---

## 三、核心 API

| API | 作用 |
|-----|------|
| `cute.compile()` | 编译一次 → 返回可复用的 JIT executor（separate compile/execute） |
| `PersistentDenseGemmKernel(...)` | 每个 config 实例化一个 kernel |
| `cutlass.utils.HardwareInfo().get_max_active_clusters(...)` | 查硬件能跑几个 active cluster |
| `cutlass.Float32` | 累加器 dtype |
| `autotune_gemm` | **用户自定义**的穷举搜索函数 |
| `benchmark` | **用户可定制**的计时函数 |
| `config_kernel_dict` / `input_kernel_dict` | 两层缓存字典 |

---

## 四、搜索 + 两层缓存（这页精髓）

`autotune_gemm` = **暴力穷举**：四层嵌套循环遍历
`use_2cta_instrs × use_tma_store × mma_tiler_mn × cluster_shape_mn`，
每个 config 实例化 + 编译(或取缓存) + benchmark，追踪 `min_time`/`best_kernel`。

### 两层缓存

```
外层 input_kernel_dict   ← key = config_key，来自输入特征 (m,n,k)
   │   命中 → 直接拿之前调好的 best kernel，跳过整个 autotune
   │   未命中 → 才跑 autotune_gemm
   ▼
内层 config_kernel_dict  ← key = kernel_cache_key = {dtype + kernel configs}
       命中 → 复用已编译 kernel，跳过 cute.compile
       未命中 → cute.compile 一次后存入
```

`kernel_cache_key` 格式（逐字）：
```python
kernel_cache_key = f"{ab_dtype}x{c_dtype}x{acc_dtype}x{use_2cta_instrs}x{mma_tiler}x{cluster_shape_mn}x{use_tma_store}"
```

### 内层（autotune_gemm 主体，verbatim 精简）
```python
def autotune_gemm(a, b, c, stream,
                  use_2cta_instrs_list=[True], use_tma_store_list=[True],
                  mma_tiler_m_list=[256], mma_tiler_n_list=[256],
                  cluster_shape_m_list=[2], cluster_shape_n_list=[1]):
    best_kernel = None
    min_time = float("inf")
    for use_2cta_instrs in use_2cta_instrs_list:
      for use_tma_store in use_tma_store_list:
        for mma_tiler_mn in product(mma_tiler_m_list, mma_tiler_n_list):
          for cluster_shape_mn in product(cluster_shape_m_list, cluster_shape_n_list):
            acc_dtype = cutlass.Float32
            hardware_info = cutlass.utils.HardwareInfo()
            max_active_clusters = hardware_info.get_max_active_clusters(
                cluster_shape_mn[0] * cluster_shape_mn[1])
            gemm = PersistentDenseGemmKernel(
                acc_dtype, use_2cta_instrs, mma_tiler_mn, cluster_shape_mn, use_tma_store)
            # 内层缓存：编译产物
            if kernel_cache_key not in config_kernel_dict:
                compiled_gemm = cute.compile(gemm, a, b, c, max_active_clusters, stream)
                config_kernel_dict[kernel_cache_key] = compiled_gemm
            else:
                compiled_gemm = config_kernel_dict[kernel_cache_key]
            try:
                cur_time = benchmark(partial(compiled_gemm, a, b, c, stream))
            except Exception as e:
                cur_time = float("inf")
            if cur_time < min_time:
                min_time, best_kernel = cur_time, compiled_gemm
    if best_kernel is None:
        raise ValueError("No best kernel found")
    return best_kernel
```

### 外层（按输入特征缓存调优结果）
```python
config_key = (m, n, k)
if config_key in input_kernel_dict:
    compiled_gemm = input_kernel_dict[config_key]    # 调好过 → 直接用
else:
    compiled_gemm = autotune_gemm(...)               # 没调过 → 穷举
    input_kernel_dict[config_key] = compiled_gemm
compiled_gemm(a_tensor, b_tensor, c_tensor, stream)  # launch
```

**减少 key 数量技巧**：`config_key = (power_of_2(m), power_of_2(n), power_of_2(k))` 把相近 shape 归并（少几个变体），但**是近似，得自己验证不掉性能**。

---

## 五、和前面概念怎么扣上

```
JIT Caching 页讲「为什么能缓存」 → 这页讲「怎么用缓存做 autotuning」
separate compile/execute        → cute.compile 一次、cached executor 调多次（省 host 开销）
特化(每 config 一个独立 kernel)  → 所以 dtype+configs 进 kernel_cache_key
static layout                   → 若输入是 static layout，shape 也要进 key
```
（这页没显式提 Constexpr，但"每 config 一个特化 kernel"正是 09 笔记 constexpr 组合数=kernel 数的延续。）

---

## 六、注意事项 / benchmark 建议

- **暴力穷举又准又贵** → 进阶可做 search space pruning / 遗传算法
- **static 输入** → kernel cache key 要含 shape
- **`power_of_2` 简化 key** → 省 key 但要验证不掉性能
- **稳定计时**：5~10 次 warmup（稳 GPU 温度）+ 100~1000 次计时（统计显著）+ CUDA events 同步精确计时 + `nvidia-smi` 锁 SM/显存频率 + 去离群值，看 min/avg

---

## 七、串联（General 系列怎么合上这本书）

```
06 layout/divisibility ─┐
07 代码跑两遍/特化     ─┤
08 控制流              ─┼─▶ 教你「怎么造出一堆特化 kernel 变体」
09 constexpr=kernel数  ─┤
11 static/dynamic+caching┘
                        ▼
            autotuning = 在这堆变体里「自动挑最快 + 缓存」
```

- 前面页教**怎么造变体**（constexpr/特化/static layout）
- JIT caching 教**为什么变体能缓存复用**
- 这页给**临门一脚**：两层 dict 把"挑变体"工程化（内层缓存编译产物、外层缓存"某 (m,n,k) 用哪个变体"）

> **对 FA4 的意义**：`_TUNING_CONFIG` 那张表本质就是这页"autotune 结果"的**离线固化版**——预先调好、写死成表，运行时直接查表，免得每次 brute-force。

---

## 八、一句话总结

> **GEMM autotuning = 「定义搜索空间 → 暴力 benchmark 挑最快 → 两层缓存」**：内层 `config_kernel_dict`（key=dtype+configs）缓存 `cute.compile` 的编译产物、避免重复编译；外层 `input_kernel_dict`（key=(m,n,k)）缓存"某输入该用哪个 best kernel"、避免重复穷举。它建立在 CuTe DSL 的 separate compile/execute + 特化机制上，是 General 系列所有概念的实战收尾；生产中常把 autotune 结果离线固化成 config 表（如 FA4 的 `_TUNING_CONFIG`）。
