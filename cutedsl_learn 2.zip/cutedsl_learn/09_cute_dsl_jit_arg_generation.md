# CuTe DSL JIT 参数生成（DSL JIT Argument Generation 页面学习笔记）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/dsl_jit_arg_generation.html
> 真实代码引用：本地 cutlass 仓库 `python/CuTeDSL/cutlass/`
> 主题：`@jit` 函数的参数是怎么生成/处理的 —— static vs dynamic 在参数层的落地，以及自定义类型怎么传进 kernel。

---

## 〇、In a nutshell：参数的四条规则

用 `@jit` / `@kernel` 时，函数参数被 trace 出一个 **JIT 签名**。你照常用 Python 写参数，DSL 处理剩下的：

```
1. 参数默认 dynamic（除非另行指定）
2. 标 cutlass.Constexpr → 编译期常量
3. 类型标注 → 编译期类型校验（type safety）
4. 两个 runtime-checkable 协议 JitArgument / DynamicExpression → 支持自定义类型
```

---

## 一、Static vs Dynamic 参数

「代码跑两遍」在参数层的体现：

| | Static（Constexpr） | Dynamic（默认） |
|---|---|---|
| 值何时知道 | 编译期 | 运行时 |
| 在签名里吗 | **不在**，烤进 kernel | **在**，组成签名 |

```python
@cute.jit
def f(x: cutlass.Int32, y: cutlass.Constexpr):
    ...
# x → dynamic（进签名，运行时传）
# y → static （不进签名，编译期烤进 kernel）
```

文档实例：GEMM 的 `epilogue_op: cutlass.Constexpr`，可传 lambda 做 epilogue 融合：
```python
epilogue_op = lambda x: cute.where(x > 0, x, cute.full_like(x, 0))  # ReLU 融合
```

### 关键问答：static 不进签名，为什么 64/128 还会生成两个 kernel？

「不进签名」和「区分 kernel」是两件事：
```
签名      = 已编译好的 kernel 运行时接收哪些参数
选哪个kernel = 编译期决定用哪份编译产物
static 参数：不进①签名，但参与②选/造 kernel
```

**正因为 static 不进签名（运行时不传）→ kernel 内部无从读取它 → 只能编译期把值焊死进代码 → 不同的值=不同的代码=不同的 kernel。**

```python
def f(x, head_dim: Constexpr):
    return x * head_dim

f(x, 64)  → kernel_A:  kernel(x){ return x*64; }   # 64 焊死，签名只有 x
f(x, 128) → kernel_B:  kernel(x){ return x*128; }  # 128 焊死，签名只有 x
```
两个 kernel 签名相同（都只有 x），区别在**代码体里焊死的常量**。完全等同 C++ 模板：模板参数不在函数签名里，但每个模板实参生成独立实例。

### 给几个 constexpr 会生成几个 kernel？

```
生成的 kernel 数 = 实际调用中出现过的「constexpr 值组合」的去重数量
```
- 算的是**实际调用到的组合**（lazy，非全笛卡尔积），同 C++ 模板未实例化不生成代码
- 每个组合编译一次后**缓存**，同组合复用
- dynamic 参数**不影响** kernel 数量
- ⚠️ 把变化范围大的值（如每次不同的 seqlen）标成 Constexpr → kernel 爆炸 + 编译开销巨大，这种该用 dynamic
- （精确缓存 key/失效策略在单独的 "JIT Caching" 页）

---

## 二、Type Safety：编译期就报错

类型标注在**编译期**校验，不匹配**提前失败**，报错清晰：
```
expects argument #1 (a) to be ... Tensor ..., but got ... 'int'
```

**为什么重要**：GPU 运行时错误极难调（对不上行号、信息晦涩）。类型错挡在编译期、挡在 host/Python 层 = 实在的体验提升。

**几点认知**：
- 能做编译期类型检查，是因为参数本就被 trace 成**带类型的 IR value**（呼应控制流「IR value 静态类型」）
- 类型标注**可选但推荐**；不标注 → 默认 dynamic + 从调用点推断，不做这层显式校验
- `: cute.Tensor`（类型标注，管 type safety）与 `: cutlass.Constexpr`（管 static/dynamic）是**两种不同标注**，解决不同问题
- 边界：只查**类型**，不查 shape/值层面正确性 —— 那些靠 kernel 逻辑或 divisibility 暴露

---

## 三、自定义类型：两个协议

内置 int/float/Tensor 之外，自定义/第三方对象当 `@jit` 参数，需实现协议告诉 DSL 怎么转换它。DSL 编译期要转成 MLIR 类型建签名，运行时要转成指针/values，kernel 内还要重建对象。

| 协议 | 用途（按调用边界区分） | 方法 |
|------|------|------|
| **`JitArgument`** | **host** JIT 函数（从 Python 调） | `__c_pointers__`（出 ctypes 指针）、`__get_mlir_types__`（出 MLIR 类型）、`__new_from_mlir_values__`（从 values 重建） |
| **`DynamicExpression`** | **device** JIT 函数（从 host JIT 调） | `__extract_mlir_values__`（出 dynamic values）、`__new_from_mlir_values__` |

```
Python ──调用──▶ host JIT 函数        ← 自定义参数用 JitArgument
                     └──调用──▶ device kernel   ← 用 DynamicExpression
```

三个方法对应三个环节：

| 方法 | 环节 | 干啥 |
|------|------|------|
| `__get_mlir_types__` | 编译期建签名 | 我对应哪些 MLIR 类型 |
| `__c_pointers__` / `__extract_mlir_values__` | 运行时/传参 | 怎么取出我的数据（指针 / dynamic values） |
| `__new_from_mlir_values__` | kernel 内部 | 怎么从 values 把我拼回来 |

### 两种实现方式

```
能改这个类的源码？
├─ 能  → 方式1：直接在类上实现协议方法（侵入式，内聚）
└─ 不能（第三方对象）→ 方式2：注册 adapter（非侵入式，外挂桥接）
```

完整协议细节见 CUTLASS 仓库 `cute/typing.py`。

---

## 四、真实代码例子（本地 cutlass 仓库）

### 例 1：CUDA Stream 适配器（方式 2 - adapter）

文件：`cutlass/cutlass_dsl/cuda_stream_adapter.py`

**场景**：`cuda.bindings.driver.CUstream` 是 `cuda-python` 包的类型，**改不了源码** → 用 adapter 桥接，把 CUDA stream 传进 JIT kernel 控制异步执行。

```python
@JitArgAdapterRegistry.register_jit_arg_adapter(cuda_driver.CUstream)
class CudaDialectStreamAdapter:
    def __init__(self, arg):
        self._arg = arg
        self._c_pointer = self._arg.getPtr()           # 预存 C 指针

    # ① 运行时：把 stream 变成 C 指针，递给底层
    def __c_pointers__(self):
        return [self._c_pointer]

    # ② 编译期：在 MLIR 里是什么类型 → cuda 的 StreamType
    def __get_mlir_types__(self):
        return [cuda.StreamType.get()]

    # ③ kernel 内：从 MLIR values 重建（stream 就一个值，直接返回）
    def __new_from_mlir_values__(self, values):
        assert len(values) == 1
        return values[0]
```

印证文档：`register_jit_arg_adapter` 注册 + `JitArgument` 三件套 + 第三方类型改不了用 adapter。
（真实注册路径是 `JitArgAdapterRegistry.register_jit_arg_adapter`）

### 例 2：SymInt 直接实现协议（方式 1 - 类内实现）

文件：`cute/typing.py` 的 `SymInt`（= 带 divisibility 的动态整数，CUTLASS 自家类型，能改 → 直接类内实现）

```python
class SymInt:
    # ② 编译期 MLIR 类型 —— 直接编码 divisibility！
    def __get_mlir_types__(self):
        res_ty = ir.Type.parse(
            f'!cute.int_tuple<"?{{i{self.width} div={self.divisibility}}}">'
        )                      # 生成 ?{i32 div=4}，正是 IntValue 笔记里的 ?{div=4}
        return [res_ty]

    # ③ kernel 内重建：按宽度包成 Int32/Int64
    def __new_from_mlir_values__(self, values):
        if self.width == 32:
            return Int32(IntValue(values[0]))
        elif self.width == 64:
            return Int64(IntValue(values[0]))

    # ① C 指针（SymInt 是纯编译期符号，给占位空指针）
    def __c_pointers__(self):
        return [ctypes.c_void_p(0).value]
```

**顺带验证了 06 笔记的 divisibility**：同文件 `SymInt.__mod__` 有
`if self._divisibility % other_div == 0: return 0`（divisibility 传播），
`__mul__` 有 `divisibility = self._divisibility * other`
（印证 `?{div=4} * ?{div=2} → ?{div=8}`）。

### 文档 → 真实代码对照

| 文档说的 | 真实代码 |
|---------|---------|
| `JitArgument` 协议三方法 | `CudaDialectStreamAdapter` 完整实现 |
| `register_jit_arg_adapter` | `@JitArgAdapterRegistry.register_jit_arg_adapter(CUstream)` |
| 方式1：直接实现 | `SymInt` 类内实现 |
| 方式2：adapter | CUDA stream（第三方 `CUstream` 改不了） |
| `__get_mlir_types__` 出 MLIR 类型 | `cuda.StreamType.get()` / `?{i32 div=4}` |

---

## 五、关键 API 速查

```
@cute.jit / @cute.kernel              装饰器
cutlass.Constexpr                     标记 static 参数
cutlass.register_jit_arg_adapter      注册自定义类型适配器
                                      （真实路径 JitArgAdapterRegistry.register_jit_arg_adapter）
JitArgument / DynamicExpression       两个协议
协议方法：__c_pointers__ / __get_mlir_types__ /
         __new_from_mlir_values__ / __extract_mlir_values__
完整协议细节 → CUTLASS 仓库 cute/typing.py
```

---

## 六、一句话总结

> **`@jit` 参数默认 dynamic（进签名、运行时传），标 Constexpr 变 static（不进签名、编译期烤进 kernel）；类型标注触发编译期 type safety 校验。** static 不进签名却能区分 kernel，是因为值被焊死进代码，不同值=不同代码=不同 kernel（同 C++ 模板，kernel 数=实际用到的 constexpr 组合数）。自定义类型靠 `JitArgument`(host) / `DynamicExpression`(device) 协议接入：能改源码就类内直接实现（如 `SymInt`），改不了就 `@register_jit_arg_adapter` 注册外部 adapter（如 `CUstream`）。
