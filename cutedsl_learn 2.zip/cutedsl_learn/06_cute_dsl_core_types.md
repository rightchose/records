# CuTe DSL 核心类型详解（Types 页面学习笔记）

> 来源：https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/cute_dsl_general/types.html
> 对应 `cutlass.cute.core` 里的核心类型，是「张量布局代数（tensor layout algebra）+ GPU 编程」的基础。

---

## 〇、Overview：类型全景

整页类型按层级分为 5 组，核心思想是**层层叠加**：

```
数值层      IntValue / Ratio
   │
布局层      ScaledBasis / Swizzle  ──撑起──▶  Layout / ComposedLayout
   │
内存层      Pointer
```

并且有一个贯穿全局的公式：

```
T = E ∘ L      （Tensor = Engine(Pointer) ∘ Layout）
张量 = 引擎/指针 ∘ 布局
```

即 **Pointer 与 Layout 组合就构成一个 Tensor**。

| 分组 | 类型 | 一句话 |
|------|------|--------|
| Core Numeric | `IntValue` | 带「可整除约束」的动态整数 |
| Core Numeric | `Ratio` | 两整数之比，表示除不尽时的精确分数 |
| Layout Algebra | `ScaledBasis` | 给 stride 标方向/模的 (value, mode) 对 |
| Layout Algebra | `Swizzle` | XOR 地址置换，避 bank conflict |
| Layout Algebra | `Layout` | 核心：(Shape, Stride) 坐标→index 映射 |
| Layout Algebra | `ComposedLayout` | inner∘offset∘outer，把 swizzle 贴到 layout 上 |
| Memory | `Pointer` | 带 dtype/内存空间/对齐的地址 |
| Structured | `struct` / `union` | C 风格结构体/联合体，描述 smem 布局 |
| Deprecated | `ThrMma` / `ThrCopy` | 已弃用 |

**Best Practice**：编译期已知的维度用 Python 原生 `int`（约束最强、优化最好）；运行时才确定的用 `IntValue`。

---

## 一、Core Numeric Types（核心数值类型）

### 1.1 IntValue —— 带「可整除约束」的动态整数

`IntValue` 是 CuTe IR 里「受约束整数」的代理（proxy）。它表示一个**运行时才确定、编译期未知**的整数，但可以携带一条编译期就知道的约束：**这个数一定是某因子的整数倍**。

| 打印形式 | 含义 |
|---------|------|
| `?` | divisibility = 1，未知动态整数，无额外约束 |
| `?{div=4}` | 值未知，但**保证是 4 的倍数** |

**API**
- `divisibility` 属性 / `get_divisibility()` —— 查询整除约束
- `get_typed_value()` —— 返回 IntTupleType
- 继承自 `ArithValue`，自动在 IR 里发 `cute.get_scalars`

**divisibility 信息为什么重要**

layout 代数（composition / coalesce / complement 等）经常要求「一个 size 或 stride 能整除另一个」。
- 维度是静态 `int` → 编译器直接验证整除；
- 维度是动态值 → 编译器看不到具体数，但只要带 `?{div=4}` 这样的约束，**仍能证明整除条件成立**，生成正确且优化过的代码。

**约束会在运算中传播（propagate）**：动态整数做 `+ - * // %` 时，结果的 divisibility 由操作数推导。例如：
- `?{div=4} * ?{div=2}` → 至少 `?{div=8}`
- `?{div=8} // 2` → `?{div=4}`

支持运算：加、减、乘、floor 除 `//`、模 `%`，全部带 divisibility 追踪。

### 1.2 Ratio —— 除不尽时的精确分数

用两个整数的比 `p/q` 表示一个**可能除不尽的精确有理数**，给 layout 运算提供精确分数值。

**IntValue 与 Ratio 的关系（关键）**：它们不是「输入二选一」的对等类型，而是 layout 做除法那一刻**结果的去向**：

```
某 layout 运算需要 A // B
├─ 能整除（divisibility 能证明） → 结果是整数 → IntValue（带传播后的 div 约束）
└─ 不能整除                      → 结果是分数 → Ratio（保留 p/q，不丢精度）
```

- `IntValue` 永远表示**整数**，是你写代码时用的动态整数；
- `Ratio` 通常是**运算过程中编译器自动产生的中间结果**，你一般不会主动 new。

### 1.3 用户需要关注吗？

**大多数情况不用**——这俩都是框架内部实现细节，自动产生和传播。只有踩到这些坑才回头看：
1. 报错里出现 `?{div=N}` 或 Ratio（composition/divide 报「divisibility 不满足」）→ 需显式约束动态维度，或改用静态 `int`；
2. 怀疑没走静态优化路径（动态维度丢了 div 信息会退化）；
3. 写 varlen / 动态 shape kernel（如 seqlen 参与 tile 切分）→ 把它约束成 8/16/64 的倍数能省麻烦。

> 结论：先当「报错时的查询手册」，平时不用主动学。

---

## 二、Layout Algebra Types（布局代数类型）

四个类型，从底到顶依赖关系：`ScaledBasis` / `Swizzle` 撑起 `Layout` / `ComposedLayout`。

### 2.1 Layout —— 核心：(Shape, Stride) 二元组

把**逻辑坐标空间 → 线性 index 空间**的映射，本质是个点积：

```
index = coord · stride   （坐标和 stride 做点积）
```

例：shape `(4,8)`，stride `(8,1)`，坐标 `(2,3)` → `2*8 + 3*1 = 19`

- 默认构造 `make_layout((4,8))` 是 **column-major**（列优先）
- 传 `stride=(8,1)` 就是 **row-major**（行优先）
- 字符串形式：`shape:stride`，如 `(4,8):(1,4)`
- 是**层级嵌套**结构（由更小的 layout 套出来）

**属性**：`shape`（IntTuple）、`stride`（IntTuple）、`max_alignment`（最大对齐字节）

**丰富的代数运算**：
| 运算 | 含义 |
|------|------|
| Concatenation | 沿维度拼接 layout |
| Coalescence | 合并相邻 mode |
| Composition | 与函数或其他 layout 组合 |
| Complement | 计算补空间 |
| Inversion | 求逆映射 |

> 这些运算的整除前提，正是 §1.1 divisibility 在背后支撑的。

### 2.2 ScaledBasis —— 给 stride 标方向/模

一个 `(value, mode)` 对：`value` 是缩放系数，`mode` 指定缩放哪个基。写法 `2@0` = 「2 倍的 0 号基」。

**构造**：`cute.ScaledBasis(value, mode)`
- `value`：`Union[int, Integer, Ratio, ir.Value]`
- `mode`：`Union[int, List[int]]`（不是 int 或 int 列表会抛 `TypeError`）

**属性**：`value`、`mode`（返回 int 列表）、`is_static()`
**方法**：`to(dtype)` 转换类型
**简写**：`cute.E(mode)` ≡ `ScaledBasis(1, mode)`（单位缩放基）

**示例**：
- `cute.ScaledBasis(2, 0)` → `2 * E(0)`
- `cute.ScaledBasis(cute.Ratio(1, 2), 1)` → `(1/2) * E(1)`（缩放系数是 Ratio，呼应 §1.2）
- `cute.ScaledBasis(4, [0, 1])` → `4 * E([0, 1])`
- 标量左乘重新缩放：`3 * ScaledBasis(2, 0) = ScaledBasis(6, 0)`
- 用在 stride 里：`stride=(2@0, 1@1)`，坐标 `(2,3)` 经 `crd2idx` → `(4, 3)`，每维携带自己的基

**作用**：在 **multi-modal layout** 里，让每个维度的 stride 明确「指向哪个模」。

### 2.3 Swizzle —— XOR 地址置换，避 bank conflict

把地址重排，**把同时访问打散到不同 shared memory bank**，避免串行化。

**三个参数**：
| 参数 | 含义 |
|------|------|
| **MBase** | 保持不变的最低 N 位 |
| **BBits** | 掩码的位数 |
| **SShift** | 掩码移动距离（正=右移，负=左移） |

**机制**：把高位字段 XOR 进低位字段。文档原图：

```
输入   ...YY...ZZ...
输出   ...YY...AA...      其中 AA = ZZ xor YY
```

高位组 YY 经 SShift 移位后 XOR 进低位组 ZZ，最低 MBase 位原样保留。这个 XOR 扰动就是打散 bank 的关键。通常用 swizzle factory 函数生成，再 compose 到 layout 上。

### 2.4 ComposedLayout —— 把 Swizzle 贴到 Layout 上

普通 Layout 的内层映射只能是 stride 点积；`ComposedLayout` 允许内层是**任意函数**（典型就是 Swizzle）。这就是「带 swizzle 的 shared memory layout」在代码里的真身。

**数学本质：三段函数复合**

```
最终映射(coord) = inner( offset + outer(coord) )

字符串打印：inner o offset o outer    （o 即数学复合符号 ∘）
```

**数据流从右往左**走：

```
coord ──outer──▶ 中间坐标 ──+offset──▶ 偏移后 ──inner──▶ 最终地址
       (外层布局)          (加偏移)            (内层变换/swizzle)
```

| 部件 | 类型 | 作用 |
|------|------|------|
| **outer** | Layout | **先作用**。普通 (Shape,Stride)，把逻辑坐标排成中间线性 index。`composed.shape` 来自它 |
| **offset** | IntTuple | **中间作用**。整体平移基址；多 stage/多子块共用同一布局只靠它区分起点。大多为 0 |
| **inner** | Union[Swizzle, Layout] | **最后作用**。是 Swizzle 时对地址做 XOR 置换，打散 bank |

**属性**：`inner`、`offset`、`outer`、`shape`、`max_alignment`、`is_normal`（是否普通 layout 而非一般复合）

**构造与读取**：
```python
composed = cute.composition(swizzle, layout)
composed.inner    # → swizzle
composed.outer    # → layout
composed.offset   # → 偏移
```

---

## 三、ComposedLayout 完整演算示例

设一个 4×4 的 shared memory tile：
- `outer` = `Layout (4,4):(4,1)`（row-major，`(r,c) → r*4 + c`）
- `offset` = `0`
- `inner` = `Swizzle<BBits=2, MBase=0, SShift=2>`，公式 `i ^ ((i & 0b1100) >> 2)`

### 3.1 单个坐标 (3,2)：从右往左

```
coord=(3,2)
   │ ① outer:   3*4 + 2 = 14
   ▼
   14
   │ ② +offset: 14 + 0 = 14
   ▼
   14
   │ ③ inner(swizzle): 14 ^ ((14&0b1100)>>2)
   │                 = 1110 ^ (1100>>2) = 1110 ^ 0011 = 1101 = 13
   ▼
最终物理地址 = 13
```

逻辑上访问「第 3 行第 2 列」，物理落在 smem 第 **13** 号槽位。

### 3.2 看一整列才懂为什么（取第 2 列，4 banks，bank = addr % 4）

| 坐标 | ① outer | ③ swizzle 后 | bank(%4) |
|------|---------|-------------|----------|
| (0,2) | 2  | 2  | **2** |
| (1,2) | 6  | 7  | **3** |
| (2,2) | 10 | 8  | **0** |
| (3,2) | 14 | 13 | **1** |

- **无 swizzle**：地址 2,6,10,14 → bank 全是 `2,2,2,2` → **4 路 bank conflict**，串行化；
- **有 swizzle**：地址 2,7,8,13 → bank `2,3,0,1` → **全不同**，一次并行完成。

→ `outer` 决定的整齐线性地址会规律性撞 bank，`inner` 用 XOR 打散开。

### 3.3 offset 的作用（复用 inner+outer，只改 offset）

同一块 smem，换 `offset = 1`（指向下一 stage 起点），坐标仍 `(3,2)`：

```
① outer:   3*4+2 = 14
② +offset: 14 + 1 = 15        ← 偏移生效
③ swizzle: 15 ^ ((15&0b1100)>>2) = 1111 ^ 0011 = 1100 = 12
最终地址 = 12
```

→ **inner、outer 完全复用，只改 offset 就把同一套布局平移到 smem 另一段** —— 多 stage / 多子块共享一个 swizzled layout 的常见做法。

---

## 四、四者怎么咬合（总图）

```
Layout (Shape,Stride)  ◄── ScaledBasis 让 stride 能指定 mode
      │
      │  cute.composition
      ▼
ComposedLayout  ◄── Swizzle (XOR 置换, 避 bank conflict)
   = inner ∘ offset ∘ outer
      │
      │  + Pointer(Engine)
      ▼
   Tensor   （T = E ∘ L）
```

**一句话总结**：`Layout` 定基本坐标→index 映射；`ScaledBasis` 让 stride 精确指模；`Swizzle` 定义 XOR 地址置换；`ComposedLayout` 把 swizzle+offset 包到 outer layout 外，落成「逻辑形状由 outer 决定、物理访存被 swizzle 优化」的访问模式；再叠上 `Pointer` 即成 `Tensor`。
