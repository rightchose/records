# CuTe DSL 进阶：Hopper WGMMA GEMM —— Host 侧准备 + Kernel 开头

源文件：`cutlass/examples/python/CuTeDSL/cute/hopper/kernel/dense_gemm/dense_gemm.py`
辅助：`cutlass/python/CuTeDSL/cutlass/utils/hopper_helpers.py`（即代码里的 `sm90_utils`）、`utils/layout.py`

> 承接 Ampere（`03/04`）学 Hopper。本篇覆盖 **host 侧装配 + device kernel 开头**（坐标 / mcast / TMA descriptor）。
> WGMMA 主循环 + mbarrier 流水线留到下一篇。

---

## 〇、Hopper vs Ampere 的整体差异（先建立框架）

| 维度 | Ampere (`tensorop_gemm`) | Hopper (`dense_gemm`) |
|------|--------------------------|------------------------|
| MMA | `m16n8k16`（warp 级，ldmatrix 喂寄存器） | **WGMMA** `m64nNk16`（warpgroup 级，直接读 smem） |
| GMEM→SMEM | cp.async | **TMA**（tensormap 描述符，硬件搬运 + 多播） |
| 同步 | `__syncthreads` + cp.async barrier | **mbarrier**（transaction count，异步） |
| 调度单位 | CTA | **Cluster**（2~16 CTA，DSM 共享 smem） |
| 数据复用 | L2 + smem | + **multicast**（一份数据广播进多 CTA smem） |

核心新概念：**TMA descriptor / WGMMA / cluster / multicast / mbarrier pipeline**。

---

## 一、`__call__`（host 侧装配车间）`:373-479`

纯 host 逻辑，七步：

1. **提元数据** `:399-404`：从真实 tensor 读 `dtype` / `LayoutEnum`（行列主序）
2. **类型校验** `:406-415`：`const_expr` 编译期判断，只收 16-bit / 8-bit，A/B 位宽须等
3. **`_setup_attributes()`** `:417`：集中算所有静态属性（tiled_mma / stage / smem layout / mcast 标志 / epi_tile）
4. **建 TMA atom+tensor** `:419-437`：A/B 用 G2S(load)，C 用 S2G(store)
5. **算 grid** `:439`：`_compute_grid`
6. **定义 SharedStorage** `:441-459`：mbarrier 数组 + sA + sB（**无 sC，epilogue 复用 sA**）
7. **launch** `:462-479`：带 `cluster=(*cluster_shape_mn,1)` —— **Hopper 启动接口相比 Ampere 的关键新增**

### `LayoutEnum.from_tensor`（`utils/layout.py:51`）
看 `tensor.leading_dim`（stride==1 在第几个 mode）：
- `==1` → 第 1 维连续 → **ROW_MAJOR**
- `==0` → 第 0 维连续 → **COL_MAJOR**

存在意义：把行/列主序翻译成 WGMMA/TMA 需要的 **major mode**：
```python
def sm90_mma_major_mode(self): return K if ROW_MAJOR else MN
```
ROW_MAJOR→K-major，COL_MAJOR→MN-major。swizzle 选择、GMMA descriptor 填法都依赖它。

---

## 二、`_setup_attributes` 关键计算 `:300-371`

### 2.1 `atom_layout_mnk` —— warpgroup 网格布局 `:271-275`

控制 **MMA atom（= warpgroup）在 M/N/K 各铺几个**，即 warpgroup 怎么分工：
```python
atom_layout_mnk = (2,1,1) if (BLK_M>64 and BLK_N>128) else (1,1,1)
```
- 大 tile → `(2,1,1)`：M 方向 2 个 warpgroup（cooperative，各算 64 行），**防寄存器溢出**（注释 `:269-270`）
- 小 tile → `(1,1,1)`：1 个 warpgroup

直接决定线程数 `:283-285`：
```python
mma_warp_groups = prod(atom_layout_mnk)          # 2 或 1
threads_per_cta = mma_warp_groups * 128           # 256 或 128
```
device 侧 `:664-670` 每个 warpgroup 用 `warp_group_idx` 从 tiled_mma 切出自己那段 M。

> 三个 mode：M=多 wg 分 M（用到）；N/K=split（本 kernel 恒 1，没用）。
> Blackwell 对应概念升级成 `CtaGroup`（2CTA），见 FA4 笔记。

### 2.2 `make_trivial_tiled_mma`（`hopper_helpers.py:92`）

按 dtype 选 WGMMA 指令 → atom → tiled。**关键：K 维由 dtype 硬定**：

| dtype | MMA Op | MMA shape K |
|-------|--------|-------------|
| fp16/bf16 | `MmaF16BF16Op` | **16** |
| fp8 | `MmaF8Op` | **32** |
| int8 | `MmaI8Op` | **32** |

```python
return cute.make_tiled_mma(cute.make_mma_atom(mma_op), atom_layout_mnk)
```
- `make_mma_atom`：指令 → 一个 warpgroup 能执行的最小单元
- `make_tiled_mma`：按 `atom_layout_mnk` 平铺成覆盖整 CTA tile 的 TiledMma
- `tiler_mn=(64, BLK_N)`：M **固定 64**（WGMMA m64 硬件特性）

### 2.3 `BLK_K = mma_inst_shape_k × 4` `:328-333`

```python
mma_inst_shape_k = size(tiled_mma.shape_mnk, mode=[2])  # fp16=16
mma_inst_tile_k = 4
BLK_K = 16 × 4 = 64    # fp16
```
- **必须是 MMA-K 的整数倍**（CTA tile K = 若干条 MMA 叠加）
- **fp16 → BLK_K=64 → `64×16bit=1024bit` 正好命中 128B swizzle**（坐实，见三.swizzle 选择）
- ⚠️ **`=4` 本身是 NVIDIA 调参经验值，代码无注释推导。"为什么不是 2/8" 无依据，需 benchmark 实测。**

### 2.4 `epi_tile`（`compute_tile_shape_or_override` `hopper_helpers.py:400`）

epilogue **回写工作粒度**：CTA tile 太大，回写 smem（复用 sA）装不下，切小块逐块倒，并和 GMEM 写回流水。
```python
is_cooperative:  tile_m=min(128,BLK_M), tile_n=min(32, BLK_N)
非 coop:         n_perf=64 if width==8 else 32   # 用 c_dtype 位宽!
                 tile_m=min(64,BLK_M), tile_n=min(n_perf,BLK_N)
```
- N：fp16→32，fp8→64，本质都凑 **`N×c_dtype位宽 = 64 Byte`**（`32×16bit=64×8bit=512bit`）
- M：coop=128（2 wg），非 coop=64（WGMMA m64 边界）
- ⚠️ **"为什么 epi N 恰好取 32" 未坐实**：上游写死的常数，无注释。只坐实了"N=32 进来后选 64B swizzle"。

---

## 三、smem layout（`_make_smem_layouts` → `make_smem_layout_a/b/epi`）

`_make_smem_layouts` `:1075` 是纯分发器，调三个 `sm90_utils` 函数。返回 **`cute.ComposedLayout`（基础 layout ∘ swizzle）**。

### 统一四步套路（以 A，K-major fp16，tile (128,128,64) 为例）

`make_smem_layout_a`（`hopper_helpers.py:215`）：
1. **取 2D smem 形状** `:246`：`slice_(mnk,(None,0,None))` → A 取 (M,K)=(128,64)（N 不属于 A）
2. **major mode size** `:250`：K-major → 取 K=64（连续维大小）
3. **挑 swizzle** `:253`（`get_smem_layout_atom` `:172`）：
   ```python
   major_mode_size_bits = 64×16 = 1024
   1024 % 1024 == 0 → K_SW128   # 命中最大 128B swizzle
   ```
   档位：`1024→SW128 / 512→SW64 / 256→SW32 / 否则→INTER(无swizzle)`
4. **tile + stage** `:261`：`tile_to_shape(atom, append(shape, ab_stage), order)`
   - order：K-major=`(0,1,2)`，M-major=`(1,0,2)`

### A / B / epi 差异

| | smem 形状 | stage | major 判断 |
|---|---|---|---|
| A | (M,K) `slice(None,0,None)` | ab_stage | is_k_major_a |
| B | (N,K) `slice(0,None,None)` | ab_stage | is_k_major_b |
| epi | = epi_tile（已 2D） | epi_stage(=4) | is_n_major_c / is_m_major_c |

### ⭐ ComposedLayout：swizzle 不是 stride（关键概念）

`make_smem_layout_*` 返回的 `smem_layout` 是 `ComposedLayout = swizzle ∘ 基础layout`，**两层独立**：

```
ComposedLayout
├── inner layout:  (128,64):(64,1)    ← 有 stride（K-major：K连续stride=1，M跳64）
└── swizzle:       Sw<128B, B=3>       ← XOR 函子，没有 stride
```

以 A 单 tile（K-major fp16, (M=128,K=64)）为例：
- **基础 layout stride = `(64, 1)`**：逻辑地址 `m*64 + k`，普通行主序，与有无 swizzle 无关
- **swizzle 单独一层**：物理 offset = `swizzle(m*64 + k)`，即 `addr[M:M+B] ^= addr[S:S+B]`（见 04 篇），128B 档 B=3。fp16 下连续粒度 `128B/2B=64` 正好=K

**为什么 swizzle 进不了 stride**：stride 是线性仿射 `Σ coord_i × stride_i`，swizzle 是 **XOR（非线性）**，无法用任何 stride 表达。这正是 swizzle vs padding 的本质（零空间浪费）。CuTe 用 ComposedLayout 分两层存。

> 提问"smem_layout 的 stride 是？"——答：基础部分 `(64,1)`；swizzle=128 那部分**没有 stride**，是叠加在 offset 上的 XOR 映射（逻辑 offset→物理 bank），让 WGMMA 读 smem 无 bank conflict。
> ⚠️ 未坐实：`tile_to_shape` 后基础 layout 的**确切嵌套表示**（可能是 `((8,16),64)` 这种分层而非扁平 `(64,1)`）没实跑 `print` 验证；但**逻辑 stride 等价 `(64,1)`** 与 **swizzle/stride 分离** 这两点确定。

### `make_smem_layout_epi`（`:328`）补充
- N-major(row C) → major_size=epi_tile[1]=32 → `32×16=512bit` → **K_SW64**（坐实选档）
- `order` 用了**嵌套三元**（`:384-390`），易看错，等价：
  ```python
  if smem_order is not None: smem_order          # override 检查
  elif is_m_major_c():       (1,0,2)             # 默认按 majorness
  else:                      (0,1,2)
  ```
  （A/B 没这层，因为它们不收 `smem_order` override 参数。）

---

## 四、`_make_tma_atoms_and_tensors`（造 128B tensormap）`:1190`

以 A 为例，四个实参（`:419-424`）：
```python
_make_tma_atoms_and_tensors(
    a,                                   # ① 原始 GMEM tensor (M,K,L)
    a_smem_layout_staged,                # ② 带 swizzle+stage 的 smem 布局
    (tile_shape_mnk[0], tile_shape_mnk[2]),  # ③ smem_tile=(BLK_M,BLK_K)=(128,64)
    cluster_shape_mn[1],                 # ④ mcast_dim = N方向cluster数（A沿N共享）
)
```

函数内：
1. **选 op** `:1211`：`mcast_dim==1 ? G2SOp : G2SMulticastOp`（>1 才用多播版）
2. **slice 掉 stage** `:1217`：descriptor 只描述单 tile
3. **`make_tiled_tma_atom`** `:1218`：综合 GMEM 形状/stride + tile + swizzle + `num_multicast`，生成 **128B tensormap**

返回：
- `tma_atom`：封装 descriptor 的 copy atom
- `tma_tensor`：TMA 视角包装后的 tensor（device 侧 `mA_mkl`）

| | op | smem_tile | mcast_dim | 方向 |
|---|---|---|---|---|
| A | G2S(Multicast) | (BLK_M,BLK_K) | cluster_N | sm `cluster_shape_mn[1]` |
| B | G2S(Multicast) | (BLK_N,BLK_K) | cluster_M | `cluster_shape_mn[0]` |
| C | **S2G**（`_make_tma_store...` `:1162`，写回方向，无多播） | epi_tile | — | — |

直觉：A 物理是 (M,K)，N 是外积维 A 不含；同一 (M,K) 块喂给 N 方向所有 CTA → 沿 N 多播。

---

## 五、`_compute_grid` `:1136`

```python
gc = zipped_divide(c, tiler=(BLK_M,BLK_N))           # 切 tile 网格
clusters = ceil_div(gc.mode[1].shape, cluster_shape) # 按 cluster 向上取整
grid = clusters × cluster_shape                       # 回到 CTA grid
```
两层取整：**CTA→cluster（host，ceil_div）** vs **cluster→group_size_m（device swizzle，tail）**，不要混。

---

## 六、Device kernel 开头 `:483-594`

### 6.1 入口 tensor 命名
`mA_mkl`(M,K,L) / `mB_nkl`(N,K,L) / `mC_mnl`(M,N,L)，**L=batch**。

### 6.2 prefetch TMA desc `:525-533`
```python
warp_idx = make_warp_uniform(warp_idx())
if warp_idx == 0:
    prefetch_descriptor(tma_atom_a)   # PTX prefetch.tensormap，提前拉 128B 描述符进 cache
    prefetch_descriptor(tma_atom_b)
```

### 6.3 坐标 + CTA swizzle `:538-576`（详见 04 篇 / 之前讨论）
- `cluster_id = cidx + cdimx*cidy`
- CTA swizzle（L2 复用，group_size_m=8，含 tail 处理）→ `(cid_m,cid_n)`
- `pid_m = cid_m*cluster_M + bidx_in_cluster[0]` `:569`
- `tile_coord_mnkl = (pid_m, pid_n, None, bidz)` `:572`：本 CTA 负责的 C tile（None=K循环，bidz=batch）
- `cta_rank_in_cluster = make_warp_uniform(block_idx_in_cluster())` `:573`
  - ⚠️ 用 `block_idx_in_cluster()`（返回**标量 rank**）而非 `block_in_cluster_idx()`（返回**tuple 坐标**），因为 `make_warp_uniform(value: Int)→Int32` **只收标量**，tuple 塞不进去

### 6.4 multicast mask `:581-589`
```python
a_mcast_mask = make_layout_image_mask(cta_layout_mnk, cluster_coord_mnk, mode=1)  # A沿N
b_mcast_mask = make_layout_image_mask(cta_layout_mnk, cluster_coord_mnk, mode=0)  # B沿M
a_mcast_mask = a_mcast_mask if is_a_mcast else 0   # gate：该方向cluster=1则清零退化
```
- `is_a_mcast = cluster_shape_mn[1] > 1`，`is_b_mcast = cluster_shape_mn[0] > 1` `:337-340`
- **mask = 16-bit，bit i = cluster rank i 收广播**（Hopper cluster 上限：可移植 8，非可移植 16）
- `make_layout_image_mask`（`core.py:5128`）四步：
  1. slice：固定非 mode 维，放开 mode 维
  2. image：扫 mode 维 → 一组**相对 rank**（固定维当原点）
  3. 置位：`mask |= 1<<sliced_lay(i)`
  4. **`mask <<= offset`**：把相对 rank 抬成**绝对 rank**（offset=固定维贡献）
  - 例 cluster(2,2)、当前 rank3=(1,1)、mode=1：sliced 得 {0,2}=`0b0101`，offset=1，`<<1`→`0b1010`=rank{1,3}
- 下游：`cute.copy(tma_atom_a, ..., mcast_mask=a_mcast_mask)` `:757`(prefetch)/`:901`(mainloop)，TMA 据 mask 把一份数据广播进所有置位 CTA 的 smem

### 6.5 TMA transaction bytes `:590-594`
```python
a_smem_layout = slice_(a_smem_layout_staged,(None,None,0))   # 取单 stage
tma_copy_bytes = size_in_bytes(a_dtype,a_smem) + size_in_bytes(b_dtype,b_smem)
```
一个 stage 里 A+B buffer 总字节，供 mbarrier `expect_tx` 用（TMA 异步搬完按字节数 arrive）。
> ⚠️ **不 ×multicast**：Hopper 普通多播每 CTA 仍只收一份字节。（与 Blackwell 2CTA "tx_count ×cta_group" 不同——那是跨 CTA 累加器特殊性。）

---

## 七、Epilogue 类型转换证据（坐实 fp32→c_dtype）`:990-1004`

回应"smem 里 C 到底是 fp32 还是 bf16"：**reg 内先 cvt 成 c_dtype 才写 smem**。
```python
tRS_rD     = make_rmem_tensor_like(layout, acc_dtype)   # :961 fp32 中转
acc_vec    = tRS_rD.load()
tRS_rD_out = make_rmem_tensor_like(layout, c_dtype)     # :996 c_dtype 寄存器
tRS_rD_out.store(acc_vec.to(c_dtype))                   # :998 ★cvt fp32→bf16★
cute.copy(tiled_copy_r2s, tRS_rD_out, tRS_sD[...])      # :1002 写进 smem 的是 c_dtype
```
路径：`累加器(fp32,reg) → cvt → reg(c_dtype) → smem(c_dtype) → TMA → GMEM`。
所以 epi_tile 字节宽度用 **c_dtype 位宽**（非 fp32），与 `compute_tile_shape_or_override` 传 c_dtype 自洽。

写回 store 指令 `StMatrix8x8x16bOp`（`warp/copy.py:262`）：单矩阵 8×8、**16-bit**（绑死 16-bit C）、`num_matrices∈{1,2,4}`（本 kernel 传 4）。
> ⚠️ **"epi N=32 与 StMatrix 4 矩阵/64B 的因果链未坐实"**：能确认数值自洽（32=4×8、32×16bit=64B），但"为什么甜点是 64B 而非 128B / 4 矩阵铺 N 还是 M"未从代码追出，需读 `make_tiled_copy_S` + benchmark。

---

## 八、待续（下一篇）

device 主体 `:596+`：
- mbarrier 分配 + `PipelineTmaAsync` 初始化
- `tma_partition` + `cute.copy` + transaction barrier
- WGMMA 主循环（`warpgroup.fence/commit_group/wait_group`）
- epilogue 回写流水（`PipelineTmaStore` + TMA S2G）

---

## 附：本篇诚实标注的"未坐实"清单

1. `mma_inst_tile_k=4` —— 经验值，无推导
2. `epi_tile` N=32 取值理由 —— 上游写死常数，只坐实下游选 64B swizzle
3. StMatrix 4 矩阵 / 64B 甜点的因果 —— 数值自洽但因果链未追出
